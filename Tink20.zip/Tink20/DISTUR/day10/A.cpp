#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

#define int long long
const int MOD = 1000000007;

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    string s;
    cin >> s;
    vector<pair<int, int>> dp0(n, {0, 0});
    vector<pair<int, int>> dp1(n, {0, 0});
    if (s[0] == '0') dp0[0].first = 1;
    else dp1[0].first = 1;
    for (int i = 1; i < n; i++){
        if (s[i] == '1'){
            dp1[i].first = dp0[i - 1].second;
            dp1[i].second = (dp1[i - 1].first + dp1[i - 1].second) % MOD;
            dp0[i].first = 0;
            dp0[i].second = (dp0[i - 1].second + dp0[i - 1].first) % MOD;
        }
        else{
            dp1[i].first = 0;
            dp1[i].second = dp1[i - 1].second;
            dp0[i].first = dp1[i - 1].second;
            dp0[i].second = dp0[i - 1].second;
        }
    }
    cout << (dp0[n - 1].second + dp1[n - 1].second) % MOD
    ;
    return 0;
}
