#include <vector>
#include <algorithm>
#include <iostream>
#include <set>
#include <map>

using namespace std;

#define int long long

struct e {
    int l, k, ind;
};
map<int, pair<int, int>> mp;
vector<int> p, lst, lstp;

int rel(int x, int l){
    if (x == l) return 1;
    if (mp.find(x) != mp.end()){
        return mp[x].first + mp[x].second;
    }
    int a, b;
    if (x % 2 == 0) {
        a = x / 2 - 1;
        b = x / 2;
    } else {
        a = x / 2;
        b = x / 2;
    }
    mp[x] = {0, 0};
    mp[x].first = rel(a, l);
    mp[x].second = rel(b, l);
    return mp[x].first + mp[x].second;
}

int fnd(int x, int k, int l, int pos){
    if (x == l){
        if (x % 2 == 0)
            return pos + x / 2;
        else
            return pos + x / 2 + 1;
    }
    int a, b;
    if (x % 2 == 0) {
        a = x / 2 - 1;
        b = x / 2;
    } else {
        a = x / 2;
        b = x / 2;
    }
    if (mp[x].first >= k){
        return fnd(a, k, l, pos);
    }
    else{
        return fnd(b, k - mp[x].first, l, pos + a + 1);
    }
}

int get(int l, int k, int ind){
    //cerr << l << " " << k << " " << ind << '\n';
    mp.clear();
    int x = lst[ind];
    rel(x, l);
    return fnd(x, k, l, lstp[ind]);
}
signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, m, q;
    cin >> n >> m >> q;
    for (int i = 0; i < m; i++) {
        int x;
        cin >> x;
        p.push_back(x);
    }
    for (int i = 0; i < m; i++) {
        if (i == 0) {
            if (p[i] != 1) {
                lst.push_back(p[i] - 1);
                lstp.push_back(1);
            }
        } else {
            if (p[i] != p[i - 1] + 1) {
                lst.push_back(p[i] - p[i - 1] - 1);
                lstp.push_back(p[i - 1] + 1);
            }
        }
    }
    if (p.back() != n){
        lst.push_back(n - p.back());
        lstp.push_back(p.back() + 1);
    }
    vector<e> cur;
    for (int i = 0; i < lst.size(); i++) {
        set<pair<int, int>> x;
        x.insert({-lst[i], 1});
        while (!x.empty()) {
            auto xx = *x.begin();
            xx.first *= -1;
            x.erase(x.begin());
            cur.push_back({xx.first, xx.second, i});
            int a, b;
            if (xx.first % 2 == 0) {
                a = xx.first / 2 - 1;
                b = xx.first / 2;
            } else {
                a = xx.first / 2;
                b = xx.first / 2;
            }
            if (a != 0) {
                auto it = x.lower_bound({-a, -1});
                if (it == x.end() || (*it).first != -a) {
                    x.insert({-a, xx.second});
                } else {
                    int val = (*it).second;
                    x.erase(it);
                    x.insert({-a, val + xx.second});
                }
            }
            if (b != 0) {
                auto it = x.lower_bound({-b, -1});
                if (it == x.end() || (*it).first != -b) {
                    x.insert({-b, xx.second});
                } else {
                    int val = (*it).second;
                    x.erase(it);
                    x.insert({-b, val + xx.second});
                }
            }
        }
    }
    sort(cur.begin(), cur.end(), [&](const e &a, const e &b) {
        if (a.l == b.l) return a.ind < b.ind;
        return a.l > b.l;
    });
//    for (int i =0; i < cur.size(); i++){
//        cerr << cur[i].l << " " << cur[i].k << " " << cur[i].ind << '\n';
//    }
    vector<pair<int, int>> qq;
    vector<int> ans(q);
    for (int i =0; i < q; i++){
        int x;
        cin >> x;
        if (x > m){
            qq.push_back({x - m, i});
        }
        else{
            ans[i] = p[x - 1];
        }
    }
    sort(qq.begin(), qq.end());
    int cnt = 0, pos = 0;
    for (int i = 0; i < qq.size(); i++) {
        int x = qq[i].first;
        while (x > cnt + cur[pos].k){
            cnt += cur[pos].k;
            pos++;
        }
        ans[qq[i].second] = get(cur[pos].l, x - cnt, cur[pos].ind) - 1;
    }
    for (int i = 0; i < q; i++){
        cout << ans[i] << '\n';
    }
}