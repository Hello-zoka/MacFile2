#include <vector>
#include <algorithm>
#include <iostream>
#include <set>

using namespace std;

#define int long long

struct e {
    int x, y, typ, tim;
    int ind;
};

const int INF = 1e12;

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, k, q;
    cin >> n >> k >> q;
    vector<e> lst;
    for (int i = 0; i < n; i++) {
        e cur;
        cin >> cur.x >> cur.y >> cur.tim;
        cur.y--;
        cur.typ = 0;
        lst.push_back(cur);
        cin >> cur.tim;
        cur.typ = 2;
        lst.push_back(cur);
    }
    for (int i = 0; i < q; i++) {
        e cur;
        cin >> cur.x >> cur.tim;
        cur.typ = 1;
        cur.ind = i;
        lst.push_back(cur);
    }
    vector<int> ans(q);
    sort(lst.begin(), lst.end(), [&](const e &a, const e &b) {
        if (a.tim == b.tim) return a.typ < b.typ;
        return a.tim < b.tim;
    });
    vector<multiset<int>> cur(k);
    for (int i = 0; i < lst.size(); i++) {
        //cerr << lst[i].typ << " ";
        if (lst[i].typ == 0) {
            cur[lst[i].y].insert(lst[i].x);
        } else if (lst[i].typ == 2) {
            cur[lst[i].y].erase(cur[lst[i].y].find(lst[i].x));
        } else {
            int mx = 0, bl = 1;
            for (int j = 0; j < k; j++) {
                auto it = cur[j].lower_bound(lst[i].x);
                int mn = INF;
                if (cur[j].size() == 0) {
                    bl = 0;
                    break;
                }
                if (it != cur[j].end()) {
                    mn = min(mn, abs(*it - lst[i].x));
                }
                if (it != cur[j].begin()) {
                    it--;
                    mn = min(mn, abs(*it - lst[i].x));
                }
                mx = max(mx, mn);
            }
            if (!bl)
                mx = -1;
            ans[lst[i].ind] = mx;
        }
    }
    for (int i =0; i < q; i++){
        cout << ans[i] << "\n";
    }
    return 0;
}