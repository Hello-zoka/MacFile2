#include <vector>
#include <iostream>
#include <algorithm>
#include <set>

using namespace std;

#define int long long

struct c {
    int x, y, r;
    int ind;
};
struct e {
    int x, ind;
};

bool operator<(const e &a, const e &b) {
    if (a.x == b.x) return a.ind < b.ind;
    return a.x < b.x;
}

int d(int x1, int y1, int x2, int y2) {
    return (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2);
}

bool inter(c &a, c &b) {
    return d(a.x, a.y, b.x, b.y) <= (a.r + b.r) * (a.r + b.r);
}

int n;
vector<c> lst;

void solv1() {
    sort(lst.begin(), lst.end(), [&](const c &a, const c &b) {
        if (a.r == b.r) return a.ind < b.ind;
        return a.r > b.r;
    });
    vector<int> used(n, -1);
    for (int i = 0; i < n; i++) {
        //cerr << lst[i].ind << " ";
        if (used[i] == -1) {
            used[i] = lst[i].ind;
            for (int j = 0; j < n; j++) {
                if (used[j] == -1 && inter(lst[i], lst[j])) {
                    used[j] = lst[i].ind;
                }
            }
        }
    }
    vector<int> ans(n);
    for (int i = 0; i < n; i++) {
        ans[lst[i].ind] = used[i] + 1;
    }
    for (int i = 0; i < n; i++) {
        cout << ans[i] << " ";
    }

}

void solv2() {
    set<e> cur;
    sort(lst.begin(), lst.end(), [&](const c &a, const c &b) {
        if (a.r == b.r) return a.ind < b.ind;
        return a.r > b.r;
    });
    for (int i = 0; i < n; i++) {
        cur.insert({lst[i].x - lst[i].r, i});
        cur.insert({lst[i].x + lst[i].r, i});
    }
    vector<int> used(n, -1);
    for (int i = 0; i < n; i++) {
        if (used[i] == -1) {
            int l = lst[i].x - lst[i].r;
            int r = lst[i].x + lst[i].r;
            auto it = cur.lower_bound({l - 1, n + 1});
            while ((*it).x <= r) {
                e a = *it;
                used[a.ind] = lst[i].ind;
                int ll = lst[a.ind].x - lst[a.ind].r;
                int rr = lst[a.ind].x + lst[a.ind].r;
                cur.erase(cur.find({rr, a.ind}));
                cur.erase(cur.find({ll, a.ind}));
                it = cur.lower_bound({l - 1, n + 1});
                if (it == cur.end()) break;
            }
        }
    }
    vector<int> ans(n);
    for (int i = 0; i < n; i++) {
        ans[lst[i].ind] = used[i] + 1;
    }
    for (int i = 0; i < n; i++) {
        cout << ans[i] << " ";
    }
}

struct ln {
    int y, typ, ind;
};

int solv3() {
    set<e> cur;
    vector<ln> lin;
    for (int i = 0; i < n; i++) {
        lin.push_back({lst[i].y + lst[i].r, 0, i});
        lin.push_back({lst[i].y - lst[i].r, 1, i});
    }
    sort(lin.begin(), lin.end(), [&](const ln &a, const ln &b) {
        if (a.y == b.y) return a.typ < b.typ;
        return a.y > b.y;
    });
    vector<pair<int, int>> edg;
    vector<int> used(n, 0);
    for (int i = 0; i < lin.size(); i++) {
        if (lin[i].typ == 1) {
            if (used[lin[i].ind]) {
                cur.erase({lst[lin[i].ind].x, lin[i].ind});
                used[lin[i].ind] = 0;
            }
        } else {
            auto it = cur.lower_bound({lst[lin[i].ind].x, -1});
            //cerr << "f: " << it->ind << '\n';
            if (it != cur.end() && inter(lst[lin[i].ind], lst[it->ind])) {
                //cerr << "s2: " << it->ind << '\n';
                edg.push_back({lin[i].ind, it->ind});
                cur.erase(it);
                used[it->ind] = 0;
            } else if (it != cur.begin()) {
                it--;
                if (inter(lst[lin[i].ind], lst[(it)->ind])) {
                    edg.push_back({lin[i].ind, it->ind});
                    used[it->ind] = 0;
                    cur.erase(it);
                } else {
                    cur.insert({lst[lin[i].ind].x, lin[i].ind});
                    used[lin[i].ind] = 1;
                }
            } else {
                cur.insert({lst[lin[i].ind].x, lin[i].ind});
                used[lin[i].ind] = 1;
            }
        }
    }
    vector<int> ans(n, -1);
    for (int i = 0; i < edg.size(); i++) {
        if (ans[edg[i].first] != -1 || ans[edg[i].second] != -1) return -1;
        if (lst[edg[i].first].r > lst[edg[i].second].r ||
            (lst[edg[i].first].r == lst[edg[i].second].r && edg[i].first < edg[i].second)) {
            ans[edg[i].second] = edg[i].first;
        } else {
            ans[edg[i].first] = edg[i].second;
        }
    }
    for (int i = 0; i < n; i++) {
        if (ans[i] == -1) {
            ans[i] = i;
        }
        cout << ans[i] + 1 << " ";
    }
    return 0;
}


signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    int bl = 1;
    for (int i = 0; i < n; i++) {
        c x;
        cin >> x.x >> x.y >> x.r;
        if (x.y != 0) bl = 0;
        x.ind = i;
        lst.push_back(x);
    }
//    solv3();
//    cout << '\n';
    if (n <= 5000) {
        solv1();
    } else if (bl) {
        solv2();
    } else {
        return solv3();
    }
    return 0;
}