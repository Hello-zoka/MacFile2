#include <iostream>
#include <algorithm>
#include <vector>

using namespace  std;

#define int long long
#define INF 1e9
int ans =INF;
int xx;

void check(int x){
    for (int i = xx / x + 1; i <= x + 5; i++){
        int ned = x * (i - 1) + 1;
        int cnt = 0;
        while(ned % i == 0){
            ned /= i;
            cnt++;
        }
        if (ned != 1 ){
            continue;
        }

        ans = min(ans, i);
    }
}
signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> xx;
    for (int k = 1; k * k <= xx; k++){
        if (xx % k == 0){
            check(k);
            check(xx / k);
        }
    }
    cout << ans;


    return 0;
}