#include <iostream>
#include <algorithm>
#include <vector>
#include <math.h>

using namespace  std;
int n, m, u;
const int mod = 1000000007;
void solve(){
    swap(n, m);
    int dp[2][m][m];
    int ans =0;
    for (int k = 0; k < n; k++){
        vector<int> pref(m, 0), mas(m, 0);
        for (int i = 1; i < m; i++){
            vector<int> cur(m, 0);
            for (int j = 0; j < i; j++){
                //cerr << 1;
                if (k == 0)
                    dp[1][i][j] = 1;
                else if (j != 0) {
                    dp[1][i][j] = mas[j - 1];
                }
                else {
                    dp[1][i][j] = 0;
                    //continue;
                }
                //cerr << 2;
                dp[1][i][j] %= mod;
                if (k != 0)
                    cur[j] += dp[0][i][j];
                cur[j] %= mod;
                if (k == n - 1) {
                    ans += dp[1][i][j];
                    ans %= mod;
                }
            }
            for (int j =0; j  < m; j++){
                pref[j] += cur[j];
                pref[j] %= mod;
                mas[j] = pref[j];
                if (j != 0) mas[j] += mas[j - 1];
                mas[j] %= mod;
            }
//            if (k == 1)
//                cerr << "\n\n";
        }
        for (int i = 1; i < m; i++){
            for (int j = 0; j < i; j++){
                dp[0][i][j] = dp[1][i][j];
            }
        }
    }
//    for (int i =0 ; i < n; i++){
//        for (int j =0 ; j < m; j++){
//            for (int k = 0; k < m; k++){
//                cerr << dp[i][j][k] << " ";
//            }
//            cerr << '\n';
//        }
//        cerr << '\n';
//    }
    cout << ans;
}
#define int long long
#define INF 1e9
const int maxn = 2000002;

int t[maxn];
int bp (int a, int n) {
    int res = 1;
    while (n) {
        if (n & 1) res = res * a % mod;
        a = a * a % mod;
        n >>= 1;
    }
    return res;
}
int inv (int x) {
    return bp(x, mod-2);
}
int c (int n, int k) {
    return t[n] * inv(t[k]) % mod * inv(t[n-k]) % mod;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m >> u;
    if (u == 0){
        solve();
        return 0;
    }
    int x = 1;
    t[0] = 1;
    for (int i = 1; i < maxn; i++){
        x *= i;
        x %= mod;
        t[i] = x;
    }
    int dop = c(n, 2 * m);
    //cerr << dop;

    cout << (dop * ((inv(m + 1) * c(2 * m, m)) % mod))% mod;
    return 0;
}