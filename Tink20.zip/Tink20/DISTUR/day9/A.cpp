#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
using namespace  std;

#define int long long

vector<int> par, sz;
int cnt;
int getu(int v){
    if (par[v] == v) return v;
    return par[v] = getu(par[v]);
}
void un(int u, int v){
    u = getu(u);
    v = getu(v);
    if (u != v){
        cnt--;
        if (sz[u] < sz[v]) swap(u, v);
        par[v] = u;
        if (sz[u] == sz[v]) sz[u]++;
    }
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, m, k;
    cin >> n >> m >> k;
    vector<pair<int, int>> lst;
    sz.assign(n, 0);
    for (int i =0; i < n; i++){
        par.push_back(i);
    }
    cnt = n;
    vector<pair<int, int>> edg;
    for (int i = 0; i < m; i++){
        int u, v;
        cin >> u >> v;
        u--;
        v--;
        un(u, v);
        edg.push_back({u, v});
    }
    int cur = 0;
    vector<int> a(n, 0);
    for (int i =0; i < n; i++){
        a[getu(i)]++;
    }
    sort(a.begin(), a.end());
    reverse(a.begin(), a.end());
    for (int i =0; i < m ; i++){
        if (getu(edg[i].first) == getu(edg[i].second)) cur++;
    }
    cout << max((int)1, cnt - k) << " ";
    k += cur;
    for (int i = 0; i < n; i++){
        k -= (a[i] * (a[i] - 1)) / 2;
    }
    int st = a[0];
    for (in
    t i = 1; i < n; i++){
        if (cnt == 1 || k <= 0) break;
        cnt--;
        k -= st * a[i];
        st += a[i];
    }
    cout << cnt;
    return 0;
}
