#include <vector>
#include <algorithm>
#include <iostream>
#include <stack>

using namespace std;

//#define int long long

struct e{
    int l, r, ind;
    int vl = -1;
};

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, m;
    cin >> n >> m;
    vector<vector<int>> lst(n);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            int x;
            cin >> x;
            lst[i].push_back(x ^ 1);
        }
    }
    int qq;
    cin >> qq;
    vector<e> q;
    for (int t = 0; t < qq; t++) {
        e x;
        cin >> x.l >> x.r;
        x.l--;
        x.r--;
        x.ind = t;
        q.push_back(x);
    }
    sort(q.begin(), q.end(), [&](const e &a, const e &b) {
        if (a.r == b.r) {
            return a.l < b.l;
        }
        return a.r < b.r;
    });

    vector<vector<e>> mas(n);
    int pos = 0;
    for (int i = 0; i < n; i++) {
        while (pos < q.size() && q[pos].r == i) {
            mas[i].push_back(q[pos]);
            pos++;
        }
    }
    vector<vector<int>> dp = lst;
    for (int i = n - 2; i >= 0; i--) {
        for (int j = 0; j < m; j++) {
            if (dp[i][j] != 0) {
                dp[i][j] += dp[i + 1][j];
            }
        }
    }
    vector<int> uk(n, -1);
    sort(q.begin(), q.end(), [&](const e &a, const e &b) {
        return a.l < b.l;
    });
    pos = 0;
    for (int i = 0; i < n; i++){
        while (pos < q.size() && q[pos].l == i){
            uk[q[pos].r]++;
            pos++;
        }
        vector<pair<int, int>> rect;
        stack<pair<int, int>> cur;
        int res = -1;
        for (int j = 0; j < m; j++){
            int prev = j;
            while (!cur.empty() && cur.top().first > dp[i][j]){
                rect.push_back({cur.top().first, j - cur.top().second});
                res = max(res, cur.top().first * (j - cur.top().second));
                prev = cur.top().second;
                cur.pop();
            }
            //if (dp[i][j] != 0)
            cur.push({dp[i][j], prev});
        }
        while (!cur.empty()){
            rect.push_back({cur.top().first, m - cur.top().second});
            res = max(res, cur.top().first * (m - cur.top().second));
            cur.pop();
        }
        sort(rect.begin(), rect.end());
        vector<pair<int, int>> gd;
        for (int j = rect.size() - 1; j >= 0; j--){
            if (gd.size() == 0){
                if (rect[j].first * rect[j].second < res) continue;
                gd.push_back(rect[j]);
            }
            else{
                if (gd.back().first > rect[j].first){
                    gd.push_back(rect[j]);
                }
            }
        }
        reverse(gd.begin(), gd.end());
//        cerr << "\n\n";
//        for (int j =0; j < rect.size(); j++){
//            cerr << rect[j].first << " " << rect[j].second << '\n';
//        }
        int c = gd.size() -1;
        vector<int> pref;
        for (int j = 0; j < gd.size(); j++){
            pref.push_back(gd[j].first * gd[j].second);
            if (j != 0){
                pref.back() = max(pref[j - 1], pref.back());
            }
        }
        int dop = -1;
        for (int j = n - 1; j >= i; j--){
            while (c >= 0 && j < gd[c].first + i - 1){
                dop = max(gd[c].second, dop);
                c--;
            }
            int pr = -1;
            if (c != -1) pr = pref[c];
            if (uk[j] == -1) continue;
            //cerr << i << " " << j << " " << dop * (j - i + 1) << " " << pr << " " << c  << '\n';
            //cerr << uk[j] << " " << mas[j].size() << '\n';
            mas[j][uk[j]].vl = max(mas[j][uk[j]].vl, max(dop * (j - i + 1), pr));
            //cerr << mas[j][uk[j]].vl << '\n';
        }

    }
    vector<int> ans(qq, 0);
    for (int i = 0; i < n; i++){
        if (mas[i].size() == 0) continue;
        int mx  = mas[i].back().vl;
        for (int j = mas[i].size() - 1; j >= 0; j--){
            //cerr << mas[i][j].ind << ' ' << mas[i][j].vl << "\n";
            mx = max(mx, mas[i][j].vl);
            ans[mas[i][j].ind] = max(mx, ans[mas[i][j].ind]);
        }
    }
    for (int i = 0; i < ans.size(); i++){
        cout << ans[i] << '\n';
    }
}
