#include  <vector>
#include <iostream>
#include <algorithm>

using namespace std;

#define int long long

int gcd(int a, int b, int &x, int &y) {
    if (a == 0) {
        x = 0;
        y = 1;
        return b;
    }
    int x0, y0;
    int p = gcd(b % a, a, x0, y0);
    x = y0 - (b / a) * x0;
    y = x0;
    return p;
}


signed main() {
    int a, b, c;
    cin >> a >> b >> c;
    int x0, y0;
    int g = gcd(a, b, x0, y0);
    if (c % g != 0) {
        cout << "Impossible";
        return 0;
    }
    x0 *= c / g;
    y0 *= c / g;
    int k;
    if (x0 >= 0) {
        k = x0 / (b / g);
        x0 -= k * (b / g);
        y0 += k * (a / g);
    } else {
        k = (-x0) / (b / g);
        if ((-x0) % (b / g) != 0) {
            k++;
        }
        x0 += k * (b / g);
        y0 -= k * (a / g);
    }
    cout << x0 << " " << y0;
}