#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

#define int long long
#define MOD 1000000007

int bp(int a, int n) {
    int res = 1;
    while (n) {
        if (n & 1) res = (res * a) % MOD;
        a = (a * a) % MOD;
        n >>= 1;
    }
    return res;
}

int inv(int x) {
    return bp(x, MOD - 2);
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, k;
    cin >> n >> k;
    int x = 0;
    vector<vector<int>> a;
    vector<int> f = {1}, obf = {1};
    int fc = 1;
    a.assign(n + 1, {});
    for (int i = 2; i <= n; i++) {
        if (a[i].size() == 0) {
            x++;
            for (int j = i; j <= n; j += i) {
                a[j].push_back(i);
            }
        }
    }
    for (int i = 1; i < x + k + 5; i++) {
        fc *= i;
        fc %= MOD;
        f.push_back(fc);
        obf.push_back(inv(fc));
    }
    int ans = 0;
    for (int i = 1; i <= n; i++) {
        int c = a[i].size();
        int ii = i;
        int ccc = 0;
        for (int y : a[i]) {
            while (ii % y == 0) {
                ii /= y;
                ccc++;
            }
        }
        int kk = k - ccc;
        if (kk < 0 || x - c < 0) continue;
        int res = (((f[x - c + kk] * obf[x - c]) % MOD) * obf[kk]) % MOD;
        for (int j = 1; j * i <= n; j++) {
            // res--;;
            // cerr << j << " " << i << " " << res << " " << x - c << " " << kk << '\n';
            ans += ((j * i) * res) % MOD;
            ans %= MOD;
        }
    }
//    for (int i = 1; i <= n; i++) {
//        ans += i;
//        ans %= MOD;
//    }
    cout << ans;
}