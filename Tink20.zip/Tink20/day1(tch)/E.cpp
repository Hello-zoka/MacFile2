#include <iostream>
#include <vector>
#include <math.h>
#include <bitset>

using namespace std;

#define int long long

int phi(int n) {
    int res = n;
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            while (n % i == 0) {
                n /= i;
            }
            res -= res / i;
        }
    }
    if (n > 1) res -= res / n;
    return res;
}

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int n, k;
    cin >> n >> k;
    int ans = phi(n);
    for (int i = 2; i <= k; i++) {
        if (ans <= 1) break;
        if (i % 2 == 1) {
            ans = phi(ans);
        }
    }
    cout << ans % 100000007;
    return 0;
}