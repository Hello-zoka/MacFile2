#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;
#define int long long

int n;

int cnt(int a, int b) {
    return n / (a + b) * a + min(a, n % (a + b));
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    string s;
    cin >> s;
    n = s.size();
    vector<int> l0, r1(n);
    int last = -1;
    for (int i = 0; i < n; i++) {
        if (s[i] == '0')last = i;
        l0.push_back(last);
    }
    last = n;
    for (int i = n - 1; i >= 0; i--) {
        if (s[i] == '1') last = i;
        r1[i] = last;
    }
    pair<int, int> ans = {-1, -1};
    for (int k = 1; k <= n; k++) {
        int mxl = 0, mnr = k;
        for (int i = 0; i < n; i += k) {
            int l = i, r = min(n, l + k) - 1;
            if (l <= l0[r] && l0[r] <= r) {
                mxl = max(mxl, l0[r] - l);
            }
            if (l <= r1[l] && r1[l] <= r) {
                mnr = min(mnr, r1[l] - l);
            }
        }
        if (mxl >= mnr) continue;
        int cur = k - mxl - 1;
        // cerr << k << " " << cur << "\n";
        if (ans == make_pair((int) -1, (int) -1) || cnt(ans.first, ans.second) > cnt(mxl + 1, cur))
            ans = {mxl + 1, cur};
    }
    if (ans == make_pair((int) -1, (int) -1)) {
        cout << -1;
    } else {
        for (int i = 0; i < n; i++) {
            if (i % (ans.first + ans.second) < ans.first) {
                cout << '0';
            } else {
                cout << '1';
            }
        }
    }
}