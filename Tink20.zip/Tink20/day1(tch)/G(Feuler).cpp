#include <iostream>
#include <vector>

using namespace std;

#pragma GCC target("avx")
#pragma GCC optimize("Ofast")
#pragma GCC optimize("O3")
int p[100000007];
// int pp[100000007];
int primes[200];
int sz = 0;
//
// int phi (int n) {
//    int result = n;
//    int i = n;
//    if (p[i] == i)
//        return n - 1;
//    if (p[i] != 1)
//        return p[p[i]] * p[n / p[i]];
//
//    for (int i: primes)
//        if (n % i == 0) {
//            while (n % i == 0)
//                n /= i;
//            result -= result / i;
//            break;
//        }
//
//    if (n > 1)
//        result -= result / n;
//    return result;
//
// }
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    long long ans = 1;
    bool b = true;
    int nxt = 100;
    for (int i = 2; i <= n; ++i) {
        // bool bl = false;
        if (p[i] == 0) {
            p[i] = i - 1;
            // pp[i] = i;
            // bl = true;
            primes[sz++] = i;
        }
        bool pl = false;
        // int a = min(i, p[i]);
        for (int ind = 0; ind < sz; ind++) {
            int x = primes[ind];
            if (pl || 1ll * x * i > n) {
                break;
            }
            // pp[x * i] = x;
            if (p[x * i] != 0) break;
            if (i % x == 0) pl = true;
            // cerr << i << " " << x << " " << p[i] <<  "\n";
            if (pl) {
                p[x * i] = p[i] * x;
            } else {
                p[x * i] = p[i] * (x - 1);
            }
        }
        b = true;
        ans += p[i];
        if (i == nxt) {
            nxt += 100;
            cout << ans << " ";
            b = false;
            ans = 0;
        }
    }
    if (b) cout << ans;
    return 0;
}