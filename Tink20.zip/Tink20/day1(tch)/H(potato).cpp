#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

#define int long long
#define MOD 1000000007

// #define ll long long
signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, m;
    cin >> n >> m;
    if (m == 1) {
        cout << n << '\n';
        return 0;
    }
    vector<int> p(1000007);
    for (int i = 2; i < p.size(); i++) {
        if (!p[i]) {
            for (int j = i * i; j < p.size(); j += i) {
                p[j] = 1;
            }
        }
    }
    vector<int> pr;
    for (int i = 2; i * i <= m; i++) {
        if (!p[i] && m % i == 0) {
            pr.push_back(i);
            while (m % i == 0) {
                m /= i;
            }
        }
    }
    if (m != 1) pr.push_back(m);
    int ans = 0;
    for (int i = 1; i < (1 << pr.size()); i++) {
        int k = 0, sm = 1;
        for (int j = 0; j < pr.size(); j++) {
            if (i & (1 << j)) {
                sm *= pr[j];
                k++;
            }
        }
        if (k % 2 == 0) {
            ans -= n / sm;
        } else {
            ans += n / sm;
        }
    }
    cout << n - ans << '\n';
    return 0;
}