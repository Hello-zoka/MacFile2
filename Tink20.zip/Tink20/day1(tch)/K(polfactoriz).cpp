#include <iostream>
#include <vector>
#include <random>
#include <chrono>

using namespace std;

typedef unsigned __int128 big;
vector<int> pr;
mt19937 rnd(chrono::steady_clock().now().time_since_epoch().count());

big gccd(big a, big b) {
    if (a == 0 || b == 0) {
        return a + b;
    }
    return gccd(b, a % b);
}

big pw(big a, big st, big mod) {
    if (st == 0)
        return 1;
    if (st % 2 == 0) {
        big y = pw(a, st / 2, mod);
        return (y * y) % mod;
    } else {
        big y = pw(a, st - 1, mod);
        return (y * a) % mod;
    }
}

int check(big p) {
    if (p < 1000) {
        for (int i = 2; i * i <= p; i++) {
            if (p % i == 0)
                return 0;
        }
        return 1;
    }
    big f = (p - 1);
    int cnt = 0;
    while (f % 2 == 0) {
        cnt++;
        f /= 2;
    }
    for (auto a : pr) {
        if (pw(a, p - 1, p) != 1)
            return 0;
        if (gccd(a, p) != 1)
            return 0;
        vector<big> now;
        big r = pw(a, f, p);
        for (int i = 0; i <= cnt; i++) {
            now.push_back(r);
            r = (r * r) % p;
        }
        for (int i = now.size() - 1; i >= 0; i--) {
            if (now[i] != 1) {
                if (now[i] != (p - 1))
                    return 0;
                break;
            }
        }
    }
    return 1;
}

big abc(big x) {
    if (x < 0) return -x;
    return x;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie();
    cout.tie();
    for (int i = 2; i < 1000; i++) {
        pr.push_back(i);
        for (int j = 2; j < i; j++) {
            if (i % j == 0) {
                pr.pop_back();
                break;
            }
        }
        if (pr.size() >= 30)
            break;
    }
    unsigned long long N;
    cin >> N;
    N--;
    big n = N;
    if (check(n)) {
        cout << 1 << '\n' << N - 1;
        return 0;
    }
    srand(time(0));
    vector<long long> anss;
    for (int i = 2; i < min(n, (big) 1000); i++) {
        while (n % i == 0) {
            anss.push_back(i);
            n /= i;
        }
    }
    while (n != 1 && (!check(n) && !check(n))) {
        big b0 = rnd() % n, g;
        // cout << rand() << '\n';
        // cout << b1;
        vector<big> now;
        int v1 = -1, v2 = -1;
        long long ans;
        while (1) {
            now.push_back(b0);
            b0 = (b0 * b0 + 1) % n;
            now.push_back(b0);
            v2 += 2;
            v1 += 1;
            g = gccd(abc(now[v1] - now[v2]), n);
            if (g == n) break;
            if (g != 1) {
                ans = g;
                while (n % ans == 0) {
                    anss.push_back(ans);
                    n /= ans;
                }
                break;
                // return 0;
            }
        }
    }
    if (n != 1) {
        anss.push_back(n);
    }
    cout << anss.size() << '\n';
    for (int i = 0; i < anss.size(); i++) {
        cout << anss[i] - 1 << " ";
    }
    return 0;
}