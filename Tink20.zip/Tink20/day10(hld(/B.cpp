#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

#define int long long
#define maxn 1000000

vector<vector<int>> lst;
vector<pair<int, int>> ind;
vector<int> a, d;

void dfs(int st) {
    // cerr << st << " ";
    a.push_back(st);
    ind[st].first = a.size() - 1;
    for (int to : lst[st]) {
        d[to] = d[st] + 1;
        dfs(to);
    }
    a.push_back(st);
    ind[st].second = a.size() - 1;
}

int t[4 * maxn];

void upd(int v, int tl, int tr, int pos, int val) {
    if (tl + 1 == tr) {
        t[v] += val;
        return;
    }
    int tm = (tl + tr) / 2;
    if (pos < tm)
        upd(v * 2 + 1, tl, tm, pos, val);
    else
        upd(v * 2 + 2, tm, tr, pos, val);
    t[v] = t[v * 2 + 1] + t[v * 2 + 2];
}

int get(int v, int tl, int tr, int l, int r) {
    if (l >= tr || r <= tl) return 0;
    if (l <= tl && tr <= r) {
        return t[v];
    }
    int tm = (tl + tr) / 2;
    return get(v * 2 + 1, tl, tm, l, min(r, tm)) + get(v * 2 + 2, tm, tr, max(l, tm), r);
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    ind.assign(n, {-1, -1});
    lst.assign(n, {});
    for (int i = 1; i <= n - 1; i++) {
        int x;
        cin >> x;
        x--;
        lst[x].push_back(i);
    }
    d.assign(n, 0);
    dfs(0);
    vector<pair<int, int>> cur;
    for (int i = 0; i < n; i++) {
        cur.push_back({d[i], i});
    }
    sort(cur.begin(), cur.end());
    int q;
    cin >> q;
    vector<pair<int, pair<int, int>>> edg;
    for (int i = 0; i < q; i++) {
        int x, y;
        cin >> x >> y;
        x--;
        edg.push_back({d[x] + y, {x, i}});
    }
    sort(edg.begin(), edg.end());
    int pos = 0;
    vector<int> ans(q, 0);
    vector<int> per;
    for (int i = 0; i < n; i++) {
        upd(0, 0, a.size(), ind[cur[i].second].first, 1);
        per.push_back(i);
        if (i != n - 1 && cur[i + 1].first == cur[i].first) continue;
        while (pos < edg.size() && edg[pos].first <= cur[i].first) {
            if (edg[pos].first == cur[i].first)
                ans[edg[pos].second.second] = get(0, 0, a.size(), ind[edg[pos].second.first].first,
                                                  ind[edg[pos].second.first].second);
            pos++;
        }
        for (int ii = 0; ii < per.size(); ii++) {
            upd(0, 0, a.size(), ind[cur[per[ii]].second].first, -1);
        }
        per.clear();
    }
    for (int i : ans) cout << i << '\n';
}