#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

#define int long long
#define maxn 500006
#define INF 1e15
vector<vector<pair<int, int>>> lst;
vector<pair<int, int>> lr;
vector<int> d;
vector<bool> endd;

int t[4 * maxn], pu[4 * maxn];

void build(int v, int tl, int tr) {
    if (tl + 1 == tr) {
        t[v] = d[tl];
        return;
    }
    int tm = (tl + tr) / 2;
    build(v * 2 + 1, tl, tm);
    build(v * 2 + 2, tm, tr);
    t[v] = min(t[v * 2 + 1], t[v * 2 + 2]);
}

void pus(int v, int tl, int tr) {
    t[v] += pu[v];
    if (tl + 1 != tr) {
        pu[v * 2 + 1] += pu[v];
        pu[v * 2 + 2] += pu[v];
    }
    pu[v] = 0;
}

void upd(int v, int tl, int tr, int l, int r, int val) {
    pus(v, tl, tr);
    if (tl >= r || tr <= l) {
        return;
    }
    if (l <= tl && tr <= r) {
        pu[v] += val;
        pus(v, tl, tr);
        return;
    }
    int tm = (tl + tr) / 2;
    upd(v * 2 + 1, tl, tm, l, min(r, tm), val);
    upd(v * 2 + 2, tm, tr, max(l, tm), r, val);
    t[v] = min(t[v * 2 + 1], t[v * 2 + 2]);
}

int get(int v, int tl, int tr, int l, int r) {
    pus(v, tl, tr);
    if (tl >= r || tr <= l) {
        return INF;
    }
    if (l <= tl && tr <= r) {
        return t[v];
    }
    int tm = (tl + tr) / 2;
    return min(get(v * 2 + 1, tl, tm, l, min(r, tm)), get(v * 2 + 2, tm, tr, max(l, tm), r));
}

void dfs(int st, int pr = -1) {
    for (int i = 0; i < lst[st].size(); i++) {
        int to = lst[st][i].first, c = lst[st][i].second;
        if (to != pr) {
            d[to] = d[st] + c;
            dfs(to);
            lr[st].first = min(lr[st].first, lr[to].first);
            lr[st].second = max(lr[st].second, lr[to].second);
        }
    }
    if (lst[st].size() == 0) {
        lr[st] = {st, st};
        endd[st] = true;
    }
}

vector<vector<pair<int, pair<int, int>>>> q;
vector<int> ans;
int n, qq;

void slv(int st) {
    for (int j = 0; j < q[st].size(); j++) {
        // cerr << "zapros: ";
//        for (int i =0;i < n; i++){
//            cerr << get(0, 0, n, i, i + 1) << ' ';
//        }
        // cerr << '\n';
        // cerr << q[st][j].first << " " << q[st][j].second.first << " " << q[st][j].second.second << '\n';
        // cerr << get(0, 0, n, q[st][j].second.first, q[st][j].second.second + 1);
        ans[q[st][j].first] = get(0, 0, n, q[st][j].second.first, q[st][j].second.second + 1);
    }
    for (int i = 0; i < lst[st].size(); i++) {
        int to = lst[st][i].first, c = lst[st][i].second;
        upd(0, 0, n, 0, n, c);
        upd(0, 0, n, lr[to].first, lr[to].second + 1, -2 * c);
        slv(to);
        upd(0, 0, n, lr[to].first, lr[to].second + 1, 2 * c);
        upd(0, 0, n, 0, n, -c);
    }
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> qq;
    endd.assign(n, false);
    lst.assign(n, {});
    lr.assign(n, {INF, -1});
    d.assign(n, 0);
    for (int i = 0; i < n - 1; i++) {
        int x, c;
        cin >> x >> c;
        x--;
        lst[x].push_back({i + 1, c});
    }
    dfs(0);
    for (int i = 0; i < n; i++) {
        if (!endd[i]) {
            d[i] = INF;
        }
        // cerr << d[i] << " " << lr[i].first << " " << lr[i].second << '\n';
    }
    q.assign(n, {});
    for (int i = 0; i < qq; i++) {
        int v, l, r;
        cin >> v >> l >> r;
        v--;
        l--;
        r--;
        q[v].push_back({i, {l, r}});
    }
    ans.assign(qq, 0);
    build(0, 0, n);
    slv(0);
    for (int i = 0; i < ans.size(); i++) {
        cout << ans[i] << "\n";
    }
    return 0;
}
