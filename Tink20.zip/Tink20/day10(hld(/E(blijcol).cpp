#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// #define int long long
#define logn 18
#define maxn 100007
#define INF 1e9 + 7
int up[maxn][logn];

vector<vector<int>> lst;
int par[maxn];

vector<int> lvl;

int dfs(int v, int siz, int &cent, int p = -1) {
    int cur = 1;
    // cerr << 1;
    // cerr << v << " ";
    for (int to : lst[v]) {
        if (lvl[to] == -1 && to != p) {
            cur += dfs(to, siz, cent, v);
        }
    }
    if (cent == -1 && (2 * cur >= siz || p == -1)) {
        cent = v;
    }
    return cur;
}

void solv(int v, int siz, int dep, int last) {
    int cent = -1;
    // cerr << 1;
    dfs(v, siz, cent);
    lvl[cent] = dep;
    par[cent] = last;
    for (int to : lst[cent]) {
        if (lvl[to] == -1) {
            solv(to, siz / 2, dep + 1, cent);
        }
    }
}

vector<int> uu;
int timee = 0;

vector<int> used, tin, tout, d;
int tim = 0;

void dfss(int st) {
    used[st] = 1;
    for (int i = 1; i < logn; i++) {
        up[st][i] = up[up[st][i - 1]][i - 1];
    }
    tin[st] = tim++;
    for (int to : lst[st]) {
        if (!used[to]) {
            up[to][0] = st;
            d[to] = d[st] + 1;
            dfss(to);
        }
    }
    tout[st] = tim;
}

bool anc(int u, int v) {
    return tin[u] <= tin[v] && tin[v] < tout[u];
}

int lca(int u, int v) {
    if (anc(u, v)) return u;
    if (anc(v, u)) return v;
    for (int l = logn - 1; l >= 0; l--) {
        if (!anc(up[v][l], u))
            v = up[v][l];
    }
    return up[v][0];
}

int dist(int u, int v) {
    return d[u] + d[v] - 2 * d[lca(u, v)];
}

vector<int> cur;

void addv(int v) {
    int st = v;
//     cout << v << " ";
//     cout << "do: ";
//     for (int i =0; i < cur.size(); i++){
//         cout << cur[i] << " ";
//     }
//     cout << "\nposle:";
    while (v != -1) {
        int x = dist(v, st);
        cur[v] = min(cur[v], x);
        if (uu[v] != timee) {
            cur[v] = x;
        }
        uu[v] = timee;
        v = par[v];
    }
//     for (int i =0; i < cur.size(); i++){
//         cout << cur[i] << " ";
//     }
//     cout << '\n';
}

int get(int v) {
    int st = v;
    int ans = INF;
    while (v != -1) {
        if (uu[v] == timee) {
            ans = min(ans, cur[v] + dist(v, st));
        }
        v = par[v];
    }
    return ans;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    lst.assign(n, {});
    for (int i = 0; i < n - 1; i++) {
        int u;
        cin >> u;
        lst[u].push_back(i + 1);
        lst[i + 1].push_back(u);
    }
    tin.assign(n, 0);
    used.assign(n, 0);
    tout.assign(n, 0);
    lvl.assign(n + 5, -1);
    d.assign(n, 0);
    dfss(0);
    solv(0, n, 0, -1);
    vector<pair<int, int>> a;
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        a.push_back({x, i});
    }
    int q;
    cin >> q;
    sort(a.begin(), a.end());
    vector<pair<int, pair<int, int>>> zap;
//     for (int i =0; i < n; i++){
//         cerr << par[i] << " ";
//     }
    //  cerr << " :mas\n";
    for (int i = 0; i < q; i++) {
        int x, y;
        cin >> x >> y;
        zap.push_back({y, {x, i}});
    }
    sort(zap.begin(), zap.end());
    int pos = 0;
    vector<int> ans(q);
    uu.assign(n, -1);
    cur.assign(n, INF);
    for (int i = 0; i < q; i++) {
        if (i == 0 || zap[i - 1].first != zap[i].first) {
            timee++;
            while (pos != a.size() && a[pos].first < zap[i].first) pos++;
            while (pos != a.size() && a[pos].first == zap[i].first) {
                addv(a[pos].second);
                pos++;
            }
        }
        //  cerr <<"col:" << zap[i].first << "\n";
        //  for (int j : cur) cerr << j << " ";
        //  cerr << '\n';
        int x = get(zap[i].second.first);
        if (x == INF) x = -1;
        ans[zap[i].second.second] = x;
    }
    for (int i = 0; i < q; i++) {
        cout << ans[i] << ' ';
    }
    return 0;
}