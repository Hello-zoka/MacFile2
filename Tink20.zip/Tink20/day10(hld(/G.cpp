#include <vector>
#include <algorithm>
#include <iostream>
#include <map>

using namespace std;

#define int long long
#define INF 1e15
vector<int> used;
int tim;
vector<vector<pair<int, int>>> g;
vector<vector<pair<int, int>>> decomp;
int n;
vector<int> sz;

int cent_cal(int v) {
    used[v] = tim;
    int x = 1;
    for (int i = 0; i < g[v].size(); i++) {
        int to = g[v][i].first, cost = g[v][i].second;
        if (used[to] < tim) {
            x += cent_cal(to);
        }
    }
    return sz[v] = x;
}

int cent_fnd(int v, int init) {
    used[v] = tim;
    for (int i = 0; i < g[v].size(); i++) {
        int to = g[v][i].first, cost = g[v][i].second;
        if (used[to] < tim && sz[to] * 2 > init) {
            return cent_fnd(to, init);
        }
    }
    return v;
}

void cent_mark(int v, int centr, int d = 0) {
    used[v] = tim;
    decomp[v].push_back({centr, d});
    for (int i = 0; i < g[v].size(); i++) {
        int to = g[v][i].first, cost = g[v][i].second;
        if (used[to] < tim) {
            cent_mark(to, centr, d + cost);
        }
    }
}

void cent(int v = 1, int ts = INF - 1) {
    tim = INF - ts;
    if (used[v] > ts) return;
    cent_cal(v);
    tim++;
    int x = cent_fnd(v, sz[v]);
    tim++;
    cent_mark(x, x);
    used[x] = ts;
    for (int i = 0; i < g[x].size(); i++) {
        cent(g[x][i].first, ts - 10);
    }
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    decomp.assign(n + 1, {});
    used.assign(n + 1, 0);
    g.assign(n + 1, {});
    sz.assign(n + 1, 0);
    vector<map<int, int> > mark(n + 1);
    for (int i = 1; i < n; i++) {
        int a, b, l;
        cin >> a >> b >> l;
//        a--;
//        b--;
        g[a].push_back({b, l});
        g[b].push_back({a, l});
        mark[i].insert({-INF, 0});
        mark[i].insert({INF, INF});
    }
    mark[0] = mark[1];
    mark[n] = mark[0];
    cent();
    int m;
    cin >> m;
    vector<pair<int, int>> lst;
    for (int i = 0; i < m; i++) {
        int v, t;
        cin >> v >> t;
        lst.push_back({t, v});
    }
    sort(lst.begin(), lst.end());
    for (auto cur : lst) {
        int mx = 0;
        for (auto v : decomp[cur.second]) {
            auto it = mark[v.first].upper_bound(cur.first - v.second);
            it--;
            mx = max(mx, it->second);
        }
        for (auto v : decomp[cur.second]) {
            map<int, int> *curmp = &mark[v.first];
            int val = mx + 1;
            auto tmpx = curmp->insert({cur.first + v.second, val});
            auto it = tmpx.first;
            if (!tmpx.second) {
                it->second = max(it->second, val);
            }
            auto old_it = it--;
            if (old_it->second <= it->second) {
                curmp->erase(old_it);
            } else {
                auto new_iter = old_it;
                new_iter++;
                while (new_iter->second <= old_it->second) {
                    it = new_iter++;
                    curmp->erase(it);
                }
            }
        }
    }
    int ans = 0;
    for (auto x : mark) {
        x.erase(INF);
        ans = max(ans, x.rbegin()->second);
    }
    cout << ans;
    return 0;
}
