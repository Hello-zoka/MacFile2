#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

#define int long long

#define maxn 50001

vector<vector<int>> lst;
vector<int> used, ans;
int s[maxn];
int tim = 0;

int sz(int v, int p = -1) {
    s[v] = 1;
    for (int u : lst[v]) {
        if (u != p && !used[u])
            s[v] += sz(u, v);
    }
    return s[v];
}

int cent(int v, int n, int p) {
    for (int to : lst[v]) {
        if (!used[to] && to != p && s[to] > n / 2) {
            return cent(to, n, v);
        }
    }
    return v;
}

int mx = 0;

void dfs(int v, int p, int d, vector<int> &t) {
    t[d]++;
    mx = max(mx, d + 1);
    for (int to : lst[v]) {
        if (to != p && !used[to]) {
            dfs(to, v, d + 1, t);
        }
    }
}

void solv(int v) {
    sz(v);
    vector<int> d(s[v], 0);
    d[0] = 1;
    int cur = 1;
    for (int to : lst[v]) {
        if (!used[to]) {
            vector<int> t;
            t.assign(s[v] + 2, 0);
            mx = 1;
            dfs(to, v, 1, t);
            for (int i = 0; i < mx; i++) {
                for (int j = 0; j < cur; j++) {
                    ans[j + i] += d[j] * t[i];
                }
            }
            cur = max(cur, mx);
            for (int i = 0; i < mx; i++) {
                d[i] += t[i];
            }
        }
    }
    used[v] = 1;
    for (int to : lst[v]) {
        if (!used[to]) {
            solv(cent(to, v, s[to]));
        }
    }
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    used.assign(n, 0);
    lst.assign(n, {});
    for (int i = 0; i < n - 1; i++) {
        int u, v;
        cin >> u >> v;
        u--;
        v--;
        lst[u].push_back(v);
        lst[v].push_back(u);
    }
    ans.assign(n, 0);
    solv(0);
    for (int i = 1; i < n; i++) {
        cout << ans[i] << "\n";
    }
    return 0;
}
