#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

#define int long long
#define logn 18
#define maxn 100007
int up[maxn][logn];
vector<vector<int>> lst;
vector<int> used, tin, tout;
int tim = 0;

void dfs(int st) {
    used[st] = 1;
    for (int i = 1; i < logn; i++) {
        up[st][i] = up[up[st][i - 1]][i - 1];
    }
    tin[st] = tim++;
    for (int to : lst[st]) {
        if (!used[to]) {
            up[to][0] = st;
            dfs(to);
        }
    }
    tout[st] = tim;
}

bool anc(int u, int v) {
    return tin[u] <= tin[v] && tin[v] < tout[u];
}

int lca(int u, int v) {
    if (anc(u, v)) return u;
    if (anc(v, u)) return v;
    for (int l = logn - 1; l >= 0; l--) {
        if (!anc(up[v][l], u))
            v = up[v][l];
    }
    return up[v][0];
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    while (n != 0) {
        lst.assign(n, {});
        for (int i = 0; i < n - 1; i++) {
            int a, b;
            cin >> a >> b;
            a--;
            b--;
            lst[a].push_back(b);
            lst[b].push_back(a);
        }
        tim = 0;
        used.assign(n, 0);
        tin.assign(n, 0);
        tout.assign(n, 0);
        dfs(0);
        int v = 0;
        int m;
        cin >> m;
        for (int q = 0; q < m; q++) {
            char x;
            cin >> x;
            if (x == '?') {
                int a, b;
                cin >> a >> b;
                a--;
                b--;
                int res = lca(v, a) ^lca(v, b) ^lca(a, b);
                cout << res + 1 << '\n';
            } else {
                cin >> v;
                v--;
            }
        }
        cin >> n;
    }
    return 0;
}