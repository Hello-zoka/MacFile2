#include <iostream>
#include <vector>
#include <algorithm>
#include <bitset>

using namespace std;

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, m, k;
    cin >> n >> m >> k;
    int lst[n][m];
    vector<int> l;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            char x;
            cin >> x;
            lst[i][j] = x - '0';
        }
    }
//    for (int i =0; i < m; i++){
//        cerr << lst2[i] << '\n';
//    }
    int ans = 0;
    if (n < m) {
        for (int i = 0; i < m; i++) {
            int x = 0;
            for (int j = 0; j < n; j++) {
                x |= (lst[j][i] << j);
            }
            l.push_back(x);
        }
        for (int i = 0; i < (1 << n); i++) {
            int kk = k;
            int res = 0;
            vector<int> a(n + 1, 0);
            kk -= __builtin_popcount(i);
            for (int j = 0; j < m; j++) {
                int cnt = -n;
                int x = __builtin_popcount(l[j] ^ i);
                res += x;
                cnt += 2 * x;
                if (cnt < 0) a[-cnt]++;
            }
            // kk -= __builtin_popcount(i);
            if (kk < 0) continue;
            // sort(a.begin(), a.end());
            // reverse(a.begin(), a.end());
            for (int j = n; kk > 0 && j >= 0; j--) {
                for (int x = 0; x < a[j] && kk > 0; x++) {
                    kk--;
                    res += j;
                }
            }
            ans = max(res, ans);
        }
    } else {
        for (int i = 0; i < n; i++) {
            int x = 0;
            for (int j = 0; j < m; j++) {
                x |= (lst[i][j] << j);
            }
            l.push_back(x);
            // cerr << x << " ";
        }
        for (int i = 0; i < (1 << m); i++) {
            int kk = k;
            int res = 0;
            vector<int> a(m + 1, 0);
            kk -= __builtin_popcount(i);
            for (int j = 0; j < n; j++) {
                int cnt = -m;
                int x = __builtin_popcount(l[j] ^ i);
                res += x;
                cnt += 2 * x;
                // cerr << cnt << " " << j << " " << i << '\n';
                if (cnt < 0) {
                    a[-cnt]++;
                }
            }
            if (kk < 0) continue;
//            cerr << i << " ";
//            for (int j = 0; j  < m + 1; j++){
//                cerr << a[j] << " ";
//            }
//            cerr << '\n';
            // sort(a.begin(), a.end());
            // reverse(a.begin(), a.end());
            for (int j = m; kk > 0 && j >= 0; j--) {
                for (int x = 0; x < a[j] && kk > 0; x++) {
                    kk--;
                    res += j;
                }
            }
            ans = max(res, ans);
        }
    }
    cout << ans;
    return 0;
}
