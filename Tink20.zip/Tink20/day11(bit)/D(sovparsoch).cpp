#include <vector>
#include <algorithm>
#include <iostream>
#include <unordered_map>

using namespace std;

#define int long long
#define MOD 1000000007
vector<vector<int>> lst;
unordered_map<int, int> tab;
int n, m;

int gen(int cur) {
    if (tab.count(cur)) {
        return tab[cur];
    }
//    if (__builtin_popcount(cur) == n) {
//        return 1;
//    }
    int l = 0;
    for (int i = __builtin_popcount(cur) / 2; i < n; i++) {
        if (!((cur >> i) & 1)) {
            l = i;
            break;
        }
    }
    cur |= (1 << l);
    int ans = 0;
    for (int j = 0; j < lst[l].size(); j++) {
        if ((cur >> lst[l][j]) & 1) continue;
        int r = (1 << lst[l][j]);
        cur |= r;
        ans += gen(cur);
        ans %= MOD;
        cur ^= r;
    }
    cur ^= (1 << l);
    tab[cur] = ans;
    // cerr << cur << " " << ans << '\n';
    return ans;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
//    int x = 30;
//    vector<pair<int, int>> cock;
//    for (int i = 1; i <= 30; i++){
//        for (int j = i + 1; j <= 30; j++){
//            cock.push_back({i, j});
//        }
//    }
//    cout << x << " " << cock.size() << '\n';
//    for (int i = 0; i < cock.size(); i++){
//        cout << cock[i].first << ' ' << cock[i].second << '\n';
//    }
    cin >> n >> m;

    tab.rehash(1346269 * 2 + 7);
    tab[(1 << n) - 1] = 1;
    lst.assign(n, {});
    for (int i = 0; i < m; i++) {
        int a, b;
        cin >> a >> b;
        a--;
        b--;
        if (a > b) swap(a, b);
        lst[a].push_back(b);
    }
    cout << gen(0);
    //cerr << tab.size();
}
