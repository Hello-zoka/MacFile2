#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#include <map>

//#define ALP 28
using namespace std;
//#define int long long
const int INF = 1000000007;
const int maxn = 20002;
vector<int> ans;
vector<int> pi;
map<pair<int, int>, int> bl;
vector<int> cnt;
int BL;

int n, m;
int cntr = 0;
int uk = 0;

bool sr(int i, int j) {
    if (i == n || j == n) return false;
    if (i > j) swap(i, j);
    int x, y;
    int bl1 = 0, bl2 = 0;
    if (i < n) {
        x = i + 1;
    } else {
        x = i - n;
        bl1 = 1;
    }
    if (j < n) {
        y = j + 1;
        bl2 = 1;
    } else {
        y = j - n;
    }
    if (bl.count({i, j}) != 0) {
        if (bl[{i, j}] == 1) return true;
        return false;
    }
    //cerr << y << " " << BL << '\n';
    if (!bl2 && y > uk + 1) {
        cntr = 5;
    }
    while (cntr == 5) {
        if (BL >= uk) {
            cout << "$ " << ans[uk] << endl;
        } else {
            cout << "$ " << cnt[n] << endl;
        }
        cntr = 0;
        uk++;
        if (!bl2 && y > uk + 1) {
            cntr = 5;
        }
    }
    cntr++;


    if (!bl1 && !bl2) {
        cout << "s " << x << " t " << y << endl;
    } else if (bl1) {
        cout << "t " << x << " t " << y << endl;
    } else {
        cout << "s " << x << " s " << y << endl;
    }
    string s;
    cin >> s;
    if (s == "Yes") {
        bl[{i, j}] = 1;
        return true;
    }
    bl[{i, j}] = 0;
    return false;
}


void prefix_function(int pos) {
    if (pi[pos - 1] == -1) {
        prefix_function(pos - 1);
    }
    int j = pi[pos - 1];
    while (j > 0 && !sr(pos, j)) {
        if (pi[j - 1] == -1) prefix_function(j - 1);
        j = pi[j - 1];
    }
    if (sr(pos, j)) ++j;
    pi[pos] = j;
    cnt[j]++;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m;
    cnt.assign(n + 1, 0);
    pi.assign(n + m + 1, -1);
    pi[0] = 0;
    pi[n] = 0;
    BL = -1;
    ans.assign(m, -1);
    for (int i = 1; i <= m + n; i++) {
        prefix_function(i);
        if (i > n) {
            ans[i - n - 1] = cnt[n];
            BL = i - n - 1;
        }
    }
    for (int i = uk; i < m; i++) {
        cout << "$ " << ans[i] << endl;
    }
    return 0;
}
//aba
//abacaba