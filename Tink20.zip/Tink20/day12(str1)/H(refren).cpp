#include <iostream>
#include <vector>
#include <algorithm>
#include <stack>

#define ALP 12
using namespace std;
#define int long long

struct e {
    int w, h, ind;
};

vector<int> blcp(vector<int> s, vector<int> suf) {
    int n = s.size();
    vector<int> lcp(n), pos(n);
    for (int i = 0; i < n; i++) {
        pos[suf[i]] = i;
    }
    int k = 0;
    for (int i = 0; i < n; i++) {
        if (k > 0) k--;
        if (pos[i] == n - 1) {
            lcp[n - 1] = -1;
            k = 0;
            continue;
        } else {
            int j = suf[pos[i] + 1];
            while (max(i + k, j + k) < n && s[i + k] == s[j + k])
                k++;
            lcp[pos[i]] = k;
        }
    }
    return lcp;
}

signed main() {
    int N, m;
    cin >> N >> m;
    vector<int> s;
    for (int i = 0; i < N; i++) {
        int x;
        cin >> x;
        s.push_back(x);
    }
    s.push_back(-1);
    int n = s.size();
    vector<int> c(n), new_c(n), suf(n), new_suf(n), starts(max(n, (long long) ALP + 1));
    for (int i = 0; i < n; i++) {
        suf[i] = i;
        if (i != n - 1) {
            starts[s[i] - 1 + 2]++;
            c[i] = s[i] - 1 + 1;
        } else {
            c[i] = 0;
            starts[1]++;
        }
    }
    for (int i = 0; i < ALP; ++i)
        starts[i + 1] += starts[i];
    for (int l = 0; l < n; l = max((long long) 1, l << 1)) {
        for (int i = 0; i < n; i++) {
            int pos = (suf[i] - l + n) % n;
            new_suf[starts[c[pos]]++] = pos;
        }
        int type = 0;
        for (int i = 0; i < n; i++) {
            if ((i == 0) || (c[new_suf[i - 1]] != c[new_suf[i]]) ||
                (c[(new_suf[i - 1] + l) % n] != c[(new_suf[i] + l) % n]))
                starts[type++] = i;
            new_c[new_suf[i]] = type - 1;
        }
        swap(c, new_c);
        swap(suf, new_suf);
    }
    vector<int> p(n);
    vector<int> lcp = blcp(s, suf);

    stack<e> st;
    int mh = n - 1;
    int mw = 1, start = 0;
    for (int i = 1; i < n; i++) {
        int x = 1;
        while (!st.empty() && lcp[i] <= st.top().h) {
            e a = st.top();
            st.pop();
            x += a.w;
            if (x * a.h > mw * mh) {
                mw = x;
                mh = a.h;
                start = suf[a.ind];
            }
        }
        if (st.empty() || lcp[i] > st.top().h)
            st.push({x, lcp[i], i});
    }
    cout << mh * mw << '\n';
    cout << mh << '\n';
    for (int i = start; i - start < mh; i++) {
        cout << s[i] << " ";
    }

    return 0;
}
