#include <iostream>
#include <vector>
#include <algorithm>
#include <set>

#define ALP 28
using namespace std;
#define int long long
#define INF 1000000007
vector<pair<int, int>> t;

pair<int, int> mx(pair<int, int> a, pair<int, int> b) {
    return {min(a.first, b.first), max(a.second, b.second)};
}

pair<int, int> get(int v, int tl, int tr, int l, int r) {
    if (tr <= l || r <= tl) {
        return {INF, -INF};
    }
    if (l <= tl && tr <= r) {
        return t[v];
    }
    int m = (tl + tr) / 2;
    return mx(get(v * 2, tl, m, l, r), get(v * 2 + 1, m, tr, l, r));
}

signed main() {
    string s;
    cin >> s;
    s += '&';
    int n = s.size();
    vector<int> c(n), new_c(n), suf(n), new_suf(n), starts(max(n, (int) ALP + 1));
    for (int i = 0; i < n; i++) {
        suf[i] = i;
        if (i != n - 1) {
            starts[s[i] - 'a' + 2]++;
            c[i] = s[i] - 'a' + 1;
        } else {
            c[i] = 0;
            starts[1]++;
        }
    }
    for (int i = 0; i < ALP; ++i)
        starts[i + 1] += starts[i];
    for (int l = 0; l < n; l = max((int) 1, l << 1)) {
        for (int i = 0; i < n; i++) {
            int pos = (suf[i] - l + n) % n;
            new_suf[starts[c[pos]]++] = pos;
        }
        int type = 0;
        for (int i = 0; i < n; i++) {
            if ((i == 0) || (c[new_suf[i - 1]] != c[new_suf[i]]) ||
                (c[(new_suf[i - 1] + l) % n] != c[(new_suf[i] + l) % n]))
                starts[type++] = i;
            new_c[new_suf[i]] = type - 1;
        }
        swap(c, new_c);
        swap(suf, new_suf);
    }
    vector<int> lcp(n), pos(n);
    for (int i = 0; i < n; i++) {
        pos[suf[i]] = i;
    }
    int k = 0;
    for (int i = 0; i < n; i++) {
        if (k > 0) k--;
        if (pos[i] == n - 1) {
            lcp[n - 1] = -1;
            k = 0;
            continue;
        } else {
            int j = suf[pos[i] + 1];
            while (max(i + k, j + k) < n && s[i + k] == s[j + k])
                k++;
            lcp[pos[i]] = k;
        }
    }
    n--;
    vector<pair<int, int>> lst;
    for (int i = 0; i < n - 1; ++i) {
        lst.push_back({lcp[i + 1], i + 1});
    }
    k = 1;
    while (k < n) k <<= 1;
    t.assign(k * 2, {INF, -INF});
    for (int i = 0; i < n; i++) {
        t[k + i] = {suf[i + 1], suf[i + 1]};
    }
    for (int i = k - 1; i > 0; i--) {
        t[i] = mx(t[i * 2], t[i * 2 + 1]);
    }
    int ans = n;
    sort(lst.begin(), lst.end());
    set<int> cur = {0, n};
    for (int i = 0; i < lst.size(); i++) {
        pair<int, int> p = lst[i];
        int posi = p.second;
        int pr = *--cur.lower_bound(posi);
        int nx = *cur.lower_bound(posi);
        pair<int, int> a = get(1, 0, k, pr, nx);
        ans = max(ans, p.first * p.first + (a.second - a.first + p.first));
        cur.insert(posi);
    }
    cout << ans;
    return 0;
}
