#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

#define int long long
vector<vector<int>> g, gr;
vector<int> used;
vector<int> ord, comp;

void dfs1(int st) {
    used[st] = 1;
    for (int to : g[st]) {
        if (!used[to]) {
            dfs1(to);
        }
    }
    ord.push_back(st);
}

void dfs2(int st) {
    used[st] = 1;
    comp.push_back(st);
    for (int to : gr[st]) {
        if (!used[to]) {
            dfs2(to);
        }
    }
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, m, h;
    cin >> n >> m >> h;
    vector<int> lst;
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        lst.push_back(x);
    }
    vector<pair<int, int>> edg;
    g.assign(n, {});
    gr.assign(n, {});
    for (int i = 0; i < m; i++) {
        int a, b;
        cin >> a >> b;
        a--;
        b--;
        if ((lst[a] + 1) % h == lst[b]) {
            edg.push_back({a, b});
            g[a].push_back(b);
            gr[b].push_back(a);
        }
        if ((lst[b] + 1) % h == lst[a]) {
            edg.push_back({b, a});
            g[b].push_back(a);
            gr[a].push_back(b);
        }
    }
    used.assign(n, 0);
    for (int i = 0; i < n; i++) {
        if (!used[i]) {
            dfs1(i);
        }
    }
    used.assign(n, 0);
    int cnt = 0;
    vector<int> col(n, -1);
    vector<vector<int>> cm;
    for (int i = 0; i < n; i++) {
        int v = ord[n - i - 1];
        if (!used[v]) {
            dfs2(v);
            cm.push_back({});
            for (int j : comp) {
                col[j] = cnt;
                cm.back().push_back(j);
            }
            cnt++;
            comp.clear();
        }
    }
    vector<vector<int>> nw(cnt);
    for (int i = 0; i < edg.size(); i++) {
        if (col[edg[i].first] != col[edg[i].second])
            nw[col[edg[i].first]].push_back(col[edg[i].second]);
    }
    int mx = n + 2, ind = 0;
    for (int i = 0; i < cnt; i++) {
        if (nw[i].size() == 0) {
            if (mx > cm[i].size()) {
                mx = cm[i].size();
                ind = i;
            }
        }
    }
    cout << mx << '\n';
    for (int i : cm[ind]) {
        cout << i + 1 << " ";
    }
}
