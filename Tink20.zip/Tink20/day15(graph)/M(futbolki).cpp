#include <vector>
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <math.h>

using namespace std;

#define ll long long

struct e {
    int u, v;
    ll c;
};

ll dist(int x1, int y1, int x2, int y2) {
    return 1LL * (x2 - x1) * (x2 - x1) + 1LL * (y1 - y2) * (y1 - y2);
}

vector<e> edg;
vector<int> mt;
int n, m;
int k = 0;
vector<vector<int>> lst;
vector<int> used;
int timer = -1, timer2 = -1;

bool try_kun(int st) {
    if (used[st] == timer) return false;
    used[st] = timer;
    for (int to : lst[st]) {
        if (mt[to] == -1) {
            mt[to] = st;
            return true;
        }
    }
    for (int to : lst[st]) {
        if (try_kun(mt[to])) {
            mt[to] = st;
            return true;
        }
    }
    return false;
}

int prevv = 0;
vector<ll> curr;

bool ch(ll x) {
    // lst.assign(n, {});
    int ii;
    if (prevv < edg.size() && edg[prevv].c <= x) {
        for (ii = prevv; ii < edg.size() && edg[ii].c <= x; ii++) {
            lst[edg[ii].u].push_back(edg[ii].v);
        }
    } else {
        for (ii = prevv - 1; edg[ii].c > x; ii--) {
            lst[edg[ii].u].pop_back();
        }
        ii++;
    }
//    cerr <<'o';
//    cerr << ii << " " << edg.size() << " " << '\n';
//    cerr << x << " " << edg[ii - 1].c << '\n';
    prevv = ii;
    mt.assign(k, -1);
    vector<char> used1(n);
    for (int i = 0; i < n; ++i)
        for (int to : lst[i])
            if (mt[to] == -1) {
                mt[to] = i;
                used1[i] = true;
                break;
            }
    for (int i = 0; i < n; i++) {
        if (used1[i]) continue;
        timer++;
        if (!try_kun(i)) return false;
    }
    int cnt = 0;
    for (int i = 0; i < k; i++) {
        if (mt[i] != -1) {
            cnt++;
        }
    }
    // cerr << x << " " << cnt << " ";
    return cnt == n;
}


int bin() {
    int l = -1, r = curr.size() - 1;
    while (l + 1 != r) {
        int mi = (l + r) / 2;
        if (ch(curr[mi]))
            r = mi;
        else
            l = mi;
    }
    return r;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m;
    used.assign(n, -1);
    lst.assign(n, {});
    vector<pair<int, int>> cord;
    for (int i = 0; i < n; i++) {
        int x, y;
        cin >> x >> y;
        cord.push_back({x, y});
    }
    for (int i = 0; i < m; i++) {
        int x, y, a;
        cin >> x >> y >> a;
        for (int kk = 0; kk < a; kk++) {
            for (int j = 0; j < n; j++) {
                edg.push_back({j, k, dist(cord[j].first, cord[j].second, x, y)});
            }
            k++;
        }
    }
    sort(edg.begin(), edg.end(), [&](e i, e j) { return i.c < j.c; });
    for (int i = 0; i < edg.size(); i++) {
        if (i == 0 || edg[i].c != edg[i - 1].c) {
            curr.push_back(edg[i].c);
            //cerr << curr.back() << " ";
        }
    }
    int res = bin();
    // cerr << res;
    cout << setprecision(15) << fixed << sqrt(curr[res]);
}
