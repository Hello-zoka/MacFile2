#include <iostream>
#include <vector>
#include <algorithm>
#include <deque>

using namespace std;

#define int long long
const int INF = 100000000007;
vector<vector<char>> lst;
vector<vector<int>> dp;
int n, m;
vector<int> p1 = {0, -1, 0, 1};
vector<int> p2 = {-1, 0, 1, 0};

void bfs(int x, int y) {
    deque<pair<int, pair<int, int>>> q;
    q.push_back({0, {x, y}});
    while (!q.empty()) {
        pair<int, pair<int, int>> cur = q.front();
        q.pop_front();
        int a = cur.first, xx = cur.second.first, yy = cur.second.second;
        if (a < dp[xx][yy]) {
            dp[xx][yy] = a;
            for (int i = 0; i < 4; i++) {
                int ii = xx + p1[i], jj = p2[i] + yy;
                if (ii < 0 || ii >= n || jj < 0 || jj >= m || lst[ii][jj] == '*') continue;
                if (i == 0) {
                    q.push_back({a + 1, {ii, jj}});
                } else {
                    q.push_front({a, {ii, jj}});
                }
            }
        }
    }
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m;
    int r, c;
    cin >> r >> c;
    r--;
    c--;
    int a, b;
    cin >> a >> b;
    // l - r = c => l = r  + c => minimize l
    for (int i = 0; i < n; i++) {
        lst.push_back({});
        for (int j = 0; j < m; j++) {
            char x;
            cin >> x;
            lst[i].push_back(x);
        }
    }
    dp.assign(n, vector<int>(m, INF));
    bfs(r, c);
    int ans = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (dp[i][j] > a || j - c + dp[i][j] > b) continue;
            ans++;
        }
    }
    cout << ans;
    return 0;
}
