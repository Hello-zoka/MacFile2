#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

#define int long long

vector<int> used, is_dt;
vector<int> tin, fup;
vector<vector<int>> lst;
int tim = 0;
int ch = 0;

void dfs(int st, int pr = -1) {
    used[st] = 1;
    tin[st] = fup[st] = tim++;
    for (int to : lst[st]) {
        if (to == pr) continue;
        if (used[to]) {
            fup[st] = min(fup[st], tin[to]);
        } else {
            dfs(to, st);
            fup[st] = min(fup[st], fup[to]);
            if (fup[to] >= tin[st] && pr != -1) {
                is_dt[st] = 1;
            }
            ch++;
        }
    }
    if (pr == -1 && ch >= 2) is_dt[st] = 1;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, m;
    cin >> n >> m;
    lst.assign(n + m, {});

    for (int i = 0; i < m; i++) {
        int a, b, c;
        cin >> a >> b >> c;
        a--;
        b--;
        c--;
        lst[a].push_back(n + i);
        lst[b].push_back(n + i);
        lst[c].push_back(n + i);
        lst[n + i].push_back(a);
        lst[n + i].push_back(b);
        lst[n + i].push_back(c);
    }
    used.assign(n + m, 0);
    is_dt.assign(n + m, 0);
    tin.assign(n + m, 0);
    fup.assign(n + m, 0);
    dfs(0);
    vector<int> ans;
    for (int i = n; i < n + m; i++) {
        if (is_dt[i]) {
            ans.push_back(i - n + 1);
        }
    }
    cout << ans.size() << '\n';
    for (int i : ans) {
        cout << i << " ";
    }
}
