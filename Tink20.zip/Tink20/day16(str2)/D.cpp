#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <cstring>

using namespace std;
#define int long long
#define maxn 200007
struct node {
    int ln, link;
    map<char, int> go;
};
node suf[maxn];
int sz = 0, last = 0;


void add(char s) {
    int nlast = sz++;
    suf[nlast].ln = suf[last].ln + 1;
    int p = last;
    while (p != -1 && suf[p].go.count(s) == 0) {
        suf[p].go[s] = nlast;
        p = suf[p].link;
    }
    if (p == -1) {
        suf[nlast].link = 0;
    } else {
        int q = suf[p].go[s];
        if (suf[p].ln + 1 == suf[q].ln) {
            suf[nlast].link = q;
        } else {
            int clone = sz++;
            suf[clone] = suf[q];
            suf[clone].ln = suf[p].ln + 1;
            while (p != -1 && suf[p].go[s] == q) {
                suf[p].go[s] = clone;
                p = suf[p].link;
            }
            suf[q].link = suf[nlast].link = clone;
        }
    }
    last = nlast;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    char x;
    suf[0].ln = 0;
    suf[0].link = -1;
    sz++;
    while (cin >> x) {
        string s;
        cin >> s;
        if (x == '?') {
            int v = 0;
            int bl = 1;
            for (int i = 0; i < s.size(); i++) {
                s[i] = tolower(s[i]);
                if (suf[v].go.count(s[i]) == 0) {
                    bl = 0;
                    break;
                }
                v = suf[v].go[s[i]];
            }
            if (bl == 1) {
                cout << "YES\n";
            } else {
                cout << "NO\n";
            }
        } else {
            for (int i = 0; i < s.size(); i++) {
                s[i] = tolower(s[i]);
                //cerr << s[i] << " ";
                add(s[i]);
            }
        }
    }
    return 0;
}
