#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;

#define int long long

const int ALP = 28;
const int MX = 200007;
int ans = 0;
vector<int> s;
int ln[MX], lin[MX], to[MX][ALP], cnt[MX];

int cur = 0, sz = 2, l = 0;

int get(int v) {
    while (s[cur - ln[v] - 2] != s[cur - 1]) {
        v = lin[v];
    }
    return v;
}

void add(int c) {
    s[cur++] = c;
    l = get(l);
    if (!to[l][c]) {
        ln[sz] = ln[l] + 2;
        lin[sz] = to[get(lin[l])][c];
        to[l][c] = sz++;
    }
    l = to[l][c];
    cnt[l]++;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    string ss;
    cin >> ss;
    s.assign(ss.size() + 2, 0);
    s[cur++] = -1;
    lin[0] = 1;
    ln[1] = -1;
    for (int i = 0; i < ss.size(); i++) {
        add((int)(ss[i] - 'a'));
        cout << sz - 2 << " ";
    }
    return 0;
}
