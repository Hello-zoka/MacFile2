#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <cstring>

using namespace std;
#define ALP 11
#define ll long long

struct avt {
    int ln, link;
    int nxt[ALP];
    ll res;
};
int sz = 1, last = 0;
vector<int> used;
avt st[1300007];


void add(char c) {
    int cur = sz++, p;
    st[cur].ln = st[last].ln + 1;
    for (p = last; p != -1 && !st[p].nxt[c - '0']; p = st[p].link) {
        st[p].nxt[c - '0'] = cur;
    }
    if (p == -1) {
        st[cur].link = 0;
    } else {
        int q = st[p].nxt[c - '0'];
        if (st[p].ln + 1 == st[q].ln) {
            st[cur].link = q;
        } else {
            int qcop = sz++;
            st[qcop].ln = st[p].ln + 1;
            st[qcop].link = st[q].link;
            // ans += st[qcop].ln - st[st[qcop].link].ln;
            for (int i = 0; i < ALP; i++) {
                st[qcop].nxt[i] = st[q].nxt[i];
            }
            while (p != -1 && st[p].nxt[c - '0'] == q) {
                st[p].nxt[c - '0'] = qcop;
                p = st[p].link;
            }
            // ans -= st[q].ln - st[st[q].link].ln;
            st[q].link = st[cur].link = qcop;
            // ans += st[q].ln - st[st[q].link].ln;
        }
    }
    // ans += st[cur].ln - st[st[cur].link].ln;
    last = cur;
}

vector<int> uuused;

ll dfs(int v) {
    ll res = 0;
    for (int i = 0; i < ALP; i++) {
        if (st[v].nxt[i] != 0) {
            // char chr = '0' + i;
            // cerr << chr;
            if (uuused[st[v].nxt[i]] == -1) {
                // cur += chr;
                // st[v].glub = st[st[v].nxt[i]].glub + 1;
                res += dfs(st[v].nxt[i]);
                // cur.pop_back();
            } else {
                res += uuused[st[v].nxt[i]];
                // st[v].glub = st[st[v].nxt[i]].glub + 1;
            }
        }
    }
    // cerr << 1;
    if (used[v]) res += 1;
    uuused[v] = res;
    st[v].res = res;
    return res;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, m;
    cin >> n >> m;
    st[0].ln = 0;
    st[0].res = 0;
    st[0].link = -1;
    for (int i = 0; i < ALP; i++) {
        st[0].nxt[i] = 0;
    }
    string s = "";
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        x--;
        s += x + '0';
    }
    for (int i = 0; i < s.size(); i++) {
        add(s[i]);
    }
    used.assign(sz + 2, 0);
    while (last != 0) {
        used[last] = 1;
        last = st[last].link;
    }
    uuused.assign(sz + 2, -1);

    dfs(0);
    ll mx = 0, ln, ind;
    string answ = "";
    for (int i = 1; i < sz; i++) {
        if (mx < (ll) st[i].res * st[i].ln) {
            ln = st[i].ln;
            mx = st[i].res * st[i].ln;
            ind = i;
        }
    }
    int xx = 0;
    while (!used[ind]) {
        for (int i = 0; i < ALP; i++) {
            if (st[ind].nxt[i]) {
                ind = st[ind].nxt[i];
                break;
            }
        }
        xx++;
    }
    cout << mx << '\n' << ln << '\n';

    for (int i = n - ln - xx; i < n; i++) {
        answ += s[i];
    }
    for (int i = 0; i < ln; i++) {
        int xx = answ[i] - '0';
        cout << xx + 1 << " ";
    }
    return 0;
}
