#include <iostream>
#include <vector>
#include <stdio.h>
#include <algorithm>

using namespace std;
#define int long long
#define maxn 100000

vector<int> mt[4 * maxn];
vector<int> lst;

void build(int v, int tl, int tr) {
    if (tl + 1 == tr) {
        mt[v].push_back(lst[tl]);
        return;
    }
    int tm = (tl + tr) / 2;
    build(v * 2 + 1, tl, tm);
    build(v * 2 + 2, tm, tr);
    mt[v].resize(mt[v * 2 + 1].size() + mt[v * 2 + 2].size());
    merge(mt[2 * v + 1].begin(), mt[2 * v + 1].end(),
          mt[2 * v + 2].begin(), mt[2 * v + 2].end(),
          mt[v].begin());
}

int get(int v, int tl, int tr, int l, int r, int x, int y) {
    if (tl >= r || tr <= l) {
        return 0;
    }
    if (l <= tl && tr <= r) {
        int a = lower_bound(mt[v].begin(), mt[v].end(), x) - mt[v].begin();
        int b = upper_bound(mt[v].begin(), mt[v].end(), y) - mt[v].begin();
        // cerr << a << ' ' << b << '\n';
        return b - a;
    }
    int tm = (tl + tr) / 2;
    return get(v * 2 + 1, tl, tm, l, r, x, y) + get(v * 2 + 2, tm, tr, l, r, x, y);
}

signed main() {
    int n, m;
    cin >> n >> m;
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        lst.push_back(x);
    }
    build(0, 0, n);

    for (int i = 0; i < m; i++) {
        int l, r, x, y;
        cin >> l >> r >> x >> y;
        l--;
        cout << get(0, 0, n, l, r, x, y) << "\n";
    }

    return 0;
}