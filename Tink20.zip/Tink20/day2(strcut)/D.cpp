#include <iostream>
#include <vector>
#include <stdio.h>
#include <algorithm>

using namespace std;
#define int long long
#define maxn 150000

vector<int> mt[4 * maxn], sm[4 * maxn];
vector<int> lst;

void build(int v, int tl, int tr) {
    if (tl + 1 == tr) {
        mt[v].push_back(lst[tl]);
        sm[v].push_back(lst[tl]);
        return;
    }
    int tm = (tl + tr) / 2;
    build(v * 2 + 1, tl, tm);
    build(v * 2 + 2, tm, tr);
    mt[v].resize(mt[v * 2 + 1].size() + mt[v * 2 + 2].size());
    merge(mt[2 * v + 1].begin(), mt[2 * v + 1].end(),
          mt[2 * v + 2].begin(), mt[2 * v + 2].end(),
          mt[v].begin());
    sm[v].resize(mt[v].size());
    sm[v][0] = mt[v][0];
    for (int i = 1; i < (int) sm[v].size(); i++) {
        sm[v][i] = sm[v][i - 1] + mt[v][i];
    }
}

int get(int v, int tl, int tr, int l, int r, int x) {
    if (tl >= r || tr <= l) {
        return 0;
    }
    if (l <= tl && tr <= r) {
        int a = lower_bound(mt[v].begin(), mt[v].end(), x + 1) - mt[v].begin();
        // int b = upper_bound(mt[v].begin(), mt[v].end(), y) - mt[v].begin();
        // cerr << a << ' ' << b << '\n';
        if (a == 0) return 0;
        return sm[v][a - 1];
    }
    int tm = (tl + tr) / 2;
    return get(v * 2 + 1, tl, tm, l, r, x) + get(v * 2 + 2, tm, tr, l, r, x);
}

signed main() {
    int n, m;
    cin >> n >> m;
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        lst.push_back(x);
    }
    build(0, 0, n);

    for (int i = 0; i < m; i++) {
        int l, r;
        cin >> l >> r;
        l--;
        int cur = 0;
        while (true) {
            int x = get(0, 0, n, l, r, cur + 1);
            if (x > cur) {
                cur = x;
            } else {
                break;
            }
        }
        cout << cur + 1 << '\n';
    }

    return 0;
}