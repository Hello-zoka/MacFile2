#include <iostream>
#include <vector>
#include <stdio.h>
#include <algorithm>

using namespace std;
#define int long long
#define maxn 100070

int t[4 * maxn], mx[4 * maxn], mn[4 * maxn], pus[4 * maxn];

int gcd(int a, int b) {
    if (b == 0) return a;
    return gcd(b, a % b);
}

void pu(int v, int tl, int tr) {
    if (pus[v] == 0) return;
    if (tl + 1 == tr) {
        t[v] = pus[v];
        mx[v] = t[v];
        mn[v] = t[v];
        pus[v] = 0;
    } else if (pus[v] != 0) {
        t[v] = (tr - tl) * pus[v];
        mx[v] = pus[v];
        mn[v] = pus[v];
        pus[v * 2 + 1] = pus[v];
        pus[v * 2 + 2] = pus[v];
        pus[v] = 0;
    }
}

int get(int v, int tl, int tr, int l, int r) {
    // cerr << tl << " " << tr << " " << l << " " << r << '\n';
    pu(v, tl, tr);
    if (tl >= r || tr <= l) {
        return 0;
    }
    if (l <= tl && tr <= r) {
        return t[v];
    }
    int tm = (tl + tr) / 2;
    return get(v * 2 + 1, tl, tm, l, min(r, tm)) + get(v * 2 + 2, tm, tr, max(l, tm), r);
}

void upd(int v, int tl, int tr, int l, int r, int val) {
    pu(v, tl, tr);
    if (l >= tr || r <= tl || mn[v] >= val) {
        return;
    }
    if (l <= tl && tr <= r && mx[v] <= val) {
        pus[v] = val;
        // cerr << '\n';
        // cerr << tl << " " << tr << " updated with val: " << val << "    range was:  " << l << " " << r << '\n';
        pu(v, tl, tr);
        return;
    }
    int tm = (tl + tr) / 2;
    upd(v * 2 + 1, tl, tm, l, min(r, tm), val);
    upd(v * 2 + 2, tm, tr, max(l, tm), r, val);
    t[v] = t[v * 2 + 1] + t[v * 2 + 2];
    mn[v] = min(mn[v * 2 + 1], mn[v * 2 + 2]);
    mx[v] = max(mx[v * 2 + 1], mx[v * 2 + 2]);
}

signed main() {
    int n, k;
    cin >> n >> k;
    while (n != 0 || k != 0) {
        for (int i = 0; i < 4 * n; i++) {
            mx[i] = 0;
            mn[i] = 0;
            t[i] = 0;
            pus[i] = 0;
        }
        for (int q = 0; q < k; q++) {
            char x;
            cin >> x;
            // cerr << t[0] << " ";
            if (x == '?') {
                int l, r;
                cin >> l >> r;
                l--;
                int sm = get(0, 0, n, l, r);
                int g = gcd(sm, r - l);
                // cerr << sm << "\n";
                if ((r - l) == g)
                    cout << sm / g << '\n';
                else
                    cout << sm / g << "/" << (r - l) / g << '\n';
            } else {
                int l, r, val;
                cin >> l >> r >> val;
                l--;
                upd(0, 0, n, l, r, val);
            }
        }
        cin >> n >> k;
    }
    return 0;
}