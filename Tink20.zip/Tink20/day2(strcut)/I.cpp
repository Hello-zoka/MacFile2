#include <iostream>
#include <vector>
#include <stdio.h>
#include <algorithm>

using namespace std;
#define int long long
#define maxn 200070

int t[4 * maxn], pus[4 * maxn];

void pu(int v, int tl, int tr) {
    if (pus[v] == 0) return;
    if (tl + 1 == tr) {
        t[v] += pus[v];
        pus[v] = 0;
    } else if (pus[v] != 0) {
        t[v] += pus[v];
        pus[v * 2 + 1] += pus[v];
        pus[v * 2 + 2] += pus[v];
        pus[v] = 0;
    }
}

int get(int v, int tl, int tr, int l, int r) {
    // cerr << tl << " " << tr << " " << l << " " << r << '\n';
    pu(v, tl, tr);
    if (tl >= r || tr <= l) {
        return 0;
    }
    if (l <= tl && tr <= r) {
        return t[v];
    }
    int tm = (tl + tr) / 2;
    return max(get(v * 2 + 1, tl, tm, l, min(r, tm)), get(v * 2 + 2, tm, tr, max(l, tm), r));
}

void upd(int v, int tl, int tr, int l, int r, int val) {
    pu(v, tl, tr);
    if (l >= tr || r <= tl) {
        return;
    }
    if (l <= tl && tr <= r) {
        pus[v] += val;
        // cerr << '\n';
        // cerr << tl << " " << tr << " updated with val: " << val << "    range was:  " << l << " " << r << '\n';
        pu(v, tl, tr);
        return;
    }
    int tm = (tl + tr) / 2;
    upd(v * 2 + 1, tl, tm, l, min(r, tm), val);
    upd(v * 2 + 2, tm, tr, max(l, tm), r, val);
    t[v] = max(t[v * 2 + 1], t[v * 2 + 2]);
}

signed main() {
    int n;
    cin >> n;
    vector<int> a, b;
    vector<pair<int, int>> lst;
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        a.push_back(x);
        lst.push_back({x, i});
    }
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        b.push_back(x);
        lst.push_back({x, n + i});
    }
    sort(lst.begin(), lst.end());
    reverse(lst.begin(), lst.end());
    int k = 0;
    vector<int> ans;
    ans.assign(n + 1, 0);
    for (int i = 0; i < lst.size(); i++) {
        int pos = lst[i].second;
        if (pos >= n) {
            upd(0, 0, n + 1, 0, pos - n + 1, 1);
        } else {
            upd(0, 0,  n + 1, pos + 1, n + 1, 1);
        }
        int x = get(0, 0, n + 1, 0, n + 1);
        // cerr << x << " ";
        while (k < ans.size() && k <= x) {
            ans[k] = lst[i].first;
            k++;
        }
    }
    for (int i = 1; i <= n; i++) {
        cout << ans[i] << " ";
    }
    return 0;
}