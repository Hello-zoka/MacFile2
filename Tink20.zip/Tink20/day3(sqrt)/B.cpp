#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;
#pragma GCC diagnostic error "-std=c++11"
#pragma GCC target("avx")
#pragma GCC optimize(3)
#pragma GCC optimize("Ofast")
#pragma GCC optimize("inline")
#pragma GCC optimize("-fgcse")
#pragma GCC optimize("-fgcse-lm")
#pragma GCC optimize("-fipa-sra")
#pragma GCC optimize("-ftree-pre")
#pragma GCC optimize("-ftree-vrp")
#pragma GCC optimize("-fpeephole2")
#pragma GCC optimize("-ffast-math")
#pragma GCC optimize("-fsched-spec")
#pragma GCC optimize("unroll-loops")
#pragma GCC optimize("-falign-jumps")
#pragma GCC optimize("-falign-loops")
#pragma GCC optimize("-falign-labels")
#pragma GCC optimize("-fdevirtualize")
#pragma GCC optimize("-fcaller-saves")
#pragma GCC optimize("-fcrossjumping")
#pragma GCC optimize("-fthread-jumps")
#pragma GCC optimize("-funroll-loops")
#pragma GCC optimize("-fwhole-program")
#pragma GCC optimize("-freorder-blocks")
#pragma GCC optimize("-fschedule-insns")
#pragma GCC optimize("inline-functions")
#pragma GCC optimize("-ftree-tail-merge")
#pragma GCC optimize("-fschedule-insns2")
#pragma GCC optimize("-fstrict-aliasing")
#pragma GCC optimize("-fstrict-overflow")
#pragma GCC optimize("-falign-functions")
#pragma GCC optimize("-fcse-skip-blocks")
#pragma GCC optimize("-fcse-follow-jumps")
#pragma GCC optimize("-fsched-interblock")
#pragma GCC optimize("-fpartial-inlining")
#pragma GCC optimize("no-stack-protector")
#pragma GCC optimize("-freorder-functions")
#pragma GCC optimize("-findirect-inlining")
#pragma GCC optimize("-fhoist-adjacent-loads")
#pragma GCC optimize("-frerun-cse-after-loop")
#pragma GCC optimize("inline-small-functions")
#pragma GCC optimize("-finline-small-functions")
#pragma GCC optimize("-ftree-switch-conversion")
#pragma GCC optimize("-foptimize-sibling-calls")
#pragma GCC optimize("-fexpensive-optimizations")
#pragma GCC optimize("-funsafe-loop-optimizations")
#pragma GCC optimize("inline-functions-called-once")
#pragma GCC optimize("-fdelete-null-pointer-checks")
// #define int long long
#define maxn 200001
int g[maxn], lst[maxn];


const int sz = 5000;

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;

    for (int i = 0; i < n; i++) {
        cin >> lst[i];
        g[i] = lst[i];
    }
    for (int i = 0; i < n; i += sz) {
        sort(g + i, g + min(n, sz + i));
    }
    int q;
    cin >> q;
    for (int t = 0; t < q; t++) {
        int x;
        cin >> x;
        if (x == 1) {
            int a, k;
            cin >> a >> k;
            a--;
            int l = (a / sz) * sz, r = min(n, l + sz);
            int p = lower_bound(g + l, g + r, lst[a]) - g;
            if (lst[a] < k) {
                while (p < r - 1 && g[p + 1] < k) {
                    g[p] = g[p + 1];
                    p++;
                }
                g[p] = k;
            } else {
                while (p > l && g[p - 1] > k) {
                    g[p] = g[p - 1];
                    p--;
                }
                g[p] = k;
            }
            lst[a] = k;
        } else {
            int m, a, b;
            cin >> m >> a >> b;
            a--;
            int l = (a / sz) * sz, r = min(n, l + sz);
            int ans = 0;
            if (a > (l + r) / 2 || r >= b) {
                for (int i = a; i < min(r, b); i++) {
                    if (lst[i] < m) ans--;
                }
            } else {
                ans -= lower_bound(g + l, g + r, m) - g - l;
                for (int i = l; i < a; i++) {
                    if (lst[i] < m)
                        ans++;
                }
            }
            if (r < b) {
                int r2 = (b / sz) * sz;
                while (r < r2) {
                    ans -= lower_bound(g + r, g + r + sz, m) - g - r;
                    r += sz;
                }
                l = r;
                r = min(l + sz, n);
                if (b < (l + r) / 2) {
                    for (int i = l; i < b; i++) {
                        if (lst[i] < m) {
                            ans--;
                        }
                    }
                } else {
                    ans -= lower_bound(g + l, g + r, m) - g - l;
                    for (int i = b; i < r; i++) {
                        if (lst[i] < m) {
                            ans++;
                        }
                    }
                }
            }
            ans = max(0, ans * 2 + b - a);
            cout<< ans << '\n';
        }
    }
}