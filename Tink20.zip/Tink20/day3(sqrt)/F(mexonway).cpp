#include <iostream>
#include <vector>
#include <math.h>
#include <algorithm>

using namespace std;

vector<int> t;
int n, lg = 0;
vector<int> cnt;

void upd(int pos, int val) {
    for (int i = pos; i <= n; i = (i | (i + 1))) {
        t[i] += val;
    }
}

void inc(int x, int val) {
    // cout <<x << " " << val << '\n';
    if (x >= cnt.size() || x < 0) return;
    if (val == 1) {
        if (cnt[x] == 0) upd(x, -1);
        cnt[x]++;
    } else {
        if (cnt[x] == 1) upd(x, 1);
        cnt[x]--;
    }
}

int find_last_less(int s) {
    // cout << '\n';
    int k = -1;
//    for (int i =0; i < t.size(); i++){
//        cerr << t[i];
//    }
//    cerr << '\n';
    for (int l = lg; l >= 0; l--) {
        if (k + (1 << l) < n && t[k + (1 << l)] < s) {
            // cout << "wtf";
            k += (1 << l);
            s -= t[k];
        }
    }
    return k;
}

vector<pair<int, int>> ind;
vector<vector<pair<int, int>>> g;
vector<int> cost;
const int k = 1000;
vector<int> cur;

void dfs(int st, int pr = -1) {
    ind[st].first = cur.size();
    cur.push_back(st);
    for (int i = 0; i < g[st].size(); i++) {
        int to = g[st][i].first;
        if (to != pr) {
            cost[to] = g[st][i].second;
            dfs(to, st);
        }
    }
    ind[st].second = cur.size();
    cur.push_back(st);
}

struct e {
    int l, r, ind;
};

bool operator<(const e &a, const e &b) {
    if (a.l / k == b.l / k) return a.r < b.r;
    return a.l < b.l;
}

signed main() {
    int q;
    cin >> n >> q;
    g.assign(n, {});
    t.assign(n + 3, 0);
    for (int i = 0; i <= n; i++) {
        upd(i, 1);
    }
    for (int i = 0; i < n - 1; i++) {
        int a, b, c;
        cin >> a >> b >> c;
        a--;
        b--;
        g[a].push_back({b, c});
        g[b].push_back({a, c});
    }
    int cc = 1;
    while (cc < n) {
        cc *= 2;
        lg++;
    }
    lg++;
    vector<e> edg;
    ind.assign(n, {-1, -1});
    cost.assign(n, -1);
    dfs(0);
//    for (int i =0; i < cur.size(); i++){
//        cerr << cur[i] << " ";
//    }
//    cerr << "\n";
//    for (int i =0; i < n; i++){
//        cerr << cost[i] << " ";
//    }
//    cerr << '\n';
    for (int qq = 0; qq < q; qq++) {
        int u, v;
        cin >> u >> v;
        u--;
        v--;
        e a;
        a.ind = qq;
        if (ind[v].second > ind[u].first && ind[u].second > ind[v].second) {
            a.l = ind[u].first + 1;
            a.r = ind[v].first;
        } else if (ind[u].second > ind[v].first && ind[v].second > ind[u].second) {
            a.l = ind[v].first + 1;
            a.r = ind[u].first;
        } else {
            a.l = min(ind[u].second, ind[v].second);
            a.r = max(ind[u].first, ind[v].first);
        }
        // cerr << a.l << " " << a.r << '\n';
        edg.push_back(a);
        // cerr << a.l << " " << a.r << '\n';
    }
    sort(edg.begin(), edg.end());
    int l = 0, r = 0;
    vector<int> used, ans;
    ans.assign(q, 0);
    used.assign(n, 0);
    cnt.assign(n, 0);
    for (int qq = 0; qq < q; qq++) {
        int a = edg[qq].l, b = edg[qq].r;
        // cerr << a << " " << b << " " << edg[qq].ind << '\n';
        while (b > r) {
            if (cost[cur[r + 1]] != -1) {
                if (used[cur[r + 1]] == 1) {
                    inc(cost[cur[r + 1]], -1);
                } else {
                    inc(cost[cur[r + 1]], 1);
                }
            }
            used[cur[r + 1]]++;
            r++;
        }
        while (b < r) {
            if (cost[cur[r]] != -1) {
                if (used[cur[r]] == 2) {
                    inc(cost[cur[r]], 1);
                } else {
                    inc(cost[cur[r]], -1);
                }
            }
            used[cur[r]]--;
            r--;
        }
        while (a > l) {
            if (cost[cur[l]] != -1) {
                if (used[cur[l]] == 2) {
                    inc(cost[cur[l]], 1);
                } else {
                    inc(cost[cur[l]], -1);
                }
            }
            used[cur[l]]--;
            l++;
        }
        while (a < l) {
            if (cost[cur[l - 1]] != -1) {
                if (used[cur[l - 1]] == 1) {
                    inc(cost[cur[l - 1]], -1);
                } else {
                    inc(cost[cur[l - 1]], 1);
                }
            }
            used[cur[l - 1]]++;
            l--;
        }
        ans[edg[qq].ind] = find_last_less(1) + 1;
    }
    for (int i = 0; i < q; i++) {
        cout << ans[i] << '\n';
    }
    return 0;
}