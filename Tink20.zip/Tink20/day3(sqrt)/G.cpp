#include <iostream>
#include <vector>
#include <math.h>
#include <map>
#include <algorithm>

using namespace std;

#define int long long
#define maxn 100007
#define INF 1e9
int cnt[maxn], cnt_[4 * maxn];

void ch(int v, int to) {
    cnt[v]--;
    cnt[to]++;
}

void add(int v) {
    ch(cnt_[v], cnt_[v] + 1);
    cnt_[v]++;
}

void del(int v) {
    ch(cnt_[v], cnt_[v] - 1);
    cnt_[v]--;
}

int get() {
    return find(cnt + 1, cnt + maxn, 0) - cnt;
}

struct e {
    int t, l, r, ind;
};
const int k = 1000;

bool operator<(const e &a, const e &b) {
    if (a.t / k == b.t / k) {
        if (b.l / k == a.l / k) return a.r < b.r;
        return a.l < b.l;
    }
    return a.t < b.t;
}

signed main() {
    int n, q;
    cin >> n >> q;
    vector<int> lst;
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        lst.push_back(x);
    }
    map<int, int> comp;
    auto com = [&](int v) {
        if (comp.count(v)) {
            return comp[v];
        } else {
            int r = comp.size();
            return comp[v] = r;
        }
    };
    for (int i = 0; i < lst.size(); i++) {
        lst[i] = com(lst[i]);
    }
    vector<e> zap, upd;
    vector<int> ans;
    vector<int> tmp = lst;
    for (int qq = 0; qq < q; qq++) {
        int a, b, c;
        cin >> a >> b >> c;
        b--;
        c--;
        if (a == 1) {
            ans.push_back(-1);
            e x = {(int) upd.size() - 1, b, c, (int) ans.size() - 1};
            zap.push_back(x);
        } else {
            c = com(c + 1);
            e x = {tmp[b], b, c, qq};
            tmp[b] = c;
            upd.push_back(x);
        }
    }
    int ll = 0, rr = 0, tt = -1;
    add(lst[0]);
    sort(zap.begin(), zap.end());
    for (auto x : zap) {
        int t = x.t, l = x.l, r = x.r;
        while (ll > l) {
            add(lst[--ll]);
        }
        while (rr < r) {
            add(lst[++rr]);
        }
        while (ll < l) {
            del(lst[ll++]);
        }
        while (rr > r) {
            del(lst[rr--]);
        }
        while (t < tt) {
            if (ll <= upd[tt].l && rr >= upd[tt].l) {
                del(upd[tt].r);
                add(upd[tt].t);
            }
            lst[upd[tt].l] = upd[tt].t;
            tt--;
        }
        while (t > tt) {
            tt++;
            if (ll <= upd[tt].l && rr >= upd[tt].l) {
                del(upd[tt].t);
                add(upd[tt].r);
            }
            lst[upd[tt].l] = upd[tt].r;
        }
        ans[x.ind] = get();
    }
    for (int i : ans) {
        cout << i << "\n";
    }
    return 0;
}