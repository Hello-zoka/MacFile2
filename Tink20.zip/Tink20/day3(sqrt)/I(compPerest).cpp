#include <vector>
#include <algorithm>
#include <vector>
#include <iostream>

using namespace std;

#define int long long

int k = 1000;

vector<int> ob(vector<int> &a) {
    vector<int> res(a.size());
    for (int i = 0; i < a.size(); i++) {
        res[a[i] - 1] = i + 1;
    }
    return res;
}

vector<int> um(vector<int> &a, vector<int> &b) {
    vector<int> res(a.size());
    for (int i = 0; i < a.size(); i++) {
        res[i] = b[a[i] - 1];
    }
    return res;
}

signed main() {
    int t;
    cin >> t;
    for (int qqq = 0; qqq < t; qqq++) {
        int n, m;
        cin >> n >> m;
        vector<vector<int>> lst;
        vector<vector<int>> pr;
        for (int i = 0; i < n; i++) {
            lst.push_back({});
            pr.push_back({});
            for (int j = 0; j < m; j++) {
                int x;
                cin >> x;
                pr[i].push_back(x);
                lst[i].push_back(x);
            }
        }
        if (m < k) {
            for (int i = 1; i < n; i++) {
                pr[i] = um(pr[i - 1], lst[i]);
            }
            int q;
            cin >> q;
            for (int qq = 0; qq < q; qq++) {
                int l, r;
                cin >> l >> r;
                l--;
                r--;
                int res = 0;
                if (l == 0) {
                    for (int j = 0; j < m; j++) {
                        res += (j + 1) * (pr[r][j]);
                    }
                    cout << res << '\n';
                    continue;
                }
                vector<int> a = ob(pr[l - 1]);
                a = um(a, pr[r]);
                for (int j = 0; j < m; j++) {
                    // cerr << a[j] << " ";
                    res += (j + 1) * (a[j]);
                }
                // cerr << '\n';
                cout << res << '\n';
            }
        } else {
            vector<vector<int>> ans;
            for (int i = 0; i < n; i++) {
                ans.push_back({});
                for (int j = 0; j < n; j++) {
                    ans[i].push_back(-1);
                }
            }
            for (int i = 0; i < n; i++) {
                vector<int> cur;
                for (int j = 0; j < m; j++) {
                    cur.push_back(j + 1);
                }
                for (int j = i; j < n; j++) {
                    // cerr << 2;
                    cur = um(cur, lst[j]);
                    int res = 0;
                    for (int p = 0; p < m; p++) {
                        res += (p + 1) * cur[p];
                    }
                    ans[i][j] = res;
                }
            }
            int q;
            cin >> q;
            for (int qq = 0; qq < q; qq++) {
                int l, r;
                cin >> l >> r;
                l--;
                r--;
                cout << ans[l][r] << '\n';
            }
        }
    }
}