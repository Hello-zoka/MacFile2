#include <iostream>
#include <vector>
#include <math.h>

using namespace std;

#define ll long long

int main() {
    ll n, m;
    cin >> n >> m;
    ll k = 1000;
    vector<vector<ll>> lst;
    vector<pair<ll, ll>> e;
    lst.assign(n, {});
    for (ll i = 0; i < m; i++) {
        ll a, b;
        cin >> a >> b;
        lst[--a].push_back(--b);
        lst[b].push_back(a);
        e.push_back({a, b});
    }
    vector<ll> heavy;
    heavy.assign(n, -1);
    ll cnt = 0;
    vector<vector<ll>> mat;
    for (ll i = 0; i < n; i++) {
        if (lst[i].size() > k) {
            heavy[i] = cnt;
            cnt++;
            vector<ll> per;
            per.assign(n, 0);
            mat.push_back(per);
            for (ll j = 0; j < lst[i].size(); j++) {
                mat[mat.size() - 1][lst[i][j]] = 1;
            }
        }
    }
    vector<vector<ll>> h_mat;
    for (ll i = 0; i < cnt; i++) {
        h_mat.push_back({});
        for (ll j = 0; j < cnt; j++) {
            h_mat[i].push_back(0);
        }
    }
    for (ll i = 0; i < n; i++) {
        if (heavy[i] != -1) {
            for (ll j = 0; j < lst[i].size(); j++) {
                ll to = lst[i][j];
                if (heavy[to] != -1) {
                    h_mat[heavy[i]][heavy[to]] = 1;
                    h_mat[heavy[to]][heavy[i]] = 1;
                }
            }
        }
    }
    vector<ll> used;
    used.assign(n, 0);
    ll cnt1 = 0, cnt2 = 0, cnt3 = 0;
    for (ll i = 0; i < m; i++) {
        ll fr = e[i].first, to = e[i].second;
        if (heavy[fr] == -1 && heavy[to] == -1) {
            for (ll j = 0; j < lst[fr].size(); j++) {
                used[lst[fr][j]] = 1;
            }
            for (ll j = 0; j < lst[to].size(); j++) {
                if (used[lst[to][j]] && (heavy[lst[to][j]] == -1))
                    cnt1++;
            }
            for (ll j = 0; j < lst[fr].size(); j++) {
                used[lst[fr][j]] = 0;
            }
        } else if (heavy[fr] != -1 && heavy[to] != -1) {
            for (int j = 0; j < cnt; j++) {
                if (h_mat[heavy[fr]][j] && h_mat[heavy[to]][j])
                    cnt2++;
            }
        } else {
            if (heavy[fr] == -1)
                swap(fr, to);
            for (ll j = 0; j < lst[to].size(); j++) {
                if (mat[heavy[fr]][lst[to][j]])
                    cnt3++;
            }
        }
    }
    cout << (cnt1) / 3 + (cnt2) / 3 + (cnt3) / 2;
    return 0;
}