#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;
#define int long long
#define INF 1e14
vector<vector<int>> dp, r;
vector<string> ans;

void build(int i, int j, string cur = "") {
    if (i > j) return;
    if (i == j) {
        ans[i] = cur;
        return;
    }
    build(i, r[i][j], cur + '0');
    build(r[i][j] + 1, j, cur + '1');
}

signed main() {
    int n;
    cin >> n;
    vector<int> lst;
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        lst.push_back(x);
    }
    vector<int> pr;
    int sm = 0;
    for (int i = 0; i < n; i++) {
        sm += lst[i];
        pr.push_back(sm);
    }
    for (int i = 0; i <= n; i++) {
        dp.push_back({});
        r.push_back({});
        for (int j = 0; j <= n; j++) {
            if (i == j) {
                dp[i].push_back(0);
                r[i].push_back(i);
            } else {
                r[i].push_back(0);
                dp[i].push_back(INF);
            }
        }
    }
    for (int k = 1; k < n; k++) {
        for (int i = 0; i + k < n; i++) {
            int j = i + k;
            for (int pos = r[i][j - 1]; pos <= r[i + 1][j]; pos++) {
                int x = pr[j];
                if (i != 0) {
                    x -= pr[i - 1];
                }
                if (dp[i][j] > dp[i][pos] + dp[pos + 1][j] + x) {
                    r[i][j] = pos;
                }
                dp[i][j] = min(dp[i][j], dp[i][pos] + dp[pos + 1][j] + x);
            }
        }
    }
//    for (int i =0; i < n; i++){
//        for (int j =0; j < n; j++){
//            cerr << r[i][j] << " ";
//        }
//        cerr << '\n';
//    }
    ans.assign(n, "");
    build(0, n - 1);
    for (string ii : ans) {
        cout << ii << "\n";
    }
    return 0;
}