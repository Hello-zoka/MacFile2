#include  <vector>
#include <algorithm>
#include <iostream>

using namespace std;

#define int long long
#define double long double
#define maxn 200007
#define INF 1e10
int n, K;
vector<int> lst;
int ans = -1;

int solve(double k) {
    int res = 0;
    vector<double> dp(n, 0);
    vector<int> pos(30, -1), prev(n, -1);
    int rr = 0;
    vector<int> cr;
    for (int i = 0; i < n; i++) {
        int x = 0;
        rr |= lst[i];
        prev[i] = -1;
        dp[i] = rr - k;
        if (i != 0 && dp[i - 1] - k + lst[i] > dp[i]) {
            dp[i] = dp[i - 1] - k + lst[i];
            prev[i] = i - 1;
        }

        sort(cr.begin(), cr.end());
        reverse(cr.begin(), cr.end());
        int tek = lst[i];
        // cerr << "Cr: ";
        for (int j = 0; j < cr.size(); j++) {
            tek |= lst[cr[j]];
            double xx = 0;
            if (cr[j] != 0) {
                xx = dp[cr[j] - 1];
            }
            if (dp[i] < tek - k + xx) {
                prev[i] = cr[j] - 1;
            }
            dp[i] = max(dp[i], tek - k + xx);
            // cerr << cr[j] << "  tek:" << tek << " x:" << x << " ";
        }
        // cerr << '\n';
        // cerr << "dp[" << i << "] = " << dp[i] << '\n';
        cr.clear();
        for (int j = 0; j < 30; j++) {
            if ((lst[i] & (1 << j))) {
                pos[j] = i;
            }
            if (pos[j] != -1)
                cr.push_back(pos[j]);
        }
    }
    int ccc = n - 1;
    while (ccc != -1) {
        res++;
        ccc = prev[ccc];
    }
//     for (int i = 0;i < n; i++) {
//         cerr << prev[i] <<" ";
//     }
//     cerr << '\n';
//     cerr << dp[n - 1] << " " << res << " " << k << '\n';
    ans = (int) (dp[n - 1] + K * k + 0.49999999);
    if (res == K) {
        cout << ans;
        exit(0);
    }
    return res;
}

void bin() {
    double l = -1, r = INF;
    for (int i = 0; i < 60; i++) {
        double m = (l + r) / 2;
        if (solve(m) >= K) {
            l = m;
        } else {
            r = m;
        }
    }
}


signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> K;
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        lst.push_back(x);
    }
    bin();
    cout << (int) (ans);
    return 0;
}