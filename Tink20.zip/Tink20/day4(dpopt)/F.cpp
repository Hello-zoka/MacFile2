#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

#define int long long
#define maxn 100007

int cur = 0, L = 0, R = -1;
int cnt[maxn];
int dp[maxn][25];
vector<int> lst;

int get(int l, int r) {
    // cout << l << " " << r << '\n';
    while (R < r) {
        cur += cnt[lst[++R]]++;
    }
    while (L > l) {
        cur += cnt[lst[--L]]++;
    }
    while (R > r) {
        cur -= --cnt[lst[R--]];
    }
    while (L < l) {
        cur -= --cnt[lst[L++]];
    }
    return cur;
}

void rel(int k, int l, int r, int lop, int rop) {
    if (l > r) return;
    int m = (l + r) / 2;
    int op = lop, mx = min(rop + 1, m);
    int ans = dp[op][k - 1] + get(op + 1, m);
    for (int i = op; i < mx; i++) {
        int x = dp[i][k - 1] + get(i + 1, m);
        if (x < ans) {
            ans = x;
            op = i;
        }
    }
    dp[m][k] = ans;
    rel(k, l, m - 1, lop, op);
    rel(k, m + 1, r, op, rop);
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, k;
    cin >> n >> k;
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        lst.push_back(x);
    }
    for (int i = 0; i < n; i++) {
        dp[i][0] = get(0, i);
    }
    for (int i = 1; i <= k; i++) {
        rel(i, i, n - 1, i - 1, n - 1);
    }
//    for (int i = 0; i < n; i++) {
//        for (int j = 0; j <= k; j++) {
//            cerr << dp[i][j] << " ";
//        }
//        cerr << '\n';
//    }
    cout << dp[n - 1][k - 1];
    return 0;
}