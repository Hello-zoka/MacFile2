include <vector>
#include <iostream>
#include <algorithm>

using namespace std;

#define int long long
const int maxn = 1 << 18;
#define INF 1e18 + 1e9
const int maxm = 400007;

struct line {
    int k, b;

    line() {}

    line(int kk, int bb) : k(kk), b(bb) {}

    int val(int x) {
        return k * x + b;
    }
};

int inter(const line &a, const line &b) {
    int p1 = a.b - b.b, p2 = b.k - a.k;
    if (p2 < 0) {
        p2 *= -1;
        p1 *= -1;
    }
    if (p1 < 0) return p1 / p2;
    return (p1 + p2 - 1) / p2;
}

struct CHT {
    int ptr;
    vector<int> point;
    vector<line> lst;

    CHT() {}

    CHT(vector<line> &a) {
        ptr = 0;
        for (line &l : a) {
            while (!point.empty() && point.back() >= inter(lst.back(), l)) {
                point.pop_back();
                lst.pop_back();
            }
            if (!lst.empty()) {
                point.push_back(inter(lst.back(), l));
            }
            lst.push_back(l);
        }
    }

    int get(int x) {
        if (lst.empty()) return INF;
        while (ptr < point.size() && point[ptr] <= x) {
            ptr++;
        }
        return lst[ptr].val(x);
    }
};

CHT cht[2 * maxn];
vector<line> lst[2 * maxn];

int get(int v, int tl, int tr, int l, int r, int x) {
    if (tl >= r || tr <= l) {
        return INF;
    }
    if (l <= tl && tr <= r) {
        return cht[v].get(x);
    }
    int tm = (tl + tr) / 2;
    return min(get(v * 2, tl, tm, l, min(tm, r), x), get(v * 2 + 1, tm, tr, max(l, tm), r, x));
}

struct piz {
    int x, a, ind;
};
struct pep {
    int x, ind;
};

int n, m;
piz pizz[maxn];
int to[maxn];
pep peps[maxm];
vector<int> forb[maxm];
int ans[maxm];


signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m;
    for (int i = 0; i < n; i++) {
        cin >> pizz[i].x >> pizz[i].a;
        pizz[i].ind = i;
    }
    for (int i = 0; i < m; i++) {
        cin >> peps[i].x;
        peps[i].ind = i;
        int k;
        cin >> k;
        forb[i].resize(k);
        for (int j = 0; j < k; j++) {
            cin >> forb[i][j];
            forb[i][j]--;
        }
    }
    sort(pizz, pizz + n, [](const auto &u, const auto &v) { return u.x < v.x; });
    for (int i = 0; i < n; i++) {
        to[pizz[i].ind] = i;
        lst[maxn + i].push_back(line(-2 * pizz[i].x, pizz[i].a + pizz[i].x * pizz[i].x));
    }
    // cerr << 23;
    for (int i = maxn - 1; i > 0; i--) {
        lst[i].reserve(lst[2 * i].size() + lst[2 * i + 1].size());
        for (line &l : lst[2 * i]) {
            lst[i].push_back(l);
        }
        for (line &l : lst[2 * i + 1]) {
            lst[i].push_back(l);
        }
    }
    for (int i = 1; i < maxn + n; i++) {
        cht[i] = CHT(lst[i]);
    }
    sort(peps, peps + m, [](const auto &u, const auto &v) { return u.x < v.x; });
    for (int i = 0; i < m; i++) {
        vector<int> &cur = forb[peps[i].ind];
        for (auto &ind : cur) {
            ind = to[ind];
        }
        cur.push_back(-1);
        cur.push_back(n);
        sort(cur.begin(), cur.end());
        int res = INF;
        for (int j = 0; j < cur.size() - 1; j++) {
            int l = cur[j] + 1, r = cur[j + 1];
            res = min(res, get(1, 0, maxn, l, r, peps[i].x) + peps[i].x * peps[i].x);
        }
        ans[peps[i].ind] = res;
    }
    for (int i = 0; i < m; i++) {
        cout << ans[i] << '\n';
    }
    return 0;
}