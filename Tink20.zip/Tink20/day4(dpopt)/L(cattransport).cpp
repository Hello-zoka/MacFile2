#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

#define int long long
#define INF 1e14

struct line {
    int m, c;

    line(int m, int c) : m(m), c(c) {}

    int val(int x) {
        return m * x + c;
    }
};

vector<line> st;
int cur;

bool ok(line &l1, line &l2, line &l3) {
    int b1 = l1.m - l2.m, a1 = l2.c - l1.c;
    if (b1 < 0) {
        a1 *= -1;
        b1 *= -1;
    }
    int b2 = l2.m - l3.m, a2 = l3.c - l2.c;
    if (b2 < 0) {
        b2 *= -1;
        a2 *= -1;
    }
    return a1 * b2 < b1 * a2;
}

void add(int m, int c) {
    line l(m, c);
    while (st.size() >= 2 && !ok(st[st.size() - 2], st[st.size() - 1], l)) {
        st.pop_back();
    }
    st.push_back(l);
}

int get(int x) {
    if (st.empty()) return 0;
    while (cur + 1 < st.size() && st[cur].val(x) >= st[cur + 1].val(x)) cur++;
    return st[cur].val(x);
}

signed main() {
    int n, m, p;
    cin >> n >> m >> p;
    vector<int> lst, a;
    for (int i = 0; i < n - 1; i++) {
        int x;
        cin >> x;
        lst.push_back(x);
        if (i != 0) {
            lst[i] += lst[i - 1];
        }
    }
    for (int i = 0; i < m; i++) {
        int h, t;
        cin >> h >> t;
        if (h != 1)
            t -= lst[h - 2];
        a.push_back(t);
    }
    sort(a.begin(), a.end());

    vector<int> pr, b(m, INF);
    for (int i = 0; i < m; i++) {
        pr.push_back(a[i]);
        if (i != 0) pr[i] += pr[i - 1];
    }
    vector<int> dp(m, INF);
    for (int i = 0; i < p; i++) {
        cur = 0;
        st.clear();
        for (int j = 0; j < m; j++) {
            if (j == 0) {
                add(-j, 0);
            } else {
                add(-j, pr[j - 1] + b[j - 1]);
            }
            dp[j] = a[j] * (j + 1) - pr[j] + get(a[j]);
        }
        for (int i = 0; i < m; i++) b[i] = dp[i];
    }
    cout << dp[m - 1];
}