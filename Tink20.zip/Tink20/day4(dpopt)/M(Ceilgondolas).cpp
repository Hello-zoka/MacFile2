    #include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

// #define int long long
#define INF 1e14
#define maxn 4007
int sm[maxn][maxn], dp[maxn][maxn], p[maxn][maxn];

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, k;
    cin >> n >> k;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            int x;
            cin >> x;
            sm[i][j + 1] = x;
            if (j != 0) sm[i][j + 1] += sm[i][j];
        }
    }
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            p[i][j] = p[i][j - 1] + sm[j][j + 1] - sm[j][i];
        }
    }
    for (int i = 0; i < n; i++) {
        dp[1][i + 1] = p[0][i];
    }
    for (int i = 2; i <= k; i++) {
        int pos = 0;
        dp[i][0] = 0;
        for (int j = 0; j < n; j++) {
            while (1) {
                int bl = 0;
                int cur = dp[i - 1][pos] + p[pos][j];
                for (int x = pos + 1; x <= j && x < pos + 100; x++) {
                    if (dp[i - 1][x] + p[x][j] <= cur) {
                        pos = x;
                        bl = 1;
                        break;
                    }
                }
                if (!bl) break;
            }
            dp[i][j + 1] = dp[i - 1][pos] + p[pos][j];
        }
    }
    cout << dp[k][n];
    return 0;
}