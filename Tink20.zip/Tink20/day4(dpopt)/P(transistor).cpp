#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;
#define bigg __int128
#define int long long
#define ll long long
typedef vector<int> lnum;
const int base = 1000 * 1000 * 1000;

lnum convert(string s) {
    lnum a;
    for (int i = (int) s.length(); i > 0; i -= 9)
        if (i < 9)
            a.push_back(atoi(s.substr(0, i).c_str()));
        else
            a.push_back(atoi(s.substr(i - 9, 9).c_str()));
    return a;
}

lnum sm(lnum a, lnum b) {
    int carry = 0;
    for (size_t i = 0; i < max(a.size(), b.size()) || carry; ++i) {
        if (i == a.size())
            a.push_back(0);
        a[i] += carry + (i < b.size() ? b[i] : 0);
        carry = a[i] >= base;
        if (carry) a[i] -= base;
    }
    return a;
}

lnum raz(lnum a, lnum b) {
    int carry = 0;
    for (size_t i = 0; i < b.size() || carry; ++i) {
        a[i] -= carry + (i < b.size() ? b[i] : 0);
        carry = a[i] < 0;
        if (carry) a[i] += base;
    }
    while (a.size() > 1 && a.back() == 0)
        a.pop_back();
    return a;
}

lnum mul(lnum a, lnum b) {
    lnum c(a.size() + b.size());
    for (size_t i = 0; i < a.size(); ++i)
        for (int j = 0, carry = 0; j < (int) b.size() || carry; ++j) {
            long long cur = c[i + j] + a[i] * 1ll * (j < (int) b.size() ? b[j] : 0) + carry;
            c[i + j] = (int) cur % base;
            carry = (int) cur / base;
        }
    while (c.size() > 1 && c.back() == 0)
        c.pop_back();
    return c;
}

bool mn(lnum a, lnum b) {
    if (a.size() < b.size()) return true;
    if (b.size() < a.size()) return false;
    for (int i = a.size() - 1; i >= 0; i--) {
        if (a[i] < b[i]) return true;
        if (b[i] < a[i]) return false;
    }
    return false;
}

lnum del(lnum a, int b) {
    int carry = 0;
    for (int i = (int) a.size() - 1; i >= 0; --i) {
        long long cur = a[i] + carry * 1ll * base;
        a[i] = (int) cur / b;
        carry = (int) cur % b;
    }
    while (a.size() > 1 && a.back() == 0)
        a.pop_back();
    if (carry != 0)
        cerr << "Wtdf";
    return a;
}

void prnt(lnum a) {
    printf("%d", a.empty() ? 0 : a.back());
    for (int i = (int) a.size() - 2; i >= 0; --i)
        printf("%09d", a[i]);
}

signed main() {
    string nnn;
    cin >> nnn;
    lnum n = convert(nnn);
    string kkk;
    cin >> kkk;
    lnum k = convert(kkk);
    int lg = 0;
    lnum ed = convert("1");
    lnum kk = ed;
//    while (!mn(n, kk)) {
//        kk = mul(kk, convert("2"));
//        lg++;
//    }
    lnum cur = ed;
    lnum sum = convert("1");
    // k = sm(k, ed);
    for (ll i = 1; i <= 1000; i++) {
        lnum ii = convert(to_string(i));
        if (mn(k, ii)) {
            break;
        }
        lnum a = raz(sm(k, ed), ii);
        cur = mul(cur, a);
        cur = del(cur, i);
        sum = sm(sum, cur);
        // prnt(cur);
        // cout << '\n';
        if (mn(n, sum)) {
            cout << i;
            return 0;
        }
    }
    // k = raz(k, ed);
    // prnt(k);
    // cerr << lg;
//    if (mn(convert(to_string(lg)), k)) {
//        k = raz(k, ed);
//        prnt(k);
//        return 0;
//    }
    cout << -1;
    return 0;
}