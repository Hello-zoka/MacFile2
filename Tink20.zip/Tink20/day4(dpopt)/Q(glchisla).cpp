#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;

#define int long long
const int K = 500;

signed main() {
    int x;
    cin >> x;
    string n = to_string(x);
    vector<vector<int>> dp(K, vector<int>(20, 0));
    for (int i = 1; i < 10; i++) {
        dp[1][i] = 1;
    }
    for (int i = 2; i < K; i++) {
        int cur = 0;
        for (int j = 10; j > 0; j--) {
            cur += dp[i - 1][j];
            dp[i][j] = cur;
        }
    }
//    for (int i = 0; i < K; i++){
//        for (int j =0; j < 10; j++){
//            cerr <<dp[i][j] << " ";
//        }
//        cerr << "\n";
//    }
    string ans = "";
    int bl = 1;
    int sm = 0, ii = 0, jj = -1;
    for (int i = 1; i < K; i++) {
        ii = i;
        for (int j = 1; j < 10; j++) {
            sm += dp[i][j];
            if (sm >= x) {
                jj = j;
                x -= sm - dp[i][j];
                ans += '0' + j;
                break;
            }
        }
        if (jj != -1) break;
    }
    bl = 0;
    int pr = 0, mx = jj;
    for (int i = ii - 1; i > 0; i--) {
        pr = 0;
        int pos = 0;
        for (int j = mx; j < 10; j++) {
            pr += dp[i][j];
            if (pr >= x) {
                pos = j;
                break;
            }
        }
        if (pos == 0 && !bl) {
            ans += '0' + mx;
        }
        if (pos != 0 && (!bl || pos != 1)) {
            // cerr << i << " " << "wtf" << pos << '\n';
            bl = 0;
            char a = '0' + pos;
            ans += a;
            mx = max(mx, pos);
            if (pos != 1) {
                x -= pr - dp[i][pos];
            }
        }
    }
    cout << ans;
}