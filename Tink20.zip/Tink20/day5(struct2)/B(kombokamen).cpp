#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

// #define ll long long
#define MAXN 4000000
#define INF 1e14
#define ll long long
const ll M = 300007;

struct Node {
    int x, y;
    Node *l, *r;

    Node() {
        x = 0, l = nullptr, r = nullptr, y = -1;
    }
};

void build(Node *v, int tl, int tr) {
    if (tl == 1) v->x = 1;
    if (tl != tr) {
        ll tm = (tl + tr) / 2;
        v->l = new Node();
        v->r = new Node();
        build(v->l, tl, tm);
        build(v->r, tm + 1, tr);
    }
}

Node *td = new Node();

void upd(Node *v, int tl, int tr, int l, int r, int val) {
    if (l > r) return;
    if (tl == l && tr == r) {
        v->x = val * (tr - tl + 1);
        v->y = val;
        return;
    }
    int tm = (tl + tr) / 2;
    bool bl = false;
    if (v->y != -1) {
        td = new Node();
        td->l = (v->l)->l;
        td->r = (v->l)->r;
        td->x = (tm - tl + 1) * v->y;
        td->y = v->y;
        v->l = td;
        td = new Node();
        td->l = (v->r)->l;
        td->r = (v->r)->r;
        td->x = (tr - tm) * v->y;
        td->y = v->y;
        v->r = td;
        v->y = -1;
        bl = true;
    }
    if (l <= min(r, tm)) {
        if (!bl) {
            td = new Node();
            td->l = (v->l)->l;
            td->r = (v->l)->r;
            td->x = (v->l)->x;
            td->y = (v->l)->y;
            v->l = td;
        }
        upd(v->l, tl, tm, l, min(r, tm), val);
    }
    if (max(l, tm + 1) <= r) {
        if (!bl) {
            td = new Node();
            td->l = (v->r)->l;
            td->r = (v->r)->r;
            td->x = (v->r)->x;
            td->y = (v->r)->y;
            v->r = td;
        }
        upd(v->r, tm + 1, tr, max(l, tm + 1), r, val);
    }
    v->x = (v->l)->x + (v->r)->x;
}

ll pos, mb;

void get(Node *v, int tl, int tr) {
    if (tl > pos) return;
    if (mb != -1) return;
    if (v->x == 0) return;
    if (tl == tr) {
        mb = tl;
        return;
    }
    int tm = (tl + tr) / 2;
    if (v->y != -1) {
        td = new Node();
        td->l = (v->l)->l;
        td->r = (v->l)->r;
        td->x = (tm - tl + 1) * v->y;
        td->y = v->y;
        v->l = td;

        td = new Node();
        td->l = (v->r)->l;
        td->r = (v->r)->r;
        td->x = (tr - tm) * v->y;
        td->y = v->y;
        v->r = td;
        v->y = -1;
    }
    get(v->r, tm + 1, tr);
    get(v->l, tl, tm);
}

struct e {
    ll d = -1, dmg, R;
    Node *rt;
};

vector<e> lst;
e cur;
ll st;

void oh(ll a, ll dmg) {
    if (lst[a].d != -1) return;
    if (lst[a].R <= dmg) {
        lst[a].d = st;
        return;
    }
    pos = lst[a].R - dmg;
    td = new Node();
    td->l = lst[a].rt->l;
    td->r = lst[a].rt->r;
    td->x = lst[a].rt->x;
    td->y = lst[a].rt->y;
    lst[a].rt = td;
    mb = -1;
    get(lst[a].rt, 1, M);
    if (mb == -1) {
        lst[a].d = st;
        return;
    }
    upd(lst[a].rt, 1, M, mb, mb, 0);
    upd(lst[a].rt, 1, M, mb + 1, pos, 1);
    if (lst[a].rt->x == 0) {
        lst[a].d = st;
        return;
    }
}


signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    ll q;
    cin >> q;
    cur.rt = new Node();
    cur.dmg = 0;
    cur.R = 1;
    build(cur.rt, 1, M);
    lst.push_back(cur);
    for (st = 1; st <= q; st++) {
        ll t;
        cin >> t;
        if (t == 1) {
            lst.push_back(lst[0]);
        } else if (t == 2) {
            ll x;
            cin >> x;
            lst[x].dmg++;
        } else if (t == 3) {
            ll x;
            cin >> x;
            lst[x].R++;
        } else if (t == 4) {
            ll p;
            cin >> p;
            lst.push_back(lst[p]);
            if (lst[p].d != -1) {
                lst.back().d = st;
            }
        } else {
            ll a, b;
            cin >> a >> b;
            if (lst[a].d != -1 || lst[b].d != -1)continue;
            oh(a, lst[b].dmg);
            oh(b, lst[a].dmg);
        }
    }
    cout << lst.size() - 1 << '\n';
    for (ll i = 1; i < lst.size(); i++) {
        cout << lst[i].d << " ";
    }
    return 0;
}
