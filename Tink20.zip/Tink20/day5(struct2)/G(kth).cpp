#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

#define int long long
#define maxn 450001
#define mod 1000000000
#define MAXN 10000000

struct Node {
    int x, l, r;
    Node() {
        x = 0;
        l = -1;
        r = -1;
    }

    Node(int xx) {
        x = xx;
        l = -1;
        r = -1;
    }
};

Node pos[MAXN];
int sz = 0;

int build(int tl, int tr) {
    if (tl + 1 == tr) {
        pos[sz] = Node(0);
        return sz++;
    }
    int tm = (tl + tr) / 2;
    int num = sz++;
    Node x = Node(0);
    x.l = build(tl, tm);
    x.r = build(tm, tr);
    int a = 0, b = 0;
    if (x.r != -1) a = pos[x.r].x;
    if (x.l != -1) b = pos[x.l].x;
    x.x = a + b;
    pos[num] = x;
    return num;
}

int add(int v, int tl, int tr, int p, int val) {
    if (tl + 1 == tr) {
        pos[sz] = Node(pos[v].x + val);
        return sz++;
    }
    int tm = (tl + tr) / 2;
    if (p < tm) {
        Node x = Node(0);
        int num = sz++;
        x.l = add(pos[v].l, tl, tm, p, val);
        x.r = pos[v].r;
        int a = 0, b = 0;
        if (x.r != -1) {
            a = pos[x.r].x;
        }
        if (x.l != -1) {
            b = pos[x.l].x;
        }
        x.x = a + b;
        pos[num] = x;
        return num;
    }

    Node x = Node(0);
    int num = sz++;
    x.l = pos[v].l;
    x.r = add(pos[v].r, tm, tr, p, val);
    int a = 0, b = 0;
    if (x.r != -1) a = pos[x.r].x;
    if (x.l != -1) b = pos[x.l].x;
    x.x = a + b;
    pos[num] = x;
    return num;
}

int get(int tl, int tr, int l, int r, int k) {
    if (l + 1 == r) {
        return l;
    }
    int m = (l + r) / 2;
    if (pos[pos[tr].l].x - pos[pos[tl].l].x >= k) {
        return get(pos[tl].l, pos[tr].l, l, m, k);
    }
    return get(pos[tl].r, pos[tr].r, m, r, k - pos[pos[tr].l].x + pos[pos[tl].l].x);
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    int lst[n + 1], vers[n + 1];
    int l, m;
    cin >> lst[0] >> l >> m;
    vector<int> a(n);
    a[0] = lst[0];
    for (int i = 1; i < n; i++) {
        lst[i] = ((lst[i - 1] * l) % mod + m) % mod;
        a[i] = lst[i];
    }
    sort(a.begin(), a.end());
    int nn = n;
    vers[0] = build(0, nn);
    for (int i = 0; i < n; i++) {
        lst[i] = lower_bound(a.begin(), a.end(), lst[i]) - a.begin();
        vers[i + 1] = add(vers[i], 0, nn, lst[i], 1);
    }
    int b;
    cin >> b;
    int ans = 0;
    int x1, lx, mx, y1, ly, my, k1, lk, mk;
    int i, j;
    int q;
    while (b--) {
        cin >> q;
        cin >> x1 >> lx >> mx >> y1 >> ly >> my >> k1 >> lk >> mk;
        i = min(x1, y1);
        j = max(x1, y1);
        ans += a[get(vers[i - 1], vers[j], 0, nn, k1)];
        while (q-- != 1) {
            x1 = (((int) (i - 1) * lx) % n + mx) % n + 1;
            y1 = (((int) (j - 1) * ly) % n + my) % n + 1;
            i = min(x1, y1);
            j = max(x1, y1);
            int nnn = j - i + 1;
            k1 = (((int) (k1 - 1) * lk) % nnn + mk) % nnn + 1;
            ans += a[get(vers[i - 1], vers[j], 0, nn, k1)];
        }
    }
    cout << ans;
}