#include <immintrin.h>
#include <limits.h>
#include <algorithm>
#include <stdio.h>


using namespace std;

// #pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,avx2,tune=native")

unsigned GetMin(const unsigned *a, int n) {
    unsigned mn = UINT_MAX;
    __m256i min_avx = _mm256_set1_epi32(UINT_MAX);
    size_t i = 0;
    for (; i + 8 < n; i += 8) {
        __m256i curr_block = _mm256_lddqu_si256(reinterpret_cast<const __m256i *>(a + i));
        min_avx = _mm256_min_epu32(min_avx, curr_block);
    }
    unsigned *mins = (unsigned *) &min_avx;
    for (; i < n; i++) {
        mn = min(mn, a[i]);
    }
    for (i = 0; i < 8; i++) {
        mn = min(mn, mins[i]);
    }
    return mn;
}

void AddProg(unsigned *a, int n, unsigned k) {
    size_t i = 0;
    __m256i min_avx, add = _mm256_set1_epi32(k * 8), cur = _mm256_set_epi32(k * 8, k * 7, k * 6, k * 5, k * 4, k * 3, k * 2,
                                                                            k);
    for (; i + 8 < n; i += 8) {
        __m256i curr_block = _mm256_lddqu_si256(reinterpret_cast<const __m256i *>(a + i));
        min_avx = _mm256_add_epi32(cur, curr_block);
        _mm256_storeu_si256(reinterpret_cast<__m256i *>(a + i), min_avx);
        cur = _mm256_add_epi32(cur, add);
    }
    for (; i < n; i++) {
        a[i] = a[i] + (i + 1) * k;
    }
}
//
//    signed main() {
//        int n = 8;
//        unsigned a[18] = {100, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 0, 0, 0};
//        AddProg(a, n, 10);
//        AddProg(a, n, 0);
//
//        for (int i =0; i < 18; i++){
//            printf("%u ", a[i]);
//        }
//        printf("%u ", GetMin(a, 18));
//        printf("\n");
//    }