#include <immintrin.h>
#include <limits.h>
#include <algorithm>
#include <iostream>
#include <stdio.h>


using namespace std;

#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,avx2,tune=native")

unsigned a[200001];

void Add(int l, int r, int k) {
    size_t i = r, j = l, cnt = 0;
    __m256i cur;
    for (; cnt + 8 < k; cnt += 8, i += 8, j += 8) {
        __m256i curr_block = _mm256_lddqu_si256(reinterpret_cast<const __m256i *>(a + i));
        __m256i curr_block2 = _mm256_lddqu_si256(reinterpret_cast<const __m256i *>(a + j));
        cur = _mm256_add_epi32(curr_block2, curr_block);
        _mm256_storeu_si256(reinterpret_cast<__m256i *>(a + i), cur);
    }
    for (; cnt < k; cnt++, i++, j++) {
        a[i] += a[j];
    }
}

signed main() {
    int n, m;
    scanf("%i%i", &n, &m);
    for (int i = 0; i < n; i++) {
        scanf("%u", &a[i]);
    }
    for (int q = 0; q < m; q++) {
        int l, r, k;
        scanf("%i%i%i", &l, &r, &k);
        Add(l - 1, r - 1, k);
    }
    for (int i = 0; i < n; i++) {
        printf("%u ", a[i]);
    }
}