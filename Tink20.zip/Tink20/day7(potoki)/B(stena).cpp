#include <iostream>
#include <vector>
#include <queue>

using namespace std;

#define MAXN 5007
#define INF 1e10
#define int long long
#define INFF 1e7
struct e {
    int a, b, cap, flow;
};
int tim = 1;
vector<int> p1 = {1, 0, 0, -1};
vector<int> p2 = {0, 1, -1, 0};
int s = 0, t, q[MAXN];
vector<e> e;
vector<int> d, ptr, used;
vector<int> lst[MAXN];
int n, m;

int sz;

int bfs() {
    int ql = 0, qr = 0;
    q[qr++] = s;
    d.assign(sz, -1);
    d[s] = 0;
    while (ql < qr && d[t] == -1) {
        int v = q[ql++];
        for (int i = 0; i < lst[v].size(); ++i) {
            int id = lst[v][i], to = e[id].b;
            if (d[to] == -1 && e[id].flow < e[id].cap) {
                q[qr++] = to;
                d[to] = d[v] + 1;
            }
        }
    }
    return d[t] == -1;
}

int dfs(int v, long long flow) {
    if (flow == 0)
        return 0;
    if (v == t)
        return flow;
    used[v] = tim;
    while (ptr[v] < lst[v].size()) {
        int ind = lst[v][ptr[v]], to = e[ind].b;
        if (e[ind].cap == e[ind].flow) {
            ptr[v]++;
            continue;
        }
        if (used[to] == tim) {
            ptr[v]++;
            continue;
        }
        int cur = dfs(to, min(flow, (long long) e[ind].cap - e[ind].flow));
        if (cur != 0) {
            e[ind].flow += cur;
            e[ind ^ 1].flow -= cur;
            // cerr << 2;
            return cur;
        }
        ptr[v]++;
    }
    return 0;
}

vector<int> col;

void dfss(int v) {
    if (col[v]) return;
    col[v] = 1;
    while (ptr[v] < lst[v].size()) {
        int ind = lst[v][ptr[v]], to = e[ind].b;
        ptr[v]++;
        if (e[ind].flow != e[ind].cap)
            dfss(to);
    }
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m;
    int k, l;
    cin >> k >> l;
    sz = n * m;
    vector<vector<int>> tab(n, vector<int>(m, 0)), sc(n, vector<int>(m, -1));
    for (int i = 0; i < k; i++) {
        int x, y;
        cin >> x >> y;
        x--;
        y--;
        tab[x][y] = -1;
    }
    for (int i = 0; i < l; i++) {
        int x, y;
        cin >> x >> y;
        x--;
        y--;
        tab[x][y] = 1;
        sc[x][y] = sz++;
    }
    int stx, sty, fx, fy;
    cin >> stx >> sty >> fx >> fy;
    stx--;
    sty--;
    fx--;
    fy--;
    s = stx * m + sty;
    t = fx * m + fy;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            struct e e1, e2;
            int a, b, cap;
            if (tab[i][j] == 1) {
                a = i * m + j;
                cap = 1;
                b = sc[i][j];
                // cerr << a << " " << b<< '\n';
                e1 = {a, b, cap, 0};
                e2 = {b, a, 0, 0};
                lst[a].push_back(e.size());
                e.push_back(e1);
                lst[b].push_back(e.size());
                e.push_back(e2);
            }
            if (tab[i][j] == -1) continue;
            for (int kk = 0; kk < 2; kk++) {
                int ii = i + p1[kk], jj = j + p2[kk];
                if (ii > n - 1 || jj > m - 1) continue;
                if (tab[ii][jj] == -1) continue;
                if (tab[i][j] == 1 && tab[ii][jj] == 1) {
                    cap = INFF;
                    a = sc[i][j];
                    b = sc[ii][jj];
                    e1 = {a, ii * m + jj, cap, 0};
                    e2 = {ii * m + jj, a, 0, 0};
                    lst[a].push_back(e.size());
                    e.push_back(e1);
                    lst[ii * m + jj].push_back(e.size());
                    e.push_back(e2);
                    e1 = {i * m + j, b, 0, 0};
                    e2 = {b, i * m + j, cap, 0};
                    lst[i * m + j].push_back(e.size());
                    e.push_back(e1);
                    lst[b].push_back(e.size());
                    e.push_back(e2);
                } else if (tab[i][j] == 1) {
                    b = abs(sc[i][j]);
                    a = ii * m + jj;
                    // cerr << a << " " << b << '\n';
                    cap = INFF;
                    e1 = {a, i * m + j, cap, 0};
                    e2 = {i * m + j, a, 0, 0};
                    lst[a].push_back(e.size());
                    e.push_back(e1);
                    lst[i * m + j].push_back(e.size());
                    e.push_back(e2);
                    e1 = {a, b, 0, 0};
                    e2 = {b, a, cap, 0};
                    lst[a].push_back(e.size());
                    e.push_back(e1);
                    lst[b].push_back(e.size());
                    e.push_back(e2);
                } else if (tab[ii][jj] == 1) {
                    b = abs(sc[ii][jj]);
                    a = i * m + j;
                    // cerr << a << " " << b << '\n';
                    cap = INFF;
                    e1 = {a, ii * m + jj, cap, 0};
                    e2 = {ii * m + jj, a, 0, 0};
                    lst[a].push_back(e.size());
                    e.push_back(e1);
                    lst[ii * m + jj].push_back(e.size());
                    e.push_back(e2);
                    e1 = {a, b, 0, 0};
                    e2 = {b, a, cap, 0};
                    lst[a].push_back(e.size());
                    e.push_back(e1);
                    lst[b].push_back(e.size());
                    e.push_back(e2);
                } else {
                    b = ii * m + jj;
                    a = i * m + j;
                    // cerr << a << " " << b << '\n';
                    cap = INFF;
                    e1 = {a, b, cap, 0};
                    e2 = {b, a, cap, 0};
                    lst[a].push_back(e.size());
                    e.push_back(e1);
                    lst[b].push_back(e.size());
                    e.push_back(e2);
                }
            }
        }
    }
//    for (int i = 0; i < sz; i++) {
//        cerr << "vershina" << i << '\n';
//        for (int j : lst[i]) {
//            cerr << e[j].b << " ";
//        }
//        cerr << "\n";
//    }

    int ans = 0;
    used.assign(sz, 0);
    ptr.assign(sz, 0);
    while (dfs(s, INFF + 1)) {
        ptr.assign(sz, 0);
        ++tim;
    }
    ptr.assign(sz, 0);
    col.assign(sz, 0);
    dfss(s);
    long long cnt = 0, prop = 0;
    vector<pair<int, int>> anss;
    for (int i = 0; i < e.size(); i++) {
        if ((col[e[i].a] && !col[e[i].b])) {
            cnt += 1;
            prop += e[i].flow;
            if (e[i].flow == 1 && e[i].cap == 1) {
                int x = min(e[i].a, e[i].b);
                anss.push_back({x / m, x % m});
            }
        }
    }
    // cout << prop << '\n';
    if (prop >= MAXN) {
        cout << -1;
        return 0;
    }
    cout << anss.size() << "\n";
    for (int i = 0; i < anss.size(); i++) {
        cout << anss[i].first + 1 << " " << anss[i].second + 1 << "\n";
    }

    return 0;
}
/*
5 12 3
x1 x2 x3 x4 x5
x6 x1 x2 0110
x7 x1 x2 0001
x8 x3 x4 0110
x9 x3 x4 0001
x10 x8 x5 0110
x11 x8 x5 0001
x12 x9 x11 0110
x13 x10 x6 0110
x14 x10 x6 0001
x15 x14 x7 0110
x16 x15 x12 0110
x17 x15 x12 0001
x13 x16 x17
*/
/*
12 31 1
x1 x2 x3 x4 x5 x6 x7 x8 x9 x10 x11 x12
a x1 x2 0001
b x3 x4 0001
c x5 x6 0001
d x7 x8 0001
e x9 x10 0001
f x11 x12 0001
aa x1 x2 0110
bb x3 x4 0110
cc x5 x6 0110
dd x7 x8 0110
ee x9 x10 0110
ff x11 x12 0110
g aa bb 0001
h cc dd 0001
i ee ff 0001
gg aa bb 0110
hh cc dd 0110
ii ee ff 0110
y gg hh 0111
y1 y ii 0001
y2 gg hh 0001
y3 y1 y2 0111
xx a b 0111
xx2 c d 0111
xx3 e f 0111
xx4 g h 0111
xx5 i y3 0111
xxx xx xx2 0111
xxx2 xx3 xx4 0111
xxx3 xxx xxx2 0111
ans xx5 xxx3 0111
ans
*/