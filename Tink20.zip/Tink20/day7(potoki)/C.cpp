#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

#define int long long
#define INF 1e12
#define MAXN 505
#define inf 1e9

struct e {
    int u, v, cap, f;
};
int n, m;
vector<e> ed;
vector<int> lst[MAXN], d;
int q[MAXN];
vector<int> ptr;
int lm;

int s, t;

int bfs() {
    int l = 0, r = 0;
    q[r++] = s;
    d.assign(n + 2, INF);
    d[s] = 1;
    while (l < r && d[t] == INF) {
        int v = q[l++];
        for (int i : lst[v]) {
            int to = ed[i].v;
            if (d[to] == INF && ed[i].cap - ed[i].f >= lm) {
                q[r++] = to;
                d[to] = d[v] + 1;
            }
        }
    }
    return d[t] != INF;
}

int dfs(int v, int f) {
    if (f == 0 || v == t) return f;
    while (ptr[v] < lst[v].size()) {
        int ind = lst[v][ptr[v]], to = ed[ind].v;
        if (d[to] == d[v] + 1 && ed[ind].cap - ed[ind].f >= f) {
            int cur = dfs(to, f);
            if (cur) {
                ed[ind].f += f;
                ed[ind ^ 1].f -= f;
                return f;
            }
        }
        ptr[v]++;
    }
    return 0;
}

void addedg(int a, int b, int x) {
    ed.push_back({a, b, x, 0});
    ed.push_back({b, a, 0, 0});
    lst[a].push_back(ed.size() - 2);
    lst[b].push_back(ed.size() - 1);
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    s = 0;
    t = 1;
    int cnt = 0;
    for (int i = 0; i < n; i++) {
        int a;
        cin >> a;
        if (a >= 0) {
            addedg(s, i + 2, a);
            cnt += a;
        } else {
            addedg(i + 2, t, -a);
        }
    }
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        for (int j = 0; j < x; j++) {
            int a;
            cin >> a;
            addedg(i + 2, a + 1, inf);
        }
    }
    int ans = 0;
    for (lm = 1 << 30; lm >= 1;) {
        if (!bfs()) {
            lm >>= 1;
            continue;
        }
        ptr.assign(n + 2, 0);
        while (int cur = dfs(s, lm)) ans += cur;
    }
    cout << cnt - ans;
    return 0;
}