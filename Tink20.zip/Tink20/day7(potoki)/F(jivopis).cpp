#include <iostream>
#include <vector>
#include <queue>

using namespace std;

#define MAXN 5007
#define INF 1e10
// #define int long long
#define INFF 6e6
struct e {
    int a, b, cap, flow;
};
int tim = 1;
vector<int> p1 = {1, 0, 0, -1};
vector<int> p2 = {0, 1, -1, 0};
int s = 0, t, q[MAXN];
vector<e> e;
vector<int> d, ptr, used;
vector<int> lst[MAXN];
int n, m;
int sz;

long long bfs() {
    long long ql = 0, qr = 0;
    q[qr++] = s;
    d.assign(sz, -1);
    d[s] = 0;
    while (ql < qr && d[t] == -1) {
        long long v = q[ql++];
        for (long long i = 0; i < lst[v].size(); ++i) {
            long long id = lst[v][i], to = e[id].b;
            if (d[to] == -1 && e[id].flow < e[id].cap) {
                q[qr++] = to;
                d[to] = d[v] + 1;
            }
        }
    }
    return d[t] == -1;
}

long long dfs(long long v, long long flow) {
    if (!flow)
        return 0;
    if (v == t)
        return flow;
    while (ptr[v] < lst[v].size()) {
        long long ind = lst[v][ptr[v]], to = e[ind].b;
        if (d[to] == d[v] + 1) {
            long long cur = dfs(to, min(flow, (long long) e[ind].cap - e[ind].flow));
            if (cur != 0) {
                e[ind].flow += cur;
                e[ind ^ 1].flow -= cur;
                return cur;
            }
        }
        ptr[v]++;
    }
    return 0;
}

vector<int> col;

void dfss(int v) {
    if (col[v]) return;
    col[v] = 1;
    while (ptr[v] < lst[v].size()) {
        int ind = lst[v][ptr[v]], to = e[ind].b;
        ptr[v]++;
        if (e[ind].flow != e[ind].cap)
            dfss(to);
    }
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m;
    int w, b, g;
    cin >> w >> b >> g;
    s = n * m;
    t = n * m + 1;
    sz = t + 1;
    vector<vector<char>> tab;
    for (int i = 0; i < n; i++) {
        tab.push_back({});
        for (int j = 0; j < m; j++) {
            char x;
            cin >> x;
            tab[i].push_back(x);
        }
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (tab[i][j] == 'W') {
                struct e e1 = {s, i * m + j, 2 * b, 0};
                struct e e2 = {i * m + j, s, 2 * b, 0};
                lst[s].push_back(e.size());
                e.push_back(e1);
                lst[i * m + j].push_back(e.size());
                e.push_back(e2);
                e1 = {t, i * m + j, 0, 0};
                e2 = {i * m + j, t, 0, 0};
                lst[t].push_back(e.size());
                e.push_back(e1);
                lst[i * m + j].push_back(e.size());
                e.push_back(e2);
            } else {
                struct e e1 = {s, i * m + j, 0, 0};
                struct e e2 = {i * m + j, s, 0, 0};
                lst[s].push_back(e.size());
                e.push_back(e1);
                lst[i * m + j].push_back(e.size());
                e.push_back(e2);
                e1 = {t, i * m + j, 2 * w, 0};
                e2 = {i * m + j, t, 2 * w, 0};
                lst[t].push_back(e.size());
                e.push_back(e1);
                lst[i * m + j].push_back(e.size());
                e.push_back(e2);
            }
            for (int k = 0; k < 2; k++) {
                int x = i + p1[k], y = j + p2[k];
                if (x < 0 || x >= n || y < 0 || y >= m) continue;
                int aa = i * m + j;
                int bb = x * m + y;
                struct e e1 = {aa, bb, 2 * g, 0};
                struct e e2 = {bb, aa, 2 * g, 0};
                lst[aa].push_back(e.size());
                e.push_back(e1);
                lst[bb].push_back(e.size());
                e.push_back(e2);
            }
        }
    }
    sz = n * m + 2;
    int ans = 0;
    while (!bfs()) {
        ptr.assign(sz, 0);
        while (long long cur = dfs(s, INF)) {
            ans += cur;
        }
    }
    ptr.assign(sz, 0);
    col.assign(sz, 0);
    dfss(s);
    long long cnt = 0, prop = 0;
    vector<pair<int, int>> anss;
    for (int i = 0; i < e.size(); i++) {
        if ((col[e[i].a] && !col[e[i].b])) {
            cnt += 1;
            prop += e[i].flow;
            anss.push_back({e[i].a, e[i].b});
        }
    }
    cout << prop / 2 << '\n';
//    cout << anss.size() << "\n";
//    for (int i = 0; i < anss.size(); i++) {
//        cout << anss[i].first + 1 << " " << anss[i].second + 1 << "\n";
//    }
    return 0;
}
