#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

#define int long long
#define INF 1e12
#define MAXN 5005

struct e {
    int u, v, cap, f;
};
int n, k;
int sz;
vector<e> ed;
vector<int> lst[MAXN], d;
int q[MAXN];
vector<int> ptr;
int lm;
int s, t;

void addedg(int a, int b, int cap, int f) {
    ed.push_back({a, b, cap, f});
    ed.push_back({b, a, 0, f});
    lst[a].push_back(ed.size() - 2);
    lst[b].push_back(ed.size() - 1);
}

bool bfs() {
    int l = 0, r = 0;
    q[r++] = s;
    d.assign(sz, INF);
    d[s] = 1;
    while (l < r && d[t] == INF) {
        int v = q[l++];
        for (int i : lst[v]) {
            int to = ed[i].v;
            if (d[to] == INF && ed[i].cap - ed[i].f >= lm) {
                q[r++] = to;
                d[to] = d[v] + 1;
            }
        }
    }
    return d[t] != INF;
}

int dfs(int v, int f) {
    if (f == 0 || v == t) return f;
    while (ptr[v] < lst[v].size()) {
        int ind = lst[v][ptr[v]], to = ed[ind].v;
        if (d[to] == d[v] + 1 && ed[ind].cap - ed[ind].f >= lm) {
            int cur = dfs(to, f);
            if (cur) {
                ed[ind].f += f;
                ed[ind ^ 1].f -= f;
                return f;
            }
        }
        ptr[v]++;
    }
    return 0;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> k;
    vector<vector<int>> a(n, vector<int>(k));
    vector<vector<int>> tab(k, vector<int>(n));
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < k; j++) {
            cin >> a[i][j];
            tab[j][i] = a[i][j];
        }
    }
    vector<int> m(k);
    for (int i = 0; i < k; i++) {
        vector<int> &cur = tab[i];
        nth_element(cur.begin(), cur.begin() + n / 2, cur.end());
        nth_element(cur.begin(), cur.begin() + n / 2 - 1, cur.begin() + n / 2);
        m[i] = cur[n / 2 - 1] + cur[n / 2];
    }
    vector<int> st3(k + 1);
    st3[0] = 1;
    for (int i = 1; i <= k; i++) {
        st3[i] = st3[i - 1] * 3;
    }
    sz = st3[k] + 2;
    vector<vector<int>> buck(sz - 2);
    for (int i = 0; i < n; i++) {
        int cnt = 0;
        for (int j = 0; j < k; j++) {
            int x;
            if (a[i][j] * 2 < m[j]) {
                x = 0;
            } else if (a[i][j] * 2 > m[j]) {
                x = 2;
            } else {
                x = 1;
            }
            cnt += x * st3[j];
        }
        buck[cnt].push_back(i);
    }

    s = st3[k], t = st3[k] + 1;
    for (int i = 0; i < st3[k]; i++) {
        int ost = i % 3, ii = i;
        if (ost == 1) {
            continue;
        }
        ii /= 3;
        bool bl = false;
        for (int j = 1; j < k; j++) {
            int x = ii % 3;
            ii /= 3;
            if (x == 1) {
                bl = true;
                if (ost == 0) {
                    addedg(i, i - st3[j], n / 2, 0);
                    addedg(i, i + st3[j], n / 2, 0);
                } else {
                    addedg(i - st3[j], i, n / 2, 0);
                    addedg(i + st3[j], i, n / 2, 0);
                }
                break;
            }
        }
        if (!bl && ost == 0) {
            addedg(i, st3[k] - 1 - i, n / 2, 0);
        }
        if (ost == 0) {
            addedg(s, i, buck[i].size(), 0);
        } else {
            addedg(i, t, buck[i].size(), 0);
        }
    }

    int ans = 0;
    // cerr << 1;
    // cerr << s << " " << t << '\n';
    ptr.assign(sz, 0);
    for (lm = ((int) 1 << 30); lm >= 1;) {
        if (!bfs()) {
            lm /= 2;
            continue;
        }
        ptr.assign(sz, 0);
        while (int cur = dfs(s, lm)) {
            ptr.assign(sz, 0);
            ans += cur;
        }
    }
    // cerr << 2;
    if (ans != n / 2) {
        cout << "NO";
        return 0;
    }
    cout << "YES\n";
    for (int i = 0; i < n / 2; i++) {
        int v = s;
        int v1 = -1, v2 = -1;
        while (v != t) {
            if (v1 == -1 && v != s) {
                v1 = v;
            }
            v2 = v;
            // bool bl = false;
            for (int ind : lst[v]) {
                if (ed[ind].f > 0) {
                    // bl = true;
                    --ed[ind].f;
                    ++ed[ind ^ 1].f;
                    v = ed[ind].v;
                    break;
                }
            }
        }
        cout << buck[v1].back() + 1 << " " << buck[v2].back() + 1 << '\n';
        buck[v1].pop_back();
        buck[v2].pop_back();
    }
    return 0;
}