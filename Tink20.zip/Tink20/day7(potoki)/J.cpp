#include <iostream>
#include <vector>
#include <queue>

using namespace std;

#define MAXN 507
#define INF 1e18
#define int long long
#define INFF 1e8



// vector<int> lst[MAXN];
int n;
struct e {
    int u, v, cap, cost;
};

// int cost[MAXN][MAXN], cap[MAXN][MAXN];
vector<e> edg;
vector<vector<int>> cost, cap;
vector<vector<int>> adj;
string ans;

void djk(int v0, vector<int> &d, vector<int> &p) {
    d.assign(n, INF);
    d[v0] = 0;
    vector<int> m(n, 2);
    deque<int> q;
    q.push_back(v0);
    p.assign(n, -1);
    while (!q.empty()) {
        int u = q.front();
        q.pop_front();
        m[u] = 0;
        for (int v : adj[u]) {
            if (cap[u][v] > 0 && d[v] > d[u] + cost[u][v]) {
                d[v] = d[u] + cost[u][v];
                p[v] = u;
                if (m[v] == 2) {
                    m[v] = 1;
                    q.push_back(v);
                } else if (m[v] == 0) {
                    m[v] = 1;
                    q.push_front(v);
                }
            }
        }
    }
}

int k;

int min_cost(int s, int t) {
    adj.assign(n, vector<int>());
    cost.assign(n, vector<int>(n, 0));
    cap.assign(n, vector<int>(n, 0));
    for (e x : edg) {
        adj[x.u].push_back(x.v);
        adj[x.v].push_back(x.u);
        cost[x.u][x.v] = x.cost;
        cost[x.v][x.u] = -x.cost;
        cap[x.u][x.v] = x.cap;
    }
    int flow = 0;
    int cst = 0;
    vector<int> d, p;
    while (flow < k) {
        djk(s, d, p);
        if (d[t] == INF) {
            break;
        }
        int f = k - flow;
        int cur = t;
        while (cur != s) {
            f = min(f, cap[p[cur]][cur]);
            cur = p[cur];
        }
        flow += f;
        cst += f * d[t];
        cur = t;
        while (cur != s) {
            cap[p[cur]][cur] -= f;
            cap[cur][p[cur]] += f;
            cur = p[cur];
        }
    }
    ans = "";
    for (int i = 0; i < k; i++) {
        for (int j = 0; j < k; j++) {
            if (cap[i][j + k] == 0) {
                ans += string(1, j < 26 ? ('a' + j) : ('A' + (j - 26)));
            }
        }
    }

    if (flow < k)
        return -1;
    else
        return cst;
}

int w[110][110];
int cnt[110];

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> k;
    string s, t;
    cin >> s >> t;
    for (int i = 0; i < n; i++) {
        int a = islower(s[i]) ? s[i] - 'a' : s[i] - 'A' + 26;
        int b = islower(t[i]) ? t[i] - 'a' : t[i] - 'A' + 26;
        w[a][b]++;
        cnt[a]++;
    }
    for (int i = 0; i < k; i++) {
        for (int j = 0; j < k; j++) {
            e x = {i, k + j, 1, cnt[j] - w[i][j]};
            edg.push_back(x);
        }
    }
    for (int i = 0; i < k; i++) {
        e x = {2 * k, i, 1, 0};
        edg.push_back(x);
        e y = {k + i, 2 * k + 1, 1, 0};
        edg.push_back(y);
    }
    int nn = n;
    n = 2 * k + 2;
    cout << nn - min_cost(2 * k, 2 * k + 1) << '\n';
    cout << ans;
    return 0;
}
