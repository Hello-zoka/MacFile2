#include <iostream>
#include <vector>
#include <complex>
#include <math.h>
#include <algorithm>

using namespace std;
vector<int> rev, roots;
int lg = 1;
int N;
const double PI = 3.1415926535;

void precalc() {
    for (int i = 0; i < N; ++i) {
        rev[i] = 0;
        for (int j = 0; j < lg; ++j)
            if (i & (1 << j))
                rev[i] |= 1 << (lg - 1 - j);
        // cerr << i << " " << rev[i] << "\n";
    }
    // rev[i] = (rev[i >> 1] >> 1) | ((i & 1) << (N - 1));
}

void fft(vector<complex<double>> &a, int bl) {
    for (int i = 0; i < N; i++) {
        if (i < rev[i]) {
            swap(a[i], a[rev[i]]);
        }
    }
    int cur = 1;

    for (int lvl = 0; lvl < lg; lvl++) {
        cur *= 2;
        double ang = 2 * PI / cur * (bl ? -1 : 1);

        complex<double> wlen(cos(ang), sin(ang));
        for (int i = 0; i < N; i += cur) {
            complex<double> w(1);
            for (int j = 0; j < cur / 2; j++) {
                // cerr << i + j << " ";
                complex<double> x = a[i + j], y = a[i + j + cur / 2] * w;
                a[i + j] = x + y;
                a[i + j + cur / 2] = x - y;
                w *= wlen;
            }
        }
    }

    if (bl) {
        for (int i = 0; i < N; i++) {
            cerr << a[i].real() << " " << a[i].imag() << '\n';
            a[i] /= N;
        }
    }
}

signed main() {
    string s1, s2;
    cin >> s1 >> s2;
    int zn = 0;
    if ((s1[0] == '-' && s2[0] != '-') || (s1[0] != '-' && s2[0] == '-')) zn = 1;
    if (s1 == "0" || s2 == "0") {
        cout << 0;
        return 0;
    }
    reverse(s1.begin(), s1.end());
    reverse(s2.begin(), s2.end());
    if (s1[s1.size() - 1] == '-') s1.pop_back();
    if (s2[s2.size() - 1] == '-') s2.pop_back();
    N = 2;
    int ll = 1, k = 2;
    while (N < s1.size() + s2.size() + 5) {
        N *= 2;
        lg++;
    }
    vector<complex<double>> a, b;
    rev.assign(N + 5, 0);
    precalc();
    for (int i = 0; i < N; i++) {
        if (s1.size() > i) {
            a.push_back(s1[i] - '0');
        } else {
            a.push_back(0);
        }
    }
    for (int i = 0; i < N; i++) {
        if (s2.size() > i) {
            b.push_back(s2[i] - '0');
        } else {
            b.push_back(0);
        }
    }

    fft(a, 0);
    fft(b, 0);
    for (int i = 0; i < N; i++) {
        // cerr << a[i] << " " << b[i] << "\n";
        a[i] *= b[i];
    }
    fft(a, 1);
    vector<int> ans;
    for (int i = 0; i < N; i++) {
        ans.push_back(int(a[i].real() + 0.5));
        // cerr << ans[i] << " ";
    }
    int cur = 0;
    for (int i = 0; i < N; i++) {
        ans[i] += cur;
        cur = ans[i] / 10;
        ans[i] %= 10;
    }
    reverse(ans.begin(), ans.end());
    int bl = 0;
    if (zn) cout << "-";
    for (int i = 0; i < N; i++) {
        if (ans[i] != 0) bl = 1;
        if (bl)
            cout << ans[i];
    }
    return 0;
}