#include <iostream>
#include <vector>
#include <algorithm>
using namespace  std;
#define int long long
signed main() {
    vector<string> ss = {"solve",  "this", "problem", "and", "you", "will", "be", "the", "best"};
    vector<int> a= {0, 1, 2, 3, 4, 5, 6, 7, 8};
//   x
    for (int i = 0; i <= 362879; i++){
        if (i != 0 && i % 20 == 0) cout << '\n';
        vector<string> s;
        for (int j = 0; j <= 8; j++){
            s.push_back(ss[a[j]]);
        }
        int x= i * i;
        cout << x << " ";
        for (int j =0; j < s.size(); j++){
            int xx =i  % (s[j].size());
            for (int k = xx; k < s[j].size(); k++){
                cout << s[j][k];
            }
            for (int k = 0; k < xx; k++){
                cout << s[j][k];
            }
            cout << " ";
        }
          next_permutation(a.begin(), a.end());
    }
    cout << "\nSolved? Cool!";
    return 0;
}