#include <iostream>
#include <vector>
#include <algorithm>

using namespace  std;

#define int long long

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    freopen("rps.in", "r", stdin);
    freopen("rps.out", "w", stdout);
    int a, b, c;
    cin >> a >> b >> c;
    int a2, b2, c2;
    cin >> a2 >> b2 >> c2;
    cout << min(a, b2) + min(b, c2) + min(c, a2);
    return 0;
}
