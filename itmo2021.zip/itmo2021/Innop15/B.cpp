#include <iostream>
#include <vector>
#include <algorithm>

using namespace  std;

#define int long long

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    freopen("registration.in", "r", stdin);
    freopen("registration.out", "w", stdout);
    int h;
    cin >> h;
    int n, m, a, b;
    cin >> n >> m >> a >> b;
    if (n == 0){
        if (b >= m){
            cout << "YES\n";
            if (h){
                for (int  i =0 ; i < m; i++) {
                    cout << "B";
                }
            }
        }
        else{
            cout << "NO\n";
        }
        return 0;
    }
    if (m == 0){
        if (a >= n){
            cout << "YES\n";
            if (h){
                for (int  i =0 ; i < n; i++) {
                    cout << "G";
                }
            }
        }
        else{
            cout << "NO\n";
        }
        return 0;
    }
    if (n <= m){
        int x = m / b;
        if (m % b != 0) x++;
        if (x > n + 1){
            cout << "NO";
        }
        else{
            cout << "YES\n";
            if (h == 1){
                vector<int> cnt(n, 1);
                m -= n;
                for (int i = 0; i < n; i++){
                    cnt[i] += min(m, b - 1);
                    m -= b - 1;
                    if (m <= 0) break;
                }
                for (int i = 0; i < m; i++){
                    cout << "B";
                }
                for (int i = 0; i < n; i++){
                    cout << "G";
                    for (int j =0 ; j  < cnt[i]; j++){
                        cout << "B";
                    }
                }
            }
        }
    }
    else{
        int x = n / a;
        if (n % a != 0) x++;
        if (x > m + 1){
            cout << "NO";
        }
        else{
            cout << "YES\n";
            if (h == 1){
                vector<int> cnt(m, 1);
                n -= m;
                for (int i = 0; i < m; i++){
                    cnt[i] += min(n, a - 1);
                    n -= a - 1;
                    if (n <= 0) break;
                }
                for (int i = 0; i < n; i++){
                    cout << "G";
                }
                for (int i = 0; i < m; i++){
                    cout << "B";
                    for (int j =0 ; j  < cnt[i]; j++){
                        cout << "G";
                    }
                }
            }
        }
    }
    return 0;
}
