#include <iostream>
#include <vector>
#include <algorithm>

using namespace  std;

#define int long long

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    freopen("encode.in", "r", stdin);
    freopen("encode.out", "w", stdout);
    int n;
    cin >> n;
    vector<int> lst;
    for (int i= 0; i < n; i++){
        char x;
        cin >> x;
        lst.push_back(x - '0');
    }
    vector<int> pr = lst;
    for (int i = 1; i < n; i++){
        pr[i] += pr[i - 1];
    }
    vector<int> used(n + 2, 1);
    for (int i = 1; i <= n; i++){
        for (int j = 1; j * j <= i; j++){
            if (i % j == 0){
                int k = j - 1;
                if (k >= 1){
                    int x = 0;
                    if (i - j  - 1 >= 0){
                        x = pr[i - j - 1];
                    }
                    int cnt = pr[i - 2] - x;
                    if (cnt % 2 == 1 && lst[i - 1] == 0){
                        used[k] = 0;
                    }
                    if (cnt % 2 == 0 && lst[i - 1] == 1){
                        used[k] = 0;
                    }
                }
                k = i / j - 1;
                if (k >= 1){
                    int x = 0;
                    if (i - k - 1 - 1 >= 0){
                        x = pr[i - k - 1 - 1];
                    }
                    int cnt = pr[i - 2] - x;
                    //cerr << i << " " << k << " " << pr[i - 2] << " " << x << '\n';
                    if (cnt % 2 == 1 && lst[i - 1] == 0){
                        used[k] = 0;
                    }
                    if (cnt % 2 == 0 && lst[i - 1] == 1){
                        used[k] = 0;
                    }
                }
            }
        }
    }
    int ans = 0;
//    for (int i = 1; i < n; i++){
//        cerr << used[i] << " ";
//    }
    for (int i = 1; i < n; i++){
        ans += used[i];
    }
    cout << ans;
    return 0;
}
