#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>

using namespace  std;

#define int long long

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    freopen("origami.in", "r", stdin);
    freopen("origami.out", "w", stdout);
    double n, x, y;
    cin >> n >> x >> y;
    if (max(x, y) == n){
        if (x < y) swap(x, y);
        cout << setprecision(20) << fixed << n * n - (n - y) * n / 2.0;
        return 0;
    }
    if (x > y){
        swap(x, y);
    }
    double a = (n - x) / 2.0, b = (n - y) / 2.0, c = - (a * (a + x) + b * (b + y));
    double p1 = -(c + b * n) / a, p2  = -(c + a * n) / b, p3 = -c/a;
    double p4 = -c / b;
    double ans= 0;
    ans += p1 * n;
    ans += (p3 - p1) * n / 2.0;
    if (p2 > 0) ans -= p2 * (p3 - n) / 2.0;
    if (p4 < n) ans += (n - p4) * p1 / 2.0;
    cout << setprecision(20) << fixed <<  ans;
    return 0;
}