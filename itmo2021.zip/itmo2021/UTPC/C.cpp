#include <iostream>
#include <vector>
#include <iostream>
#include <algorithm>

using namespace  std;

vector<int> p1 = {1, -1, 0, 0};
vector<int> p2 = {0, 0, 1, -1};

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, m;
    cin >> n >> m;
    vector<vector<char>> lst;
    for (int i =0; i < n; i++){
        lst.push_back({});
        for (int j =0; j < m; j++){
            char x;
            cin >> x;
            lst[i].push_back(x);
        }
    }
    for (int i =0; i < n; i++){
        for (int j =0; j < m; j++){
            if (lst[i][j] != 'P') continue;
            for (int k = 0; k < 4; k++){
                int ii = i + p1[k], jj = j + p2[k];
                if (ii >= n || ii < 0 || jj >= m || jj < 0) continue;
                if (lst[ii][jj] == 'W'){
                    cout << "No";
                    return 0;
                }
            }
        }
    }
    cout << "Yes";
    return 0;
}
