#include <iostream>
#include <vector>
#include <iostream>
#include <algorithm>

using namespace  std;

int gcd(int a, int b){
    if (a == 0 || b == 0){
        return a + b;
    }
    return gcd(b, a % b);
}
signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int x, a, b;
    cin >> x >> b >> a;
    while (x != 0) {
        //cerr << x;
        int g = gcd(a, x);
        x -= g;
        if (x == 0) {
            cout << 0;
            return 0;
        }
        g = gcd(b, x);
        x -= g;
    }
    if (x == 0){
        cout << 1;
        return 0;
    }
    return 0;
}
