#include <iostream>
#include <vector>
#include <iostream>
#include <algorithm>

using namespace  std;

vector<vector<int>> lst;
vector<int> used;
int pos = 0;
int n;
int cur = 0, ans= 0 ;

void gen(){
    if (pos == n){
        ans = max(ans, cur);
        return;
    }
    for (int i =0 ; i  < n; i++){
        if (!used[i]){
            used[i] = 1;
            cur += lst[pos][i];
            pos++;
            gen();
            pos--;
            cur -= lst[pos][i];
            used[i] = 0;
        }
    }
}
signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    used.assign(n, 0);
    for (int i =0; i < n; i++){
        lst.push_back({});
        for (int j =0; j < n; j++){
            int x;
            cin >> x;
            lst[i].push_back(x);
        }
    }
    gen();
    cout << ans;
    return 0;
}
