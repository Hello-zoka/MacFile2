#include <iostream>
#include <vector>
#include <iostream>
#include <algorithm>
#include <queue>

using namespace std;
int l;

vector<bool> used;
vector<vector<int>> lst, lstr;
vector<int> order, comp;

void dfs1(int v) {
    used[v] = true;
    for (size_t i = 0; i < lst[v].size(); ++i)
        if (!used[lst[v][i]])
            dfs1(lst[v][i]);
    order.push_back(v);
}

void dfs2(int v) {
    used[v] = true;
    comp.push_back(v);
    for (size_t i = 0; i < lstr[v].size(); ++i)
        if (!used[lstr[v][i]])
            dfs2(lstr[v][i]);
}

vector<vector<int>> g;
vector<int> co;

void dfs3(int st = 0) {
    int mx = 0;
    for (int to : g[st]) {
        dfs3(to);
        mx = max(co[g[st][to]], mx);
    }
    co[st] += mx;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, m;
    cin >> n >> m;
    cin >> l;
    int k;
    cin >> k;
    vector<int> gd(l + 1, 0);
    for (int i = 0; i < k; i++) {
        int x;
        cin >> x;
        gd[x] = 1;
    }
    lst.assign(l + 1, {});
    lstr.assign(l + 1, {});
    vector<pair<int, int>> edg;
    for (int i = 0; i <= l; i++) {
        if (i + n <= l) {
            lst[i].push_back(i + n);
            lstr[i + n].push_back(i);
            edg.push_back({i, i + n});
        }
        if (i - m >= 0) {
            lst[i].push_back(i - m);
            lstr[i - m].push_back(i);
            edg.push_back({i, i - m});
        }
    }
    used.assign(l + 1, false);
    vector<int> col(l + 1, -1);
    int cnt = 0;
    for (int i = 0; i <= l; ++i)
        if (!used[i])
            dfs1(i);
    used.assign(l + 1, false);
    for (int i = 0; i < l + 1; ++i) {
        int v = order[l - i];
        if (!used[v]) {
            dfs2(v);
            int dop = 0;
            for (int j : comp) {
                col[j] = cnt;
                if (gd[j]) {
                    dop++;
                }
            }
            co.push_back(dop);
            cnt++;
            comp.clear();
        }
    }
    g.assign(cnt, {});
    for (int i = 0; i < edg.size(); i++) {
        if (col[edg[i].first] != col[edg[i].second]) {
            g[col[edg[i].first]].push_back(col[edg[i].second]);
        }
    }
    dfs3(col[0]);
    cout << co[col[0]];
    return 0;
}
