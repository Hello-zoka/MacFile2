#include <iostream>
#include <vector>
#include <iostream>
#include <algorithm>
#include <queue>

using namespace  std;


signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    string s;
    string ans ="";
    cin >> s;
    vector<string> lst = {"9681", "8961", "6981", "6891", "8691", "9861", "1896"};
    int a = 0, b = 0, c = 0, d = 0;
    vector<char> cur;
    for (int i = 0; i < s.size(); i++){
        if (s[i] == '1' && a == 0){
            a = 1;
        }
        else if (s[i] == '6' && b == 0){
            b = 1;
        }
        else if (s[i] == '8' && c == 0){
            c = 1;
        }
        else if (s[i] == '9' && d == 0){
            d = 1;
        }
        else{
            cur.push_back(s[i]);
        }
    }
    sort(cur.begin(), cur.end());
    reverse(cur.begin(), cur.end());
    if (cur.size() == 0){
        cout << lst[0];
        return 0;
    }
    if (cur[0] == '0'){
        ans = lst[0];
        for (int i =0; i < cur.size(); i++){
            ans += cur[i];
        }
    }
    else{
        int st = 10000 % 7;
        int x = 0;
        for (int i = cur.size() - 1; i >= 0; i--){
            ans += cur[i];
            x += st * (cur[i] - '0');
            st *= 10;
            st %= 7;
            x %= 7;
        }
        reverse(ans.begin(), ans.end());
        ans += lst[(7 - x) % 7];
    }
    cout << ans;
    //cout << 8755229861 % 7;
    return 0;
}
