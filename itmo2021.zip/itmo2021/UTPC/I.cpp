#include <vector>
#include <algorithm>
#include <iostream>


using namespace  std;
#define ll long long

struct e{
    int u, v;
    ll c;
};
vector<e> edg;
vector<int> mt;
int n;
int k = 0;
vector<vector<int>> lst;
vector<int> used;
int timer = -1, timer2 = -1;

bool try_kun(int st) {
    if (used[st] == timer) return false;
    used[st] = timer;
    for (int to : lst[st]) {
        if (mt[to] == -1) {
            mt[to] = st;
            return true;
        }
    }
    for (int to : lst[st]) {
        if (try_kun(mt[to])) {
            mt[to] = st;
            return true;
        }
    }
    return false;
}

int prevv = 0;
vector<ll> curr;

bool ch(ll x) {
    lst.assign(n, {});
    for (int i = 0; i < edg.size(); i++){
        if (edg[i].c >= x){
            lst[edg[i].u].push_back(edg[i].v);
        }
    }
    mt.assign(n, -1);
    for (int i = 0; i < n; i++) {
        timer++;
        try_kun(i);
    }
    int cnt = 0;
    for (int i = 0; i < n; i++) {
        if (mt[i] != -1) {
            cnt++;
        }
    }
    //cerr << cnt << " " << x << '\n';
    return cnt == n;
}


int bin() {
    int l = 0, r = 100001;
    while (l + 1 != r) {
        int mi = (l + r) / 2;
        if (ch(mi))
            l = mi;
        else
            r = mi;
    }
    return l;
}

signed main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    used.assign(n, -2);
    for (int i =0; i < n; i++){
        for (int j =0; j < n; j++){
            e cur = {i, j, (ll)0};
            ll x;
            cin >> x;
            cur.c = x;
            edg.push_back(cur);
        }
    }
    sort(edg.begin(), edg.end(), [&](const e & a, const e & b){return a.c < b.c;});
    cout << bin();
}