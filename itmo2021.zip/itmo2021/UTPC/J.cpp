#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

#define int long long

struct pt {
    int x, y;
    bool operator==(const pt &rhs) const {
        return x == rhs.x &&
               y == rhs.y;
    }

    bool operator!=(const pt &rhs) const {
        return !(rhs == *this);
    }
};

int cw(pt a, pt b, pt c){
    return (b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y);
}
void vipc(vector<pt> &lst) {
    sort(lst.begin(), lst.end(), [&](const pt &a, const pt &b) {
        if (a.x == b.x) return a.y < b.y;
        return a.x < b.x;
    });
    lst.resize(unique(lst.begin(), lst.end()) - lst.begin());
    vector<pt> res;
    for (int i =0; i < lst.size(); i++){
        while (res.size() >= 2 && cw(res[res.size() - 2], res.back(), lst[i]) <= 0){
            res.pop_back();
        }
        res.push_back(lst[i]);
    }
    int sz = res.size();
    for (int i = lst.size() - 1; i >= 0; i--){
        while (res.size() > sz && cw(res[res.size() - 2], res.back(), lst[i]) <= 0){
            res.pop_back();
        }
        res.push_back(lst[i]);
    }
    swap(lst, res);
    lst.pop_back();
}
int sq(vector<pt> &lst) {
    int res = 0;
    for (int i = 0; i < lst.size(); i++) {
        pt p2 = lst[i], p1 = lst[(i - 1 + lst.size()) % lst.size()];
        res += (p1.x - p2.x) * (p1.y + p2.y);
    }
    return abs(res) / 2;
}
int gcd(int a, int b){
    if (a == 0 || b == 0){
        return a + b;
    }
    return gcd(b, a % b);
}
int cel(vector<pt>&lst){
    int n = lst.size();
    if (n < 3) {
        //cout << 0;
        return 0;
    }
    int s = sq(lst);
    int cel = 0;
    for (int i = 0; i < n; i++) {
        cel += gcd(abs(lst[i].x - lst[(i - 1 + n) % n].x), abs(lst[i].y - lst[(i - 1 + n) % n].y));
    }
    return s - cel / 2 + 1;
}
struct ang {
    int a, b;
};


bool operator<(const ang &a, const ang &b) {
    if (b.b == 0 && a.b == 0) {
        return a.a < b.a;
    }
    return a.a * b.b < b.a * a.b;
}

int sq(pt a, pt b, pt c) {
    return a.x * (b.y - c.y) + b.x * (c.y - a.y) + c.x * (a.y - b.y);
}
bool ptsOnLine(const pt &a, const pt &b, const pt &c) {
    return (c.x * (b.y - a.y) - c.y * (b.x - a.x) == a.x * b.y - b.x * a.y);
}

int insid(vector<pt> &lst, vector<pt>&fl) {
    int ind = -1;
    int n = lst.size();
    for (int i = 0; i < n; i++) {
        if (ind == -1 || lst[i].x < lst[ind].x || (lst[i].x == lst[ind].x && lst[i].y < lst[ind].y)) {
            ind = i;
        }
    }
    pt st = lst[ind];
    rotate(lst.begin(), lst.begin() + ind, lst.end());
    lst.erase(lst.begin());
    n--;
    vector<ang> a(n);
    for (int i = 0; i < lst.size(); i++) {
        a[i].a = lst[i].y - st.y;
        a[i].b = lst[i].x - st.x;
        if (a[i].a == 0)
            a[i].b = a[i].b < 0 ? -1 : 1;
    }
    int k = 0;
    for (int i = 0; i < fl.size(); i++) {
        pt cur;
        cur = fl[i];
        bool in = false;
        if (cur.x >= st.x) {
            if (cur.x == st.x && cur.y == st.y) {
                in = false;
            } else {
                ang x = {cur.y - st.y, cur.x - st.x};
                if (x.a == 0) {
                    x.b = x.b < 0 ? -1 : 1;
                }
                auto it = upper_bound(a.begin(), a.end(), x);
                if (it == a.end() && x.a == a[n - 1].a && x.b == a[n - 1].b) {
                    it--;
                }
                if (it != a.end() && it != a.begin()) {
                    int p1 = (int) (it - a.begin());
                    if (sq(lst[p1], lst[p1 - 1], cur) < 0 && (i == 1 || !ptsOnLine(st, cur, lst[p1 - 1])) && (i == lst.size() - 1 || !ptsOnLine(st, cur, lst[p1]))) {
                        in = true;
//                        cout << cur.x << " " << cur.y << '\n';
//                        cout << p1 << " ";
                    }
                }
            }
        }
        if (in) k++;
    }
    return k;
}
signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    vector<pt> lst;
    for (int i = 0; i < n; i++){
        pt x;
        cin >> x.x >>x.y;
        lst.push_back(x);
    }
    vector<pt> vip = lst;
    vipc(vip);
    int ans = vip.size();
    int x = cel(vip);
//    for (int i =0; i < vip.size(); i++){
//        cerr << vip[i].x << " " << vip[i].y << '\n';
//    }
    int a = insid(vip, lst);
    cout << x - a << "\n" << n - a;
}
