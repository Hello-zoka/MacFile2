#include <iostream>
#include <vector>
#include <math.h>

using namespace std;

int main() {
    int n;
    cin >> n;
    vector<int> lst;
    for (int i= 0; i < n; i++){
        int x;
        cin >> x;
        lst.push_back(x);
    }
    int ind = 0;
    while (true){
        int mn = 1007, mx =-1;
        for (int i = 0; i < n; i++){
            if (lst[i] > mx){
                mx = lst[i];
                ind = i;
            }
            if (lst[i] < mn) mn = lst[i];
        }
        if (mx == mn){
            cout << mn;
            return 0;
        }
        lst[ind] -= mn;
    }

    return 0;
}