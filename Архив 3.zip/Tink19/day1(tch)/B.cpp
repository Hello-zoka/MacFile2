#include <iostream>
//#include <vector>

using namespace std;

unsigned long long a, m;

long long gcd (long long a, long long b, long long & x, long long & y) {
    if (a == 0) {
        x = 0; y = 1;
        return b;
    }
    long long x1, y1;
    long long d = gcd (b % a, a, x1, y1);
    x = y1 - (b / a) * x1;
    y = x1;
    return d;
}

int main() {
    cin >> a >> m;
    if (m == 1 || m == 0){
        cout << -1;
        return 0;
    }
    long long x, y;
    long long g = gcd(a, m, x, y);
    //cout << x;
    if (g != 1)
        cout << -1;
    else
        cout << (x + m) % m;
    return 0;
}