#include <iostream>
#include <vector>
#include <math.h>

using namespace std;

int main() {
    long long n;
    cin >> n;
    vector<long long> a = {0}, lst;
    for (long long i = 0; i < n; i++){
        long long x;
        cin >> x;
        a.push_back(x);
    }
    lst.assign(n + 1, a[1]);
    for (long long i = 2; i <= n; i++){
        for (long long j = i; j <= n; j += i){
            lst[j]+= a[i];
        }
    }
    for (long long i = 1;i <= n; i++){
        cout << lst[i]<< " ";
    }
    return 0;
}