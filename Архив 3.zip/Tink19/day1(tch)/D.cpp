#include <iostream>
#include <vector>
#include <math.h>

using namespace std;

int main() {
    long long n;
    cin >> n;
    vector<long long> a = {0}, lst;
    lst.assign(n + 2, 1);
    a.assign(int(sqrt(n * n + n)) + 2, 1);
    a[1] = 0;
    for (long long i = 2; i <= int(sqrt(a.size())) + 2; i++){
        if (a[i]){
            for (long long j = i * i; j < a.size(); j += i){
                a[j] = 0;
            }
        }
    }
    for (long long i = 2; i <= int(sqrt(n * n + n)) + 2; i++){
        //cout << i << " " << (i + ((n * n - i) / i ) * i) -  n * n + n << '\n';
        if (a[i]){
            for (long long j = (i + ((n * n - i) / i ) * i) -  n * n; j <= n; j += i){
                if (j >= 0)
                    lst[j] = 0;
            }
        }
    }
    int ans =0;
    for (int i = 0; i < n; i++){
        ans += lst[i];
    }
    cout << ans;
    return 0;
}