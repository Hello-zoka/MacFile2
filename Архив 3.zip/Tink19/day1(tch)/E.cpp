#include <iostream>
#include <vector>
#include <math.h>
#include <bitset>

using namespace std;

int main() {
    long long n;
    cin >> n;
    bitset<100000007> lst;
    lst.set();
    lst[1] = false;
    for (long long i = 2; i <= n; i++){
        if (lst[i]){
            for (long long j = i * i; j <= n; j += i){
                lst[j] = false;
            }
        }
    }
    long long ans = 0;
    for (long long i = 1; i <= n; i++){
        if (lst[i]) ans++;
    }
    cout << ans;
    return 0;
}