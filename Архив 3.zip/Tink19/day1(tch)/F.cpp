#include <iostream>
#include <vector>
#include <math.h>
#include <bitset>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int m;
    cin >> m;
    int r[m + 2];
    r[1] = 1;
    int b = 1;
    long long sum = 1;
    for (long long i = 2; i < m; ++i){
        b = 1;
        r[i] = (m - (m / i) * r[m % i] % m) % m;
        sum += r[i] % m;
        sum %= m;

        if (i % 100 == 0){
            cout << sum << " ";
            sum = 0;
            b = 0;
        }

    }
    if (b)
        cout << sum;
    return 0;
}