#include <iostream>
#include <vector>
#include <math.h>
#include <bitset>

using namespace std;
long long m;

long long bp (long long a, long long n) {
    long long res = 1;
    while (n) {
        if (n & 1) res = res * a % m;
        a = a * a % m;
        n >>= 1;
    }
    return res;
}


long long inv (long long x) {
    return bp(x, m - 2);
}
signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> m;

    long long k = 100;
    long long ofac[m / k + 3];
    long long fac[m / k + 3];
    long long sum[m / k + 3];
    long long per = (m - 1) / 100 + ((m - 1) % 100 == 0 ? 0 : 1);

    long long fc =1;
    fac[0] = 1;
    ofac[0] = 1;

    for (long long i = 1; i < m; i++){
        fc *= i;
        fc %= m;
        if (i % k == 0){
            fac[i / k] = fc;
            ofac[i / k] = inv(fc);
        }

    }
    fac[per] = fc;
    ofac[per] = inv(fc);

    long long  ff = 1, of = 1;
    for (long long i = 0; i < per; i++){
        vector<long long> ofacc(k + 1, 0);
        long long st = i * k + 1 , fn = min(m - 1, i * k + k);
        sum[i] = inv(fn);


        of = ofac[i + 1];
        for (long long j = fn - 1; j >= st; j--) {
            of = ((j + 1) * 1LL * of) % m;
            ofacc[j - st] = of;
        }

        ff = fac[i];

        for (long long j = st; j < fn; j++) {
            if(j == 0) continue;
            long long x = (ff * 1LL * ofacc[j - st]) % m;
            ff = (ff * j) % m;
            //cerr << x << " " << j<< "\n";
            sum[(j - 1) / k] = (sum[(j - 1) / k] + x) % m;
        }
    }
    for (long long i = 0; i < per; i++){
        cout << sum[i] << " ";
    }

    return 0;
}