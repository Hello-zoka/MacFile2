#include <iostream>
#include <vector>
#include <math.h>
#include <bitset>

using namespace std;

int main() {
    long long m;
    cin >> m;
    if (m == 1 || m == 2)
        cout << 1;
    else
        cout << 0;
}