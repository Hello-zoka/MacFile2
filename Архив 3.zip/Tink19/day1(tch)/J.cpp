#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

//#define int long long
#define MOD 1000000007
#define ll long long
signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    vector<int> lst;
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        lst.push_back(x);
    }
    vector<int> used(1000007, 0), b(1000007, 0);
    vector<int> st = {0};
    ll ss = 1;
    for (int i = 0; i < n + 5; i++){
        st.push_back(ss);
        ss *= 2;
        ss %= MOD;
    }
    for (int i = 0; i < n; i++) {
        for (int j = 1; j * j <= lst[i]; j++) {
            if (lst[i] % j == 0) {
                used[j]++;
                if (j * j != lst[i]) used[lst[i] / j]++;
            }
        }
    }
    //cerr << 11;
    ll ans = 0;
    //int mx = 0;
    for (int i = 1000005; i > 1; i--) {
        if (used[i] != 0) {
            int k = (1LL * st[used[i]] * used[i]) % MOD;
            b[i] = k;
            //mx = max(mx, i);
            for (int x = 2; x * i <= 1000005; x++) {
                b[i] -= b[i * x];
                b[i] = (1LL * b[i] + MOD) % MOD;
            }
            ans += (1LL * b[i] * i) % MOD;
            ans %= MOD;
        }
    }
    cout << ans;
    return 0;
}