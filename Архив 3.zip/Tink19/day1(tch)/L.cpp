#include <iostream>
#include <vector>
#include <math.h>
#include <bitset>

using namespace std;

int p[100000007];
int a[100000007];
vector<int> primes;


int phi (int n) {
    int result = n;
    int i = n;
    if (a[i] == i)
        return n - 1;
    if (a[i] != 1)
        return p[a[i]] * p[n / a[i]];

    for (int i: primes)
        if (n % i == 0) {
            while (n % i == 0)
                n /= i;
            result -= result / i;

            break;
        }

    if (n > 1)
        result -= result / n;
    return result;

}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;

    long long ans = 1;
    int b = 1;
    for (int i = 2; i <= n; ++i) {
        int bl = 0;
        if (a[i] == 0) {
            a[i] = i;
            bl = 1;
            primes.push_back(i);
        }
        int pl  =0;
        for (int x : primes) {
            if (pl || 1ll * x * i > n)
                break;
            if (i % x == 0) pl =1;
            if (!bl)
                if (i % x == 0 && a[i] % x != 0)
                    a[x * i] = a[i];
                else
                    a[x * i] = a[i] * x;
            else
            if (i == x)
                a[x * i] = 1;
            else
                a[x * i] = i;
        }

        b = 1;
        int x = phi(i);

        p[i] = x;

        ans += x;
        if (i % 100 == 0){
            cout << ans << " ";
            b = 0;
            ans = 0;
        }
    }

    if (b) cout << ans;
    return 0;
}