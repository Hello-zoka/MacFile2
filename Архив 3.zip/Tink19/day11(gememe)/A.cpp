#include <iostream>
#include <vector>
#include <stack>

using namespace std;

#define int long long

signed main() {
    //1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18
    //W L W W L W L W L W  L  W  L  W  L  W  L
    int n;
    cin >> n;
    if (n == 1){
        cout << "Ivan Urgant\nDraw";
    }
    else if (n == 2){
        cout << "Ivan Safonov";
    }
    else if (n == 3){
        cout << "Ivan Urgant\nDraw";
    }
    else if (n == 4){
        cout << "Ivan Urgant\nMix";
    }
    else{
        if (n % 2 != 0){
            cout << "Ivan Safonov";
        }
        else {
            cout << "Ivan Urgant\nDraw";
        }
    }
    return 0;
}