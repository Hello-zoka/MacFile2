#include <iostream>
#include <vector>
#include <stack>

using namespace std;

#define int long long

int n, m;
vector<vector<int>> lst;
vector<int> deg, used, l, w;
stack<int> q;

void bfs(){
    while (!q.empty()){
        int v = q.top();
        q.pop();
        if (l[v]){
            for (int to:lst[v]){
                if (!used[to]){
                    used[to] = 1;
                    w[to] = 1;
                    q.push(to);
                }
            }
        }
        else if (w[v]){
            for (int to: lst[v]){
                if (!used[to]) {
                    deg[to]--;
                    if (deg[to] == 0){
                        used[to] = 1;
                        l[to] = 1;
                        q.push(to);
                    }
                }
            }
        }
    }
}
signed main() {
    while (cin >> n){
        cin >> m;
        lst.assign(n, {});
        deg.assign(n, 0);
        for (int i = 0; i  < m; i++){
            int a, b;
            cin >> a >> b;
            a--;
            b--;
            lst[b].push_back(a);
            deg[a]++;
        }
        used.assign(n, 0);
        l.assign(n, 0);
        for (int i =0 ; i < n; i++){
            if (!deg[i]){
                q.push(i);
                used[i] = 1;
                l[i] = 1;
            }
        }
        w.assign(n, 0);
        bfs();
        for (int i = 0; i < n; i++){
            if (!used[i]) cout << "DRAW\n";
            else if (w[i]) cout << "FIRST\n";
            else cout << "SECOND\n";
        }
    }

    return 0;
}