#include <iostream>
#include <vector>

using namespace std;

#define int long long


signed main() {
    int t;
    cin >> t;
    for (int q= 0; q < t; q++){
        int n;
        cin >> n;
        vector<int> lst;
        int cur =0;
        for (int i = 0; i < n; i++){
            int x;
            cin >> x;
            if (x % 4 == 1 || x % 4 == 2){
                lst.push_back(x);
            }
            else if (x % 4 == 3) lst.push_back(x + 1);
            else lst.push_back(max((int)0, x - 1));
            cur ^= lst[lst.size() - 1];
        }
        if (cur == 0) cout << "SECOND\n";
        else cout << "FIRST\n";
    }

    return 0;
}