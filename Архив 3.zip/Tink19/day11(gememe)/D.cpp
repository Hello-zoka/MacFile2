#include <iostream>
#include <vector>
#include <stack>
#include <math.h>

using namespace std;

#define int long long

signed main() {
    int n;
    cin >> n;
    vector<int> a, ans;
    int k = (int)(sqrt(n)) + 2;
    a.assign(k, 0);
    ans.assign(k, 0);

    int cou = 0;
    for (int i = 2; i < k; i++){
        if (a[i] == 0){
            cou++;
            for (int j = i * i; j < k; j+= i){
                a[j] = 1;
            }
            ans[i] = cou;
        }
    }
    int cur = 0;
    int bl = 1;
    for (int i = 2; i < k; i++){
        if (n % i == 0){
            bl= 0;
            int x = n;
            int cnt = 0;
            while (x % i == 0){
                cnt++;
                x /= i;
            }
            if (cnt % 2 != 0){
                cur ^= ans[i];
            }
            //cerr << i << " " << a[i] << "\n";
        }
    }
    if (n == 1){
        cout << "Vasya";
        return 0;
    }
    if (bl){
        cout << "David";
        return 0;
    }
    //cerr << cur;
    if (cur == 0){
        cout << "Vasya";
    }
    else cout << "David";

    return 0;
}