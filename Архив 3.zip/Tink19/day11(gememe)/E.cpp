#include <iostream>
#include <vector>
#include <stack>

using namespace std;

#define int long long

signed main() {
    int n;
    cin >> n;
    int ans= 0;
    vector<pair<int, int>> lst;
    for (int i =0; i < n; i++){
        int l, r;
        cin >> l >> r;
        lst.push_back({l, r});
        if (l % 2 != 0) {
            ans ^= l;
            l++;
        }
        if (l > r) continue;
        if (r % 2 == 0) {
            ans ^= r;
            r--;
        }
        if (l > r) continue;
        if ((r - l + 1) / 2 % 2 != 0) ans ^= 1;
    }
    if (ans == 0) cout << "Lose";
    else{
        cerr << ans;
        cout << "Win\n";
        int k = 1, cur = 1, cnt = 0;
        while (cur <= ans){
            if (cur & ans) k = cur;
            cur *= 2;
            cnt++;
        }
        cur = k;
        if (cur == 1){
            for (int i =0; i < n; i++){
                if (lst[i].first % 2 != 0){
                    cout << lst[i].first << "\n" << lst[i].first - 1;
                    return 0;
                }
                if (lst[i].first + 1 <= lst[i].second){
                    cout << lst[i].first + 1 << "\n" << lst[i].first;
                    return 0;
                }
            }
        }
        for (int i =0; i < n; i++){
            int l = lst[i].first, r = lst[i].second;
            if (l & cur){
                cout << l;
                int c = 1, cr = 1;
                int nxt = 0;
                while (cr <= l){
                    if ((ans & cr) && !(l & cr)){
                        nxt += cr;
                    }
                    else if (!(ans & cr) && (l & cr)){
                        nxt += cr;
                    }
                    cr *= 2;
                }
                cout << '\n' << nxt;
                return 0;
            }

            if (r & cur){
                cout << r;
                int c = 1, cr = 1;
                int nxt = 0;
                while (cr <= r){
                    if ((ans & cr) && !(r & cr)){
                        nxt += cr;
                    }
                    else if (!(ans & cr) && (r & cr)){
                        nxt += cr;
                    }
                    cr *= 2;
                }
                cout << '\n' << nxt;
                return 0;
            }
        }
    }
    return 0;
}