#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

#define int long long
#define INF 1e9 + 7

struct line {
    int m, c;

    line(int m, int c) : m(m), c(c) {}

    int val(int x) {
        return m * x + c;
    }
};

int cur;
vector<line> st;

bool ok(line &l1, line &l2, line &l3) {
    int a1 = l2.c - l1.c, b1 = l1.m - l2.m;
    if (b1 < 0) {
        a1 *= -1;
        b1 *= -1;
    }
    int a2 = l3.c - l2.c, b2 = l2.m - l3.m;
    if (b2 < 0) {
        a2 *= -1;
        b2 *= -1;
    }
    return a1 * b2 < a2 * b1;
}

void add(int m, int c) {
    line l(m, c);
    while (st.size() >= 2 && !ok(st[st.size() - 2], st[st.size() - 1], l)) {
        st.pop_back();
    }
    st.push_back(l);
}

int get(int x) {
    if (st.empty())
        return 0;
    while (cur + 1 < (int)st.size() && st[cur].val(x) >= st[cur + 1].val(x)) {
        cur++;
    }
    return st[cur].val(x);
}

struct e {
    int h, w;
};

bool operator<(const e &a, const e &b) {
    if (a.w == b.w) return a.h > b.h;
    return a.w < b.w;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    vector<e> lst;
    vector<int> h, w;
    for (int i = 0; i < n; i++) {
        e a;
        cin >> a.w >> a.h;
        lst.push_back(a);
    }
    sort(lst.begin(), lst.end());
    vector<e> curr = {lst[0]};
    vector<int> dp;
    dp.push_back(INF);
    for (int i = 1; i < n; i++) {
        if (lst[i].w == curr[curr.size()].w) continue;
        if (lst[i].h < curr[curr.size() - 1].h) {
            dp.push_back(INF);
            curr.push_back(lst[i]);
        } else {
            while (!curr.empty() && curr[curr.size() - 1].h <= lst[i].h) {
                dp.pop_back();
                curr.pop_back();
            }
            dp.push_back(INF);
            curr.push_back(lst[i]);
        }
    }
    add(curr[0].h, 0);
    add(curr[1].h, dp[0]);
    for (int i = 0; i < curr.size(); i++) {
        dp[i] = get(curr[i].w);
        if (i != curr.size() - 1) {
            add(curr[i + 1].h, dp[i]);
        }
    }
    cout << dp[dp.size() - 1];
    return 0;
}