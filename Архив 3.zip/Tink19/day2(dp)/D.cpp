#include <iostream>
#include <vector>

using namespace std;

#define INF 100000000
#define MX 5500
vector<vector<int>> dp, opt;

signed main() {
    int n;
    while(cin >> n){
        dp.clear();
        opt.clear();
        vector<int> m;
        vector<int> pref;
        pref.assign(n + 3, 0);
        for (int i = 0; i < n + 3; i++){
            vector<int> p, p2;
            p.assign(n + 3, INF);
            p2.assign(n + 3, 0);

            dp.push_back(p);
            opt.push_back(p2);
        }
        m.push_back(INF);

        for (int i = 1; i <= n; i++){

            int x;
            cin >> x;
            m.push_back(x);
            pref[i] = pref[i - 1] + x;
            dp[i][i] = 0;
            opt[i][i] = i;
            if (m[i - 1] < m[i]){
                dp[i - 1][i] = m[i - 1];
                opt[i - 1][i] = i;
            }
            else{
                dp[i - 1][i] = m[i];
                opt[i - 1][i] = i - 1;
            }
            dp[i][i - 1] = dp[i + 1][i] = 0;
            opt[i][i - 1] = opt[i + 1][i] = 0;
        }

        for (int i = 2; i <= n; i++){
            for (int j = 1; j + i <= n + 1; j++){
                int  r = i + j - 1;
                if (r > n) break;
                for (int k = opt[j][r - 1]; k <= opt[j + 1][r]; k++){
                    //cerr << 1;
                    if (dp[j][r] > dp[j][k - 1] + dp[k + 1][r] + pref[r] - pref[j - 1] - m[k]){
                        dp[j][r] = dp[j][k - 1] + dp[k + 1][r] + pref[r] - pref[j - 1] - m[k];
                        opt[j][r] = k;
                    }
                }
            }
        }
        cout << dp[1][n] << '\n';
    }
    return 0;
}