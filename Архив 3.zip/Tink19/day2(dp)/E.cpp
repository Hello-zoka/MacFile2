#include <cstdio>
#include <string>
#include <map>
#include <queue>
#include <cstring>
#include <iostream>
#include <assert.h>
#include <algorithm>
#include <set>


using namespace std;

#define int long long

const int MAX = 100005;


int a[MAX], cnt[MAX];
int dp[30][MAX];
int cur = 0, L = 1, R = 0;

int cost(int l, int r) {
    while (R < r) cur += cnt[a[++R]]++;
    while (L > l) cur += cnt[a[--L]]++;
    while (R > r) cur -= --cnt[a[R--]];
    while (L < l) cur -= --cnt[a[L++]];
    return cur;
}

void d(int v, int l, int r, int optl, int optr) {
    if (l > r) return;
    int m = (l + r) / 2, opt = optl, mx = min(optr + 1, m);
    int ans =dp[v - 1][optl] + cost(optl + 1, m);
    for (int i = optl; i < mx; ++i) {
        int x = dp[v - 1][i] + cost(i + 1, m);
        if (x < ans) {
            ans = x;
            opt = i;
        }
    }
    dp[v][m] = ans;
    d(v, l, m - 1, optl, opt);
    d(v, m + 1, r, opt, optr);
}

signed main() {
    int n, k;
    cin >> n >> k;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
    }
    for (int i = 1; i <= n; i++) {
        dp[1][i] = cost(1, i);
    }
    for (int i = 2; i <= k  ; i++) {
        d(i, i, n, i - 1, n);
    }
    cout << dp[k][n];
    return 0;
}