#include <cstdio>
#include <string>
#include <map>
#include <queue>
#include <cstring>
#include <iostream>
#include <assert.h>
#include <algorithm>
#include <set>


using namespace std;
const int MAX = 100005;
#define INF 1000000007
#define int long long
bool Q;

struct Line {
    mutable int k, m, p;

    bool operator<(const Line &o) const {
        return Q ? p < o.p : k < o.k;
    }
};

struct LineContainer : multiset<Line> {
    int div(int a, int b) {
        return a / b - ((a ^ b) < 0 && a % b);
    }

    bool ok(iterator x, iterator y) {
        if (y == end()) {
            x->p = INF;
            return false;
        }
        if (x->k == y->k) x->p = x->m > y->m ? INF : -INF;
        else x->p = div(y->m - x->m, x->k - y->k);
        return x->p >= y->p;
    }

    void add(int k, int m) {
        auto z = insert({k, m, 0}), y = z++, x = y;
        while (ok(y, z)) z = erase(z);
        if (x != begin() && ok(--x, y)) ok(x, y = erase(y));
        while ((y = x) != begin() && (--x)->p >= y->p)
            ok(x, erase(y));
    }

    int query(int x) {
        assert(!empty());
        Q = 1;
        auto l = *lower_bound({0, 0, x});
        Q = 0;
        return l.k * x + l.m;
    }
};

vector<int> subsize, x, y;
vector<vector<int>> edg;
vector<int> ans;

void dfs1(int u, int v) {
    subsize[u] = 1;
    for (auto i:edg[u]) {
        if (i == v)continue;
        dfs1(i, u);
        subsize[u] += subsize[i];
    }
}

void dfs2(int v, int p, LineContainer &cur) {
    int mx = -1, bg = -1;
    bool leaf = true;
    for (auto u:edg[v]) {
        if (u != p and subsize[u] > mx) {
            mx = subsize[u];
            bg = u;
            leaf = false;
        }
    }
    if (bg != -1) {
        dfs2(bg, v, cur);
    }
    for (auto u:edg[v]) {
        if (u != p and u != bg) {
            LineContainer temp;
            dfs2(u, v, temp);
            for (auto i:temp) {
                cur.add(i.k, i.m);
            }
        }
    }
    if (!leaf)ans[v] = -cur.query(x[v]);
    else ans[v] = 0;
    cur.add(-y[v], -ans[v]);
}

signed main() {

    int n;
    cin >> n;
    x.assign(n + 1, 0);
    y.assign(n + 1, 0);
    ans.assign(n + 1, INF);
    subsize.assign(n + 1, INF);
    edg.resize(n + 1);
    for (int i = 1; i <= n; i++) {
        cin >> x[i];
    }
    for (int i = 1; i <= n; i++) {
        cin >> y[i];
    }
    for (int i = 0; i < n - 1   ; i++) {
        int u, v;
        cin >> u >> v;
        edg[u].push_back(v);
        edg[v].push_back(u);
    }
    dfs1(1, 0);
    LineContainer ln;
    dfs2(1, 0, ln);

    for (int i = 1 ; i <= n; i++){
        cout << ans[i] << " ";
    }
    return 0;
}