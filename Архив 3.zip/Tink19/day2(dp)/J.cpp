#include <cstdio>
#include <string>
#include <map>
#include <queue>
#include <cstring>
#include <iostream>
#include <bitset>
#include <algorithm>


using namespace std;
const int MAX = 100005;

struct line {
    long long m, c;

    line(long long m, long long c) :
            m(m), c(c) {
    }

    long long value(long long x) {
        return m * x + c;
    }
};

vector<line> set;
int cur;

void reset() {
    cur = 0, set.clear();
}

bool ok(line &l1, line &l2, line &l3) {
    long long a1 = l2.c - l1.c, b1 = l1.m - l2.m;
    if (b1 < 0) a1 *= -1, b1 *= -1;
    long long a2 = l3.c - l2.c, b2 = l2.m - l3.m;
    if (b2 < 0) a2 *= -1, b2 *= -1;
    return a1 * b2 < a2 * b1;
}

void add(long long m, long long c) {
    line l(m, c);
    while (set.size() > 1 && !ok(set[set.size() - 2], set.back(), l))
        set.pop_back();
    set.push_back(l);
}

long long get(long long x) {
    if (set.size() == 0)
        return 0;
    while (cur + 1 < (int) set.size() && set[cur].value(x) >= set[cur + 1].value(x))
        cur++;
    return set[cur].value(x);
}

long long d[MAX];
long long a[MAX];
long long s[MAX];
long long ant[MAX];
long long dp[MAX];

int main() {

    int n, m, p;

    cin >> n >> m >> p;

    for (int i = 1; i <  n; ++i) {
        cin >> d[i];
        d[i] += d[i - 1];
    }

    for (int i = 1; i <= m; ++i) {
        int h;
        cin >> h >> a[i];
        a[i] -= d[h - 1];
    }

    sort(a + 1, a + m + 1);

    for (int i = 1; i <= m; ++i)
        s[i] = s[i - 1] + a[i];

    for (int i = 1; i <= m; ++i)
        ant[i] = 1ll << 40;

    ant[0] = 0;
    for (int i = 0; i < p; ++i) {
        reset();
        for (int j = 1; j <= m; ++j) {
            add(-j + 1, s[j - 1] + ant[j - 1]);
            dp[j] = a[j] * j - s[j] + get(a[j]);
        }
        for (int j = 0; j <= m; ++j)
            ant[j] = dp[j];
    }

    cout << dp[m] << endl;

    return 0;
}
