#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <cmath>
#include <iomanip>

using namespace std;

const long double EPS = 0.00000000000000005;




signed main() {
    int n;
    cin >> n;
    vector<int> x(n), y(n);
    for (int i = 0; i < n; i++){
        cin >> x[i] >> y[i];
    }
    string s;
    cin >> s;
    int ind= -1;
    for (int i = 0; i < n ;i++){
        if (ind == -1 || x[ind] > x[i] || (x[ind] == x[i] && y[ind] > y[i]))
            ind = i;
    }
    vector<int> used;
    used.assign(n, 0);
    used[ind] = 1;
    cout << ind + 1 << " ";
    for (int i = 1; i < n; i++){
        int to = -1;
        for (int j = 0; j < n; j++){
            if (!used[j]){
                if (to == -1)
                    to = j;
                else{
                    long long now = (long long)(x[j] - x[ind]) * (long long)(y[to] - y[ind]) - (long long)(y[j] - y[ind]) * (long long)(x[to] - x[ind]);
                    if (s[i - 1] == 'R') now *= -1;
                    if (now > 0) to = j;
                }
            }

        }
        used[to] = 1;
        ind = to;
        cout << to + 1 << " ";
    }

    return 0;
}