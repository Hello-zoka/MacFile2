#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <cmath>

using namespace std;

struct point{
    long long x, y;
};
long long gccd(long long a, long long b) {
    if (a == 0 || b == 0) {
        return a + b;
    }
    return gccd(b, a % b);
}
long long sq (const vector<point> &fig)
{
    long long res = 0;
    for (unsigned i=0; i<fig.size(); i++)
    {
        point
                p1 = i ? fig[i-1] : fig.back(),
                p2 = fig[i];
        res += (p1.x - p2.x) * (p1.y + p2.y);
    }
    res = fabs(res);
    return res / 2;

}

signed main() {
    long long n;
    cin >> n;
    vector<point> lst;
    for (long long i = 0; i < n; i++){
        point a;
        cin >> a.x >> a.y;
        lst.push_back(a);
    }
    if (n == 1 || n == 2){
        cout << 0 << '\n';
        return 0;
    }
    long long s = sq(lst);
    long long q =0 ;
    for (long long i = 1; i < n; i++){
        q += gccd(fabs(lst[i].x - lst[i - 1].x), fabs(lst[i].y - lst[i - 1].y)) + 1;
    }
    q += gccd(fabs(lst[0].x - lst[n - 1].x), fabs(lst[n -1 ].y - lst[0].y)) + 1;
    q -= n;


    cout << s - q / 2 + 1;

    return 0;
}