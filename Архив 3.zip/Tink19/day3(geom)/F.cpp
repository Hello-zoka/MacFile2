#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <cmath>
#include <iomanip>

using namespace std;

const long double EPS = 0.0005;
#define int long long

struct point {
    int x, y;
    int ind;
};
struct Point {
    long double x, y;
    int ind;
};
struct Circle {
    Point center;
    long double r;

};

int sqr(int a) {
    return a * a;
}
bool PointsOnLine(const point &a, const point &b, const point &c) {
    return (c.x * (b.y - a.y) - c.y * (b.x - a.x) == a.x * b.y - b.x * a.y);
}
Circle build(const point &a, const point &b, const point &c) {
    if (PointsOnLine(a, b, c)){
        Circle per;
        per.r = -1;
        return per;
    }
    Circle cc;
    cc.center.x = -1.0 / 2 *
                  ((a.y * (sqr(b.x) + sqr(b.y) - sqr(c.x) - sqr(c.y))) +
                   b.y * (sqr(c.x) + sqr(c.y) - sqr(a.x) - sqr(a.y)) +
                   c.y * (sqr(a.x) + sqr(a.y) - sqr(b.x) - sqr(b.y))) /
                  (a.x * (b.y - c.y) + b.x * (c.y - a.y) + c.x * (a.y - b.y));
    cc.center.y = 1.0 / 2 *
                  ((a.x * (sqr(b.x) + sqr(b.y) - sqr(c.x) - sqr(c.y))) +
                   b.x * (sqr(c.x) + sqr(c.y) - sqr(a.x) - sqr(a.y)) +
                   c.x * (sqr(a.x) + sqr(a.y) - sqr(b.x) - sqr(b.y))) /
                  (a.x * (b.y - c.y) + b.x * (c.y - a.y) + c.x * (a.y - b.y));
    cc.r = abs(a.x - cc.center.x) * abs(a.x - cc.center.x) + abs(a.y - cc.center.y) * abs(a.y - cc.center.y);
    return cc;
}

signed main() {
    int n;
    cin >> n;
    vector<point> a;

    for (int i = 0; i < n; i++) {
        point f;
        cin >> f.x >> f.y;
        f.ind = i + 1;
        a.push_back(f);
    }
    if (n < 5) {
        if (n == 4) {
            cout << "2 1 2\n2 3 4";
        }
        if (n == 2){
            cout << "1 1\n1 2";
        }
        if (n == 3){
            cout << "1 1\n2 2 3";
        }
        return 0;
    }
    for (int i = 0; i < 5; i++) {
        for (int j = i + 1; j < 5; j++) {
            for (int k = j + 1; k < 5; k++) {
                Circle c1 = build(a[i], a[j], a[k]);
                if (c1.r == -1) continue;
                vector<point> p1 = {a[i], a[j], a[k]}, p2;
                for (int l = 0; l < n; l++) {
                    if (l != i && l != j && l != k) {
                        if (abs(abs(c1.center.x - a[l].x) * abs(c1.center.x - a[l].x) +
                                abs(c1.center.y - a[l].y) * abs(c1.center.y - a[l].y) - c1.r) <= EPS) {
                            p1.push_back(a[l]);
                        } else {
                            p2.push_back(a[l]);
                        }
                    }
                }
                int b = 1;
                Circle c2;
                if (p2.size() >= 3) {
                    c2 = build(p2[0], p2[1], p2[2]);
                    if (c2.r == -1) b =0;

                    for (int l = 3; l < p2.size(); l++) {
                        if (!b) break;
                        if (abs(abs(c2.center.x - p2[l].x) * abs(c2.center.x - p2[l].x) +
                                abs(c2.center.y - p2[l].y) * abs(c2.center.y - p2[l].y) - c2.r) > EPS) {
                            b = 0;
                            break;
                        }
                    }
                    if (b){
                        for (int l = 0; l < p1.size(); l++) {
                            if (abs(abs(c2.center.x - p1[l].x) * abs(c2.center.x - p1[l].x) +
                                    abs(c2.center.y - p1[l].y) * abs(c2.center.y - p1[l].y) - c2.r) <= EPS) {
                                p2.push_back(p1[l]);
                            }
                        }
                    }

                }
                if (b) {
                    if (p2.size() != 0){
                        cout << p1.size() << " ";
                        for (int i = 0; i < p1.size(); i++) {
                            cout << p1[i].ind << " ";
                        }
                        cout << "\n" << p2.size() << " ";
                        for (int i = 0; i < p2.size(); i++) {
                            cout << p2[i].ind << " ";
                        }
                    }
                    else{

                        cout << n;
                        for (int i = 0; i < n; i++){
                            cout << " " << i + 1;
                        }
                        cout << "\n1 1";
                    }
                    return 0;
                }
            }

        }
    }
    return 0;
}