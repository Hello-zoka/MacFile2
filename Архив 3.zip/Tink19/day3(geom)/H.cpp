#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
#include <cmath>
#include <iomanip>

using namespace std;

const long double EPS = 0.00000000000000005;

int X, Y;
void okrl(long r, long  a, long  b, long  c) {
    long double x0 = -a * c / (long double)(a * a + b * b), y0 = -b * c / (long double)(a * a + b * b);
    if (c * c > r * r * (a * a + b * b))
        cout << 0;
    else if (c * c == r * r * (a * a + b * b)) {
        cout << 1 << '\n';
        cout << setprecision(15) << x0 + X << ' ' << y0 + Y << '\n';
    } else {
        long double d = r * r - c * c /(long double) (a * a + b * b);
        long double mult = sqrt(d / (a * a + b * b));
        long double ax, ay, bx, by;
        ax = x0 + b * mult;
        bx = x0 - b * mult;
        ay = y0 - a * mult;
        by = y0 + a * mult;
        cout << 2 << '\n';
        cout << setprecision(15) << ax + X  << ' ' << ay + Y<< '\n' << bx  + X<< ' ' << by  + Y<< '\n';
    }
}

signed main() {
    long x, y, r, x2, y2, r2;
    cin >> x >> y >> r >> x2 >> y2 >> r2;
    if (x == x2 && y == y2){
        if (r == r2) cout << 3;
        else cout << 0;
        return 0;
    }
    x2 -= x;
    y2 -= y;
    X = x;
    Y =y;

    long A = -2 * x2;
    long B = -2 * y2;
    long C = x2 * x2 + y2 * y2 + r * r - r2 * r2;
    okrl(r, A, B, C);
    return 0;
}