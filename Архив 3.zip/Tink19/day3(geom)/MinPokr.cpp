#include <vector>
#include <algorithm>
#include <iostream>
#include <random>
#include <iomanip>
#include <chrono>

using namespace std;

#define int long long

struct pt {
    double x, y;
};
struct cir {
    pt c;
    double r;
};

double dist(pt a, pt b) {
    return (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y);
}

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

bool PtsOnLine(pt a, pt b, pt c) {
    return a.x * (b.y - c.y) + b.x * (c.y - a.y) + c.x * (a.y - b.y) == 0;
}

int sqr(int a) {
    return a * a;
}

cir build(pt a, pt b, pt c) {
    cir res;
    if (PtsOnLine(a, b, c)) {
        res.r = -1;
        return res;
    }
    res.c.x = -1.0 / 2 *
              ((a.y * (sqr(b.x) + sqr(b.y) - sqr(c.x) - sqr(c.y))) +
               b.y * (sqr(c.x) + sqr(c.y) - sqr(a.x) - sqr(a.y)) +
               c.y * (sqr(a.x) + sqr(a.y) - sqr(b.x) - sqr(b.y))) /
              (a.x * (b.y - c.y) + b.x * (c.y - a.y) + c.x * (a.y - b.y));
    res.c.y = 1.0 / 2 *
              ((a.x * (sqr(b.x) + sqr(b.y) - sqr(c.x) - sqr(c.y))) +
               b.x * (sqr(c.x) + sqr(c.y) - sqr(a.x) - sqr(a.y)) +
               c.x * (sqr(a.x) + sqr(a.y) - sqr(b.x) - sqr(b.y))) /
              (a.x * (b.y - c.y) + b.x * (c.y - a.y) + c.x * (a.y - b.y));
    res.r = dist(a, res.c);
    return res;
}

cir disk2(vector<pt> lst, pt a, pt b) {
    // random_shuffle(lst.begin(), lst.end());
    cir d;
    d.c.x = (b.x + a.x) / 2;
    d.c.y = (b.y + a.y) / 2;
    d.r = dist(d.c, a);
    vector<pt> cur = {a, b};
    for (int i = 0; i < lst.size(); i++) {
        if (dist(d.c, lst[i]) > d.r) {
            d = build(a, b, lst[i]);
        }
        cur.push_back(lst[i]);
    }
    return d;
}

cir disk1(vector<pt> lst, pt a) {
    random_shuffle(lst.begin(), lst.end());
    cir d;
    d.c.x = (lst[0].x + a.x) / 2;
    d.c.y = (lst[0].y + a.y) / 2;
    d.r = dist(d.c, lst[0]);
    vector<pt> cur = {lst[0], a};
    for (int i = 1; i < lst.size(); i++) {
        if (dist(d.c, lst[i]) > d.r) {
            d = disk2(cur, lst[i], a);
        }
        cur.push_back(lst[i]);
    }
    return d;
}


cir disk(vector<pt> lst) {
    random_shuffle(lst.begin(), lst.end());
    cir d;
    d.c.x = (lst[0].x   + lst[1].x) / 2;
    d.c.y = (lst[0].y + lst[1].y) / 2;
    d.r = dist(d.c, lst[0]);
    vector<pt> cur = {lst[0], lst[1]};
    for (int i = 2; i < lst.size(); i++) {
        if (dist(d.c, lst[i]) > d.r) {
            d = disk1(cur, lst[i]);
        }
        cur.push_back(lst[i]);
    }
    return d;
}


signed main() {
    ios_base::sync_with_stdio(0);
    cout.tie(0);
    cin.tie(0);
    int n;
    cin >> n;
    vector<pt> lst;
    for (int i = 0; i < n; i++) {
        pt a;
        cin >> a.x >> a.y;
        lst.push_back(a);
    }
    cir ans = disk(lst);
    cout << setprecision(10) << fixed << ans.c.x << " " << ans.c.y << '\n' << sqrtl(ans.r);
    return 0;
}