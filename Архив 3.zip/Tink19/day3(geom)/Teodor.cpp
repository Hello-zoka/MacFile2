#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;
#define int long long

struct pt {
    int x, y;
};

struct ang {
    int a, b;
};

bool operator<(const ang &p, const ang &q) {
    if (p.b == 0 && q.b == 0)
        return p.a < q.a;
    return p.a * q.b < p.b * q.a;
}

int sq(pt &a, pt &b, pt &c) {
    return a.x * (b.y - c.y) + b.x * (c.y - a.y) + c.x * (a.y - b.y);
}

signed main() {
    int n, m, k, ind = 0;
    cin >> n >> m >> k;
    vector<pt> lst;
    for (int i = 0; i < n; ++i) {
        pt a;
        cin >> a.x >> a.y;
        lst.push_back(a);
        if (lst[i].x < lst[ind].x || (lst[i].x == lst[ind].x && lst[i].y < lst[ind].y))
            ind = i;
    }
    pt zero = lst[ind];
    rotate(lst.begin(), lst.begin() + ind, lst.end());
    lst.erase(lst.begin());
    n--;

    vector<ang> a(n);
    for (int i = 0; i < n; ++i) {
        a[i].a = lst[i].y - zero.y;
        a[i].b = lst[i].x - zero.x;
        if (a[i].a == 0)
            a[i].b = a[i].b < 0 ? -1 : 1;
    }

    for (int i = 0; i < m; i++) {
        pt q;
        cin >> q.x >> q.y;
        int in = 0;
        if (q.x >= zero.x)
            if (q.x == zero.x && q.y == zero.y)
                in = 1;
            else {
                ang cur = {q.y - zero.y, q.x - zero.x};
                if (cur.a == 0)
                    cur.b = cur.b < 0 ? -1 : 1;
                auto it = upper_bound(a.begin(), a.end(), cur);
                if (it == a.end() && cur.a == a[n - 1].a && cur.b == a[n - 1].b)
                    it = a.end() - 1;
                if (it != a.end() && it != a.begin()) {
                    int p1 = (int) (it - a.begin());
                    if (sq(lst[p1], lst[p1 - 1], q) <= 0)
                        in = 1;
                }
            }
        if (in) k--;
    }
    if (k <= 0) cout << "YES";
    else cout << "NO";
}