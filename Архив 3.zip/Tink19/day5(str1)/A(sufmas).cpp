#include <iostream>
#include <vector>
#include <algorithm>

#define ALP 26
using namespace std;

int main() {
    string s;
    cin >> s;
    s += '$';
    int n = s.size();
    vector<int> c(n), new_c(n), suf(n), new_suf(n), starts(max(n, ALP + 1));
    for (int i = 0; i < n; i++) {
        suf[i] = i;
        if (i != n - 1){
            starts[s[i] - 'a' + 2]++;
            c[i] = s[i] - 'a' + 1;
        }
        else{
            c[i] = 0;
            starts[1]++;
        }
    }

    for (int i = 0; i < ALP; ++i)
        starts[i + 1] += starts[i];
    for (int l = 0; l < n; l = max(1, l << 1)) {
        for (int i = 0; i < n; i++) {
            int pos = (suf[i] - l + n) % n;
            new_suf[starts[c[pos]]++] = pos;
        }
        int type = 0;
        for (int i = 0; i < n; i++) {
            if ((i == 0) || (c[new_suf[i - 1]] != c[new_suf[i]]) || (c[(new_suf[i - 1] + l) % n] != c[(new_suf[i] + l) % n]))
                starts[type++] = i;
            new_c[new_suf[i]] = type - 1;
        }
        swap(c, new_c);
        swap(suf, new_suf);
    }
    vector<int> p(n);
    for (int i = 1; i < n; i++){
        cout << suf[i] + 1 << " ";
    }

    return 0;
}