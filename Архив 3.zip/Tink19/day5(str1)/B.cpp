#include <iostream>
#include <vector>
#include <algorithm>

#define ALP 95
using namespace std;
char popa = 32;
int main() {
    string s;
    int an;
    getline(cin, s);
    cin >> an;

    int n = s.size();
    vector<int> c(n), new_c(n), suf(n), new_suf(n), starts(max(n, ALP + 1));
    for (int i = 0; i < n; i++) {
        suf[i] = i;
        starts[s[i] - popa + 1]++;
        c[i] = s[i] - popa;
    }

    for (int i = 0; i < ALP; ++i)
        starts[i + 1] += starts[i];
    for (int l = 0; l < n; l = max(1, l << 1)) {
        for (int i = 0; i < n; i++) {
            int pos = (suf[i] - l + n) % n;
            new_suf[starts[c[pos]]++] = pos;
        }
        int type = 0;
        for (int i = 0; i < n; i++) {
            if ((i == 0) || (c[new_suf[i - 1]] != c[new_suf[i]]) || (c[(new_suf[i - 1] + l) % n] != c[(new_suf[i] + l) % n]))
                starts[type++] = i;
            new_c[new_suf[i]] = type - 1;
        }
        swap(c, new_c);
        swap(suf, new_suf);
    }
    vector<int> k = {suf[0]};
    for (int i = 1;i < n; i++){
        if (c[suf[i]] != c[suf[i - 1]]){
            k.push_back(suf[i]);
        }
    }
    if (an > k.size()){
        cout << "IMPOSSIBLE";
    }
    else{
        for (int i = k[an - 1]; i < n; i++){
            cout << s[i];
        }
        for (int i = 0; i < k[an - 1]; i++){
            cout << s[i];
        }
    }
    return 0;
}