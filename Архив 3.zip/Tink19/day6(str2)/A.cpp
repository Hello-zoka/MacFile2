#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;

#define int long long
#define MOD 1000007773
int n;
vector<string> lst;
const int p = 31;
int ans = -1;

bool find(int x, vector<int> y){
    int l = 0, r = y.size();
    while (l + 1 != r){
        int m = (l + r) / 2;
        //cerr << m << " " << y.size();
        if (y[m] > x) r = m;
        else l = m;
    }

    return y[l] == x;
}
bool check(int x) {
    vector<vector<int>> hash;
    if (x  == 0) return true;

    for (int i = 0; i < n; i++) {
        hash.push_back({});
        string s = lst[i];

        vector<int> p_pow(10007);
        p_pow[0] = 1;
        for (int j = 1; j < p_pow.size(); j++)
            p_pow[j] = (p_pow[j - 1] * p) % MOD;

        vector<int> h(s.size());
        for (int j = 0; j < s.size(); j++) {
            if (j) h[j] = h[j - 1];
            else h[j] = 0;
            h[j] *= p;
            h[j] %= MOD;
            h[j] += s[j] - 'a' + 1;
            h[j] %= MOD;

        }
        for (int j = 0; j <= (int)s.size() - x; j++){
            int cur = h[j + x - 1];
            if (j) cur -= (h[j - 1] * p_pow[x]) % MOD;
            cur = (cur + MOD) % MOD;
            hash[i].push_back(cur);
        }

    }

    for (int i = 0; i < n; i++) {
        sort(hash[i].begin(), hash[i].end());
    }
    for (int i:hash[0]){
        int b = 1;
        for (int j = 1; j < n; j++){
            if (hash[j].size() == 0){
                b = 0;
                break;
            }
            if (!find(i, hash[j])) {
                b= 0;
                break;
            }
        }
        if (b) {
            ans = i;
            return true;
        }
    }
    return false;
}


int bin() {
    int l = 0, r = 10007;
    while (l + 1 != r) {

        int m = (l + r) / 2;
        if (check(m)) l = m;
        else r = m;
    }

    return l;
}

signed main() {
    cin >> n;
    for (int i = 0; i < n; i++) {
        string s;
        cin >> s;
        lst.push_back(s);
    }
    int l = bin();
    vector<int> hash;

    string s = lst[0];

    vector<int> p_pow(10007);
    p_pow[0] = 1;
    for (int j = 1; j < p_pow.size(); j++)
        p_pow[j] = (p_pow[j - 1] * p) % MOD;

    vector<int> h(s.size());
    for (int j = 0; j < s.size(); j++) {
        if (j) h[j] = h[j - 1];
        else h[j] = 0;

        h[j] *= p;
        h[j] %= MOD;
        h[j] += s[j] - 'a' + 1;
        h[j] %= MOD;
    }

    for (int j = 0; j <= (int)s.size() - l; j++){
        int cur = h[j + l - 1];
        if (j) cur -= (h[j - 1] * p_pow[l]) % MOD;
        cur =  (cur + MOD) % MOD;
        if (cur == ans){
            for (int ii = j; ii - j < l; ii++){
                cout << lst[0][ii];
            }
            return 0;
        }
    }
    return 0;
}