#include <iostream>
#include <algorithm>
#include <vector>
#include <math.h>

using namespace  std;

#define int long long
#define INF 1e9
int ans =INF;
int xx;
vector<int> lg(50);
void check(int x){
    //cerr << x;
    int p = x;
    if (x == 1){
       return;
    }
    for (int i = 2; i < 50; i++){
        int a = pow(p, (double)1/(i - 1));
        for (int j = max(xx / x + 1, a - 20); j < a + 20; j++){
            //cerr << j << " " << i << "\n";
            int cur = x * j - x + 1;
            int bl = 1;
            int cnt = 0;
            while(cur % j == 0){
                cur /= j;
                cnt++;
            }
            if (cur == 1){
                ans = min(ans, j);
            }
        }
    }
}
signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> xx;
    if (xx == 1){
        cout << 2;
        return 0;
    }
    if (xx == 2){
        cout << 3;
        return 0;
    }
    ans = xx - 1;
    for (int k = 1; k * k <= xx; k++){
        if (xx % k == 0){
            check(k);
            check(xx / k);
        }
    }
    cout << ans;

    return 0;
}
