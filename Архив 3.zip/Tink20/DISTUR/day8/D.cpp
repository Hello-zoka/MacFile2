#include <iostream>
#include <algorithm>
#include <vector>
#include <math.h>

using namespace  std;
#define int long long
const int mod = 1000000007;

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    vector<int> lst;

    for (int i = 0; i < n; i++){
        int x;
        cin >> x;
        lst.push_back(x);
    }
    vector<int> f = {1, 2};
    for (int i = 0; i < 25; i++){
        f.push_back(f[f.size() - 1] + f[f.size() - 2]);
    }
    vector<int> cnt(1000000, 0);
    for (int i =0; i < 1 << 20; i++){
        int cur = 0;
        for (int j =0; j < 20; j++){
            if ((i >> j) & 1){
                cur += f[j];
            }
        }
        //cerr << cur << '\n';
        cnt[cur]++;
        cnt[cur] %= mod;
    }
    int sm =0;
    for (int i = 0; i < n; i++){
        sm += f[lst[i] - 1];
        cout << cnt[sm] << '\n';
    }
    return 0;
}