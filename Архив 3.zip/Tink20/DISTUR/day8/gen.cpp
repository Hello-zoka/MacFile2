#include <iostream>
#include <algorithm>
#include <vector>
#include <math.h>
#include <random>
#include <chrono>
using namespace  std;

#define int long long

mt19937 rnd(chrono::steady_clock::now().time_since_epoch().count());
signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cout << rnd() % 1000 + 1;
    return 0;
}
