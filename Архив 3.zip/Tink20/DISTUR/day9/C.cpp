#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

//#define int long long
const int INF = 1e9;
signed main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    string a, b;
    cin >> a >> b;
    vector<int> cnt(26, 0);
    for (int i =0; i < b.size(); i++){
        cnt[b[i] - 'a']++;
    }
    vector<vector<int>> pos(26);
    string s = "";
    for (int i = 0; i < a.size(); i++){
        if (cnt[a[i] - 'a'] != 0){
            pos[a[i] - 'a'].push_back(s.size());
            s += a[i];
        }
    }
    vector<int> cur(26, 0), ded(26);
    for (int i =0; i < 26; i++){
        if (pos[i].size() < cnt[i]){
            cout << "impossible";
            return 0;
        }
        if (cnt[i] != 0)
            ded[i] = pos[i][pos[i].size() - cnt[i]];
    }
    string ans = "";
    int ind = 0;
    while (ind < s.size()){
        int curd = INF;
        for (int i =0; i < 26; i++){
            if (cnt[i] != 0){
                curd = min(curd, pos[i][pos[i].size() - cnt[i]]);
            }
        }

        if (curd == ind) {
            int mn = s[ind] - 'a';
            char addd = 'a' + mn;
            ans += addd;
            if (ans.size() == b.size()) break;
            int nxt = pos[mn][cur[mn]];
            while(ind != nxt + 1){
                if (ind == nxt){
                    cnt[s[ind] - 'a']--;
                    //if (ded[s[ind] - 'a'] == pos[s[ind] - 'a'].size()) cnt[s[ind] - 'a'] = 0;
                }
                cur[s[ind] - 'a']++;
                ind++;
            }
            continue;
        }
        int mn = 27;
        for (int i = 0; i < 26; i++){
            if (cnt[i] != 0 && cur[i] < pos[i].size()){
                if (pos[i][cur[i]] <= curd){
                    mn = i;
                    break;
                }
            }
        }
        //cerr << mn << " " << curd << "\n";
        char addd = 'a' + mn;
        ans += addd;
        if (ans.size() == b.size()) break;
        int nxt = pos[mn][cur[mn]];
        while(ind != nxt + 1){
            if (ind == nxt){
                cnt[s[ind] - 'a']--;
                //if (ded[s[ind] - 'a'] == pos[s[ind] - 'a'].size()) cnt[s[ind] - 'a'] = 0;
            }
            cur[s[ind] - 'a']++;
            ind++;
        }

    }
    cout << ans;
}