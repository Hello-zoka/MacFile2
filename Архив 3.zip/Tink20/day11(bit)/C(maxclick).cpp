#include <vector>
#include <iostream>
#include <algorithm>
#include <iomanip>

using namespace std;

#define ll long long
const int maxn = 50, C = 21;
int n, k;
vector<ll> adj(maxn);
vector<int> dp(1 << C);

int maxc() {
    for (int i = 1; i < (1 << max((int) 0, n - C)); i++) {
        int x = i;
        for (int j = 0; j < C; j++)
            if ((i >> j) & 1)
                x &= adj[j + C] >> C;
        if (x == i)
            dp[i] = __builtin_popcount(i);
    }
    for (int i = 1; i < (1 << max((int) 0, n - C)); i++)
        for (int j = 0; j < C; j++)
            if ((i >> j) & 1)
                dp[i] = max(dp[i], dp[i ^ (1 << j)]);
    int ans = 0;
    for (int i = 0; i < (1 << min(C, n)); i++) {
        int x = i, y = (1 << max((int) 0, n - C)) - 1;
        for (int j = 0; j < min(C, n); j++)
            if ((i >> j) & 1)
                x &= adj[j] & ((1 << C) - 1), y &= adj[j] >> C;
        if (x != i) continue;
        ans = max(ans, __builtin_popcount(i) + dp[y]);
    }
    return ans;
}

signed main() {
    cin >> n >> k;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            int x;
            cin >> x;
            adj[i] |= (ll) (x || i == j) << j;
        }
    }
    int ans = maxc();
    long double res = (long double) k / ans;
    cout << fixed << setprecision(15) << res * res * ans * (ans - 1) / 2;
}
