#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

#define int long long

signed main() {
    vector<int> ans = {2, 20, 980, 232848, 267227532, 1478619421136, 39405996318420160};
    int n;
    cin >> n;
    cout << ans[n - 1];
}
