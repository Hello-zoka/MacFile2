#include <iostream>
#include <vector>
#include <cstring>
#include <algorithm>

using namespace std;
//#define int long long
const int k = 26, maxn = 50000;

struct bor {
    int nxt[k], suff_link, par, suff_flink;
    vector<int> pat_num;
    bool flag;
    char symb;
};

vector<bor> b;
vector<string> pattern;

bor build(int p, char c) {
    bor v;
    memset(v.nxt, 255, sizeof(v.nxt));
    // memset(v.auto_move, 255, sizeof(v.auto_move));
    v.flag = false;
    v.suff_link = -1;
    v.par = p;
    v.symb = c;
    v.suff_flink = -1;
    return v;
}

void init() {
    b.push_back(build(0, '$'));
}

void add(const string &s) {
    int num = 0;
    for (int i = 0; i < s.length(); i++) {
        char ch = s[i] - 'a';
        if (b[num].nxt[ch] == -1) {
            b.push_back(build(num, ch));
            b[num].nxt[ch] = b.size() - 1;
        }
        num = b[num].nxt[ch];
    }
    b[num].flag = true;
    pattern.push_back(s);
    b[num].pat_num.push_back(pattern.size() - 1);
}

int get_auto_move(int v, char ch);

int get_suff_link(int v) {
    if (b[v].suff_link == -1) {
        if (v == 0 || b[v].par == 0) {
            b[v].suff_link = 0;
        } else {
            b[v].suff_link = get_auto_move(get_suff_link(b[v].par), b[v].symb);
        }
    }
    return b[v].suff_link;
}

int get_auto_move(int v, char ch) {
    if (b[v].nxt[ch] == -1) {
        if (v == 0) {
            b[v].nxt[ch] = 0;
        } else {
            b[v].nxt[ch] = get_auto_move(get_suff_link(v), ch);
        }
    }
    return b[v].nxt[ch];
}

int get_suff_flink(int v) {
    if (b[v].suff_flink == -1) {
        int u = get_suff_link(v);
        if (u == 0) {
            b[v].suff_flink = 0;
        } else {
            b[v].suff_flink = (b[u].flag) ? u : get_suff_flink(u);
        }
    }
    return b[v].suff_flink;
}

vector<vector<int>> ans;

void check(int v, int i) {
    for (int u = v; u != 0; u = get_suff_flink(u)) {
        if (b[u].flag) {
            for (int x : b[u].pat_num)
                ans[x].push_back(i - pattern[x].length() + 1);
        }
    }
}

void find_all_pos(const string &s) {
    int u = 0;
    for (int i = 0; i < s.length(); i++) {
        u = get_auto_move(u, s[i] - 'a');
        check(u, i + 1);
    }
}

signed main() {
    freopen("inputik.txt", "r", stdin);
    freopen("outputik.txt", "w", stdout);

    string text;
    cin >> text;
    int n;
    cin >> n;
    init();
    ans.assign(n, {});
    for (int i = 0; i < n; i++) {
        string s;
        cin >> s;
        add(s);
    }
    find_all_pos(text);
    for (int i = 0; i < n; i++) {
        cout << ans[i].size() << " ";
        for (int j : ans[i]) {
            cout << j << " ";
        }
        cout << '\n';
    }
    return 0;
}
