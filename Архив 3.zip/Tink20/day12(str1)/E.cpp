#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;

#define int long long
#define MOD 1000000007

const int p = 239;
vector<int> h;
vector<int> p_pow(400007);


int get(int l, int r) {
    // cerr << l << " " << r << " " << h[l] << " " << h[r] << '\n';
    if (l == 0) return h[r];
    int ll = (h[l - 1] * p_pow[r - l + 1]) % MOD;
    return (h[r] - ll + MOD) % MOD;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    string s;
    cin >> s;
    int n = s.size();
    p_pow[0] = 1;
    for (int j = 1; j < p_pow.size(); j++)
        p_pow[j] = (p_pow[j - 1] * p) % MOD;

    h.assign(n, 0);
    int cur = 0;
    for (int j = 0; j < s.size(); j++) {
        cur *= p;
        cur %= MOD;
        cur += s[j] - 'a' + 1;
        cur %= MOD;
        h[j] = cur;
    }
    vector<int> ans(n, 1);
    for (int k = 1; k < n; k++) {
        for (int i = k; i + k <= n; i += k) {
            if (get(i - k, i - 1) != get(i, i + k - 1)) {
                break;
            }
            ans[i + k - 1] = max(ans[i + k - 1], i / k + 1);
        }
    }
    for (int i : ans) cout << i << " ";
    return 0;
}
