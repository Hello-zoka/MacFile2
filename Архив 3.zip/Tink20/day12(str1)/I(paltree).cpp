#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;

#define int long long
#define Alp 27
#define MX 500007

vector<int> s, cnt;

int ln[MX], lin[MX], to[MX][Alp];

int cur = 0, sz = 2, l = 0;

int get(int v) {
    while (s[cur - ln[v] - 2] != s[cur - 1]) {
        v = lin[v];
    }
    return v;
}

void add(char c) {
    s[cur++] = c;
    l = get(l);
    if (!to[l][c]) {
        ln[sz] = ln[l] + 2;
        lin[sz] = to[get(lin[l])][c];
        to[l][c] = sz++;
    }
    l = to[l][c];
    cnt[l]++;
}

signed main() {
    string ss;
    cin >> ss;
    s.assign(ss.size() + 2, 0);
    cnt.assign(MX, 0);
    s[cur++] = -1;
    lin[0] = 1;
    ln[1] = -1;
    for (int i = 0; i < ss.size(); i++)
        add(ss[i] - 'a');
    vector<int> occ;
    occ.assign(sz + 3, 0);
    for (int v = sz; v >= 1; v--)
        occ[v] = cnt[v];
    for (int v = sz; v >= 1; v--)
        occ[lin[v]] += occ[v];
    int mx = 1;
    for (int i = 2; i < sz; i++)
        mx = max(ln[i] * occ[i], mx);
    cout << mx;
    return 0;
}
