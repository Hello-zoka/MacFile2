#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;

#define int long long
vector<vector<int>> g;
vector<int> mt;

int dis(int x1, int y1, int x2, int y2) {
    return (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2);
}

vector<int> used;
int tim = 0;

bool try_kun(int v) {
    if (used[v] == tim) return false;
    used[v] = tim;
    for (int to : g[v]) {
        if (mt[to] == -1) {
            mt[to] = v;
            return true;
        }
    }
    for (int to : g[v]) {
        if (try_kun(mt[to])) {
            mt[to] = v;
            return true;
        }
    }
    return false;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, v;
    cin >> n >> v;
    vector<pair<int, pair<int, int>>> lst;
    for (int i = 0; i < n; i++) {
        string s;
        cin >> s;
        int x, y;
        cin >> x >> y;
        int t = (s[0] - '0') * 60 * 10 + (s[1] - '0') * 60 + (s[3] - '0') * 10 + s[4] - '0';
        lst.push_back({t, {x, y}});
    }
    mt.assign(n, -1);
    g.assign(n, {});
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (i != j) {
                int d = dis(lst[i].second.first, lst[i].second.second, lst[j].second.first, lst[j].second.second);
                if (lst[j].first >= lst[i].first &&
                    d * 3600 <= (v * (lst[j].first - lst[i].first) * (v * (lst[j].first - lst[i].first)))) {
                    //
                    // cerr << lst[i].first << " " << lst[j].first <<  '\n';
                    g[i].push_back(j);
                }
            }
        }
    }
    used.assign(n, -1);
    for (int i = 0; i < n; i++) {
        tim++;
        try_kun(i);
    }
    int cnt = 0;
    for (int i = 0; i < n; i++) {
        if (mt[i] != -1) cnt++;
    }
    cout << n - cnt;
}
