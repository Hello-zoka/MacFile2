#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;

#define int long long
vector<vector<int>> g;
vector<int> mt;

vector<int> used;
int tim = 0;
vector<int> men, gir;

int n, m;
int a = 0, b;


bool try_kun(int v) {
    if (used[v] == tim) return false;
    used[v] = tim;
    for (int to : g[v]) {
        if (mt[to] == -1) {
            mt[to] = v;
            return true;
        }
    }
    for (int to : g[v]) {
        if (try_kun(mt[to])) {
            mt[to] = v;
            return true;
        }
    }
    return false;
}

void dfs(int st) {
    if (men[st] == 1) return;
    men[st] = 1;
    a++;
    for (int to : g[st]) {
        if (gir[to]) {
            gir[to] = 0;
            b--;
            dfs(mt[to]);
        }
    }
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int t;
    cin >> t;
    for (int q = 0; q < t; q++) {
        cin >> n >> m;
        mt.assign(m, -1);
        g.assign(n, {});
        tim = 0;
        a = 0;
        for (int i = 0; i < n; i++) {
            int x;
            cin >> x;
            vector<int> cur(m, 0);
            while (x != 0) {
                cur[x - 1] = 1;
                cin >> x;
            }
            for (int j = 0; j < m; j++) {
                if (cur[j] == 0) {
                    g[i].push_back(j);
                }
            }
        }
        used.assign(n, -1);
        for (int i = 0; i < n; i++) {
            tim++;
            try_kun(i);
        }
        men.assign(n, 0);
        gir.assign(m, 1);
        vector<pair<int, int>> edg;
        b = m;
        vector<int> st(n, 1);
        for (int i = 0; i < m; i++) {
            if (mt[i] != -1) {
                //cerr << mt[i] << " ";
                st[mt[i]] = 0;
            }
        }
        for (int i = 0; i < st.size(); i++) {
            if (st[i] == 1 && !men[i])
                dfs(i);
        }

        cout << a + b << '\n';
        cout << a << " " << b << '\n';
        for (int i = 0; i < n; i++) {
            if (men[i]) cout << i + 1 << " ";
        }
        cout << '\n';
        for (int i = 0; i < m; i++) {
            if (gir[i]) cout << i + 1 << " ";
        }
        cout << '\n';
    }
}
