#include <vector>
#include <algorithm>
#include <iostream>
#include <stack>

using namespace std;

#define int long long

vector<vector<int>> lst;
vector<int> tin, up, tout;
vector<int> col;
int tim = 0;
stack<int> st;
vector<vector<int>> g;
vector<int> used;
int cnt = -1;

void paint(int v) {
    cnt++;
    int last = -1;
    while (last != v && !st.empty()) {
        col[st.top()] = cnt;
        last = st.top();
        st.pop();
    }
}

void dfs(int v, int p = -1) {
    used[v] = 1;
    tim++;
    st.push(v);
    tin[v] = tim;
    up[v] = tim;
    for (int to : lst[v]) {
        if (to == p) continue;
        if (used[to]) {
            up[v] = min(up[v], tin[to]);
        } else if (!used[to]) {
            dfs(to, v);
            up[v] = min(up[v], up[to]);
            if (up[to] > tin[v]) {
                paint(to);
            }
        }
    }
}

const int lg = 18;
int upp[100007][lg];
vector<int> d;

void dfs2(int v) {
    used[v] = 1;
    for (int l = 1; l < lg; l++) {
        upp[v][l] = upp[upp[v][l - 1]][l - 1];
    }
    tin[v] = tim++;
    for (int to : g[v]) {
        if (used[to]) continue;
        upp[to][0] = v;
        d[to] = d[v] + 1;
        dfs2(to);
    }
    tout[v] = tim;
}

bool anc(int u, int v) {
    return tin[u] <= tin[v] && tout[u] > tin[v];
}

int lca(int u, int v) {
    if (anc(u, v)) return u;
    if (anc(v, u)) return v;
    for (int l = lg - 1; l >= 0; l--) {
        if (!anc(upp[v][l], u))
            v = upp[v][l];
    }
    return upp[v][0];
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, m;
    cin >> n >> m;
    col.assign(n, -1);
    int f;
    tin.assign(n, 0);
    up.assign(n, 0);
    cin >> f;
    f--;
    lst.assign(n, {});
    vector<pair<int, int>> edg;
    for (int i = 0; i < m; i++) {
        int a, b;
        cin >> a >> b;
        a--;
        b--;
        lst[a].push_back(b);
        lst[b].push_back(a);
        edg.push_back({a, b});
    }
    used.assign(n, 0);
    dfs(0);
    paint(0);
    cnt++;
    g.assign(cnt, {});
    used.assign(cnt, 0);
    d.assign(cnt, 0);
    // cerr << '\n';
    for (int i = 0; i < edg.size(); i++) {
        // cerr << col[edg[i].first] << " " << col[edg[i].second] << '\n';
        g[col[edg[i].first]].push_back(col[edg[i].second]);
        g[col[edg[i].second]].push_back(col[edg[i].first]);
    }
    tin.assign(cnt, 0);
    tout.assign(cnt, 0);
    tim = 1;
    for (int i = 0; i < lg; i++) {
        upp[col[f]][i] = col[f];
    }
    dfs2(col[f]);
//    for (int i = 0; i < cnt; i++){
//        cerr << col[i] << " ";
//    }
//    cerr << '\n';
//    for (int i = 0; i < cnt; i++){
//        cerr << d[i] << " ";
//    }
//    cerr << '\n';
    int k;
    cin >> k;
    for (int i = 0; i < k; i++) {
        int a, b;
        cin >> a >> b;
        a = col[a - 1];
        b = col[b - 1];
//        cerr << '\n' << a << " " << b << " " << lca(a, b) << '\n';
        cout << d[lca(a, b)] << "\n";
    }
}
