#include <vector>
#include <algorithm>
#include <iostream>
#include <set>

using namespace std;

#define int long long

signed main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

}