#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

#define int long long

int n;
vector<vector<int>> g, gr;
vector<int> used;
vector<int> ord, comp;
int cnt = 0;

void dfs1(int v) {
    used[v] = 1;
    for (int to : g[v]) {
        if (!used[to]) {
            dfs1(to);
        }
    }
    ord.push_back(v);
}

void dfs2(int v) {
    comp[v] = cnt;
    for (int to : gr[v]) {
        if (comp[to] == -1) {
            dfs2(to);
        }
    }
}

void adde(int x, int y) {
    g[x].push_back(y);
    gr[y].push_back(x);
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    while (cin >> n) {
        int m;
        cin >> m;
        g.assign(2 * n, {});
        gr.assign(2 * n, {});
        for (int i = 0; i < m; i++) {
            int x, y, a, b;
            cin >> x >> a >> y >> b;
            if (a == 1 && b == 1) {
                adde(2 * x + 1, 2 * y);
                adde(2 * y + 1, 2 * x);
            } else if (a == 1 && b == 0) {
                adde(2 * x + 1, 2 * y + 1);
                adde(2 * y, 2 * x);
            } else if (a == 0 && b == 1) {
                adde(2 * x, 2 * y);
                adde(2 * y + 1, 2 * x + 1);
            } else {
                adde(2 * x, 2 * y + 1);
                adde(2 * y, 2 * x + 1);
            }
        }
        comp.assign(2 * n, -1);
        used.assign(2 * n, 0);
        ord.clear();
        for (int i = 0; i < 2 * n; i++) {
            if (!used[i]) {
                dfs1(i);
            }
        }
        cnt = 0;
        for (int i = 0; i < 2 * n; i++) {
            int v = ord[2 * n - i - 1];
            if (comp[v] == -1) {
                dfs2(v);
                cnt++;
            }
        }
        int bl = 0;
        for (int i = 0; i < 2 * n; i += 2) {
            if (comp[i] == comp[i + 1]) {
                bl = 1;
                break;
            }
        }
        if (bl) {
            cerr << "ERROR NO SOLUTION";
        }
        for (int i = 0; i < 2 * n; i += 2) {
            if (comp[i] > comp[i + 1])
                cout << 1;
            else
                cout << 0;
        }
        cout << '\n';
    }
}
