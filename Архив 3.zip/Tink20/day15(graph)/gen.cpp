#include <vector>
#include <algorithm>
#include <iostream>
#include <stack>
#include <random>
#include <chrono>

using namespace std;

#define int long long

mt19937 rng(chrono::steady_clock().now().time_since_epoch().count());

vector<vector<int>> lst;
vector<int> used;

void dfs(int st){
    used[st] = 1;
    for (int to : lst[st]){
        if (!used[to]){
            dfs(to);
        }
    }
}
signed main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, m;
    n = rng() % 100 + 2;
    int st = 1;
    used.assign(n, 0);
    vector<vector<int>> mat(n, vector<int>(n, 0));
    m = 0;
    vector<pair<int, int>> edg;
    lst.assign(n, {});
    while (1){
        int a = rng() % n, b = rng() % n;
        if (mat[a][b]) continue;
        mat[a][b] = 1;
        mat[b][a] = 1;
        m++;
        edg.push_back({a, b});
        lst[a].push_back(b);
        lst[b].push_back(a);
        used.assign(n, 0);
        dfs(0);
        int bl = 1;
        for (int i = 0; i < n; i++){
            if (!used[i]){
                bl = 0;
                break;
            }
        }
        if (bl) break;
    }
    cout << n << " " << m << '\n';
    cout << st << '\n';
    for (int i =0; i < m; i++){
        cout << edg[i].first + 1<< " " << edg[i].second + 1 << '\n';
    }
    int q = 1;
    cout << q << '\n';
    for (int i =0; i < q; i++){
        cout << rng() % n  + 1 << " " << rng() % n + 1 << '\n';
    }
}
