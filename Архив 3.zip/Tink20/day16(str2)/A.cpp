#include <iostream>
#include <vector>
#include <algorithm>
#include <map>

using namespace std;

#define int long long

const int maxn = 400007;

struct node {
    int ln, link;
    map<char, int> go;
};

node suf[maxn];
int sz = 0, last = 0;
int ans = 0;

void add(char s) {
    int nlast = sz++;
    suf[nlast].ln = suf[last].ln + 1;
    ans += suf[nlast].ln - suf[suf[nlast].link].ln;
    int p = last;
    while (p != -1 && suf[p].go.count(s) == 0) {
        suf[p].go[s] = nlast;
        p = suf[p].link;
    }
    if (p == -1) {
        ans -= suf[nlast].ln - suf[suf[nlast].link].ln;
        suf[nlast].link = 0;
        ans += suf[nlast].ln - suf[suf[nlast].link].ln;
    } else {
        int q = suf[p].go[s];
        if (suf[p].ln + 1 == suf[q].ln) {
            ans -= suf[nlast].ln - suf[suf[nlast].link].ln;
            suf[nlast].link = q;
            ans += suf[nlast].ln - suf[suf[nlast].link].ln;
        } else {
            int clone = sz++;
            suf[clone] = suf[q];
            suf[clone].ln = suf[p].ln + 1;
            ans += suf[clone].ln - suf[suf[clone].link].ln;

            while (p != -1 && suf[p].go[s] == q) {
                suf[p].go[s] = clone;
                p = suf[p].link;
            }
            ans -= suf[nlast].ln - suf[suf[nlast].link].ln;
            ans -= suf[q].ln - suf[suf[q].link].ln;
            suf[q].link = suf[nlast].link = clone;
            ans += suf[nlast].ln - suf[suf[nlast].link].ln;
            ans += suf[q].ln - suf[suf[q].link].ln;
        }
    }
    last = nlast;
}


signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
//    freopen("keepcounted.in", "r", stdin);
//    freopen("keepcounted.out", "w", stdout);
    suf[0].ln = 0;
    suf[0].link = -1;
    sz++;
    string s;
    cin >> s;
    for (int i = 0; i < s.size(); i++) {
        add(s[i]);
        cout << ans << '\n';
    }
    return 0;
}
