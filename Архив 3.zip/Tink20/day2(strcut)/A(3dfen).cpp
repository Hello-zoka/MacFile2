#include <iostream>
#include <vector>
#include <stdio.h>
#include <algorithm>

using namespace std;
#define int long long
vector<vector<vector<int>>> t;
int n;

int sum(int x, int y, int z) {
    if (x < 0 || y < 0 || z < 0) return 0;
    int ans = 0;
    for (int i = x; i >= 0; i = (i & (i + 1)) - 1)
        for (int j = y; j >= 0; j = (j & (j + 1)) - 1)
            for (int k = z; k >= 0; k = (k & (k + 1)) - 1)
                ans += t[i][j][k];

    return ans;
}

void inc(int x, int y, int z, int val) {
    for (int i = x; i < n; i = (i | (i + 1)))
        for (int j = y; j < n; j = (j | (j + 1)))
            for (int k = z; k < n; k = (k | (k + 1)))
                t[i][j][k] += val;
}

signed main() {
    cin >> n;
    t.assign(n + 7, {});
    for (int i = 0; i < n + 7; i++) {
        for (int j = 0; j < n + 7; j++) {
            t[i].push_back({});
            for (int k = 0; k < n + 7; k++) {
                t[i][j].push_back(0);
            }
        }
    }
    int a;
    cin >> a;
    while (a != 3) {
        if (a == 1) {
            int x, y, z, c;
            cin >> x >> y >> z >> c;
            inc(x, y, z, c);
        } else {
            int x1, y1, z1, x2, y2, z2;
            cin >> x1 >> y1 >> z1 >> x2 >> y2 >> z2;
            // cerr << sum(x2, y2, z2) << '\n';
            x1--;
            y1--;
            z1--;
            cout << sum(x2, y2, z2) - sum(x2, y2, z1) - sum(x2, y1, z2) - sum(x1, y2, z2) + sum(x2, y1, z1) +
                    sum(x1, y1, z2) + sum(x1, y2, z1) - sum(x1, y1, z1) << '\n';
        }
        cin >> a;
    }
    return 0;
}