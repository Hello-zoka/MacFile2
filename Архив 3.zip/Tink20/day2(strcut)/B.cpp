#include <iostream>
#include <vector>
#include <stdio.h>
#include <algorithm>
#include  <set>
#include <random>
#include <chrono>

using namespace std;
// #define int long long
#define maxn 50005
mt19937 rnd(chrono::steady_clock().now().time_since_epoch().count());

struct Node {
    int key, pr, sz = 1;
    Node *l = NULL, *r = NULL;

    Node(int kkey) { key = kkey, pr = rnd(); }
};

int size(Node *v) { return v ? v->sz : 0; }

void upd(Node *v) { v->sz = 1 + size(v->l) + size(v->r); }

Node *mt[4 * maxn];
vector<int> lst;

pair<Node *, Node *> split(Node *p, int k) {
    if (p == NULL) return {NULL, NULL};
    if (p->key <= k) {
        pair<Node *, Node *> q = split(p->r, k);
        p->r = q.first;
        upd(p);
        return {p, q.second};
    } else {
        pair<Node *, Node *> q = split(p->l, k);
        p->l = q.second;
        upd(p);
        return {q.first, p};
    }
}

Node *merge(Node *l, Node *r) {
    if (!l) return r;
    if (!r) return l;
    if (l->pr > r->pr) {
        l->r = merge(l->r, r);
        upd(l);
        return l;
    } else {
        r->l = merge(l, r->l);
        upd(r);
        return r;
    }
}

Node *erase(Node *root, int key) {
    // assert(root != nullptr);
    if (key < root->key)
        root->l = erase(root->l, key);
    else if (key > root->key)
        root->r = erase(root->r, key);
    else
        root = merge(root->l, root->r);
    if (root != NULL) upd(root);
    return root;
}

Node *insert(Node *p, int x) {
    pair<Node *, Node *> q = split(p, x);
    Node *t = new Node(x);
    Node *tt = merge(t, q.second);
    upd(tt);
    p = merge(q.first, tt);
    upd(p);
    return p;
}

Node *sl(Node *a, Node *b) {
    if (b != NULL) {
        a = insert(a, b->key);
        a = sl(a, b->l);
        a = sl(a, b->r);
    }
    return a;
}

void print(Node *t) {
    // push(t);
    if (t != NULL) {
        print(t->l);
        cerr << t->key << " ";
        print(t->r);
    }
}

void build(int v, int tl, int tr) {
    if (tl + 1 == tr) {
        mt[v] = new Node(lst[tl]);
        return;
    }
    int tm = (tl + tr) / 2;
    build(v * 2 + 1, tl, tm);
    build(v * 2 + 2, tm, tr);
    Node *a = NULL, *b = NULL;
    a = sl(a, mt[v * 2 + 1]);
    b = sl(b, mt[v * 2 + 2]);
    mt[v] = sl(a, b);
}

int getmn(int v, int tl, int tr, int l, int r, int x) {
    if (tl >= r || tr <= l) {
        return 0;
    }
    if (l <= tl && tr <= r) {
        // cerr << "start   ";
        // print(mt[v]);
        pair<Node *, Node *> per = split(mt[v], x);
        // cerr << "firstt   ";
        // print(per.first);
        // cerr << "    sec";
        // print(per.second);
        // cerr << "     ind" << tl << " " << tr << "\n";
        int res = size(per.first);
        mt[v] = merge(per.first, per.second);
        return res;
    }
    int tm = (tl + tr) / 2;
    return getmn(v * 2 + 1, tl, tm, l, r, x) + getmn(v * 2 + 2, tm, tr, l, r, x);
}

int getbol(int v, int tl, int tr, int l, int r, int x) {
    if (tl >= r || tr <= l) {
        return 0;
    }
    if (l <= tl && tr <= r) {
        // cerr << "start   ";
        // print(mt[v]);
        pair<Node *, Node *> per = split(mt[v], x);
        // cerr << "firstt   ";
        // print(per.first);
        // cerr << "    sec";
        // print(per.second);
        // cerr << "     ind" << tl << " " << tr << "\n";
        int res = size(per.second);
        mt[v] = merge(per.first, per.second);
        return res;
    }
    int tm = (tl + tr) / 2;
    return getbol(v * 2 + 1, tl, tm, l, r, x) + getbol(v * 2 + 2, tm, tr, l, r, x);
}

void upd(int v, int tl, int tr, int pos, int val) {
    mt[v] = erase(mt[v], lst[pos]);
    mt[v] = insert(mt[v], val);
    if (tl + 1 == tr) {
        lst[pos] = val;
        return;
    }
    int tm = (tl + tr) / 2;
    if (pos < tm)
        upd(v * 2 + 1, tl, tm, pos, val);
    else
        upd(v * 2 + 2, tm, tr, pos, val);
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, m;
    cin >> n;
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        lst.push_back(x);
    }
    build(0, 0, n);
    cin >> m;

    for (int i = 0; i < m; i++) {
        char q;
        cin >> q;
        if (q == 'Q') {
            int x1, x2, y1, y2;
            cin >> x1 >> y1 >> x2 >> y2;
            int a = y1 + (y2 - y1) / 2;
            int b = y1 + (y2 - y1) / 2 - 1 + ((y2 - y1) % 2 != 0);
            // cerr << "derevo\n\n\n";
            // print(mt[0]);
            // cerr << "konec\n";
            int x = getbol(0, 0, n, x1 - 1, x2, a), y = getmn(0, 0, n, x1 - 1, x2, b);
            // cerr << getmn(0, 0, n, 0, 2, 1) << '\n';
            // cerr << a << " " << b <<  " " << x << " " << y << '\n';

            if (x == y)
                cout << 0 << '\n';
            else if (x > y)
                cout << 2 << '\n';
            else
                cout << 1 << '\n';
        } else {
            int pos, val;
            cin >> pos >> val;
            upd(0, 0, n, pos - 1, val);
            // cerr << l << " "  << r << '\n';
            // for (int q:lst) cerr << q << " ";
        }
    }
    return 0;
}