#include <iostream>
#include <vector>
#include <cstdio>
#include <algorithm>
#include <queue>
#include <map>

using namespace std;
#define int long long
#define maxn 200700
#define INF 2000007007
struct seg {
    int l, r, w, d, p;
    seg() = default;
} S[maxn];

struct tree {
    vector<pair<int, seg *>> ws;
    int n = 0;
    vector<int> T;
    tree() = default;
    void add(int w, seg *s) {
        ws.push_back({w, s});
    }

    void clear() {
        T.assign(2 * n, INF);
    }

    void build() {
        sort(ws.begin(), ws.end());
        for (int i = 0; i < (int) ws.size(); i++) {
            ws[i].second->p = i;
        }
        n = 1;
        while (n < ws.size()) {
            n *= 2;
        }
        clear();
    }

    int get(int l, int r) {
        l += n;
        r += n;
        int ans = INF;
        while (l <= r) {
            if ((l & 1) && ans >= T[l])
                ans = T[l];
            if (!(r & 1) && ans >= T[r])
                ans = T[r];
            l = (l + 1) / 2;
            r = (r - 1) / 2;
        }
        return ans;
    }

    int get_pref(int w) {
        return get(0, upper_bound(ws.begin(), ws.end(), make_pair(w, S + n)) - ws.begin() - 1);
    }

    void upd(int i, int val) {
        i += n;
        T[i] = val;
        while ((i /= 2) > 0) {
            T[i] = min(T[2 * i], T[2 * i + 1]);
        }
    }
};

struct Open {
    tree st;
    map<int, int> cnt;
    Open() = default;
    int getMin(int crit, int mx) {
        auto it = cnt.find(crit);
        if (it != cnt.end() && it->second > 0) {
            return crit;
        }
        return st.get_pref(mx);
    }

    void add(seg *s) {
        cnt[s->r]++;
        st.upd(s->p, s->r);
    }

    void del(seg *s) {
        cnt[s->r]--;
        st.upd(s->p, INF);
    }

    void clear() {
        st.clear();
        cnt.clear();
    }
} open;

struct e {
    int t, tp;
    seg *s;
};

bool operator<(const e &a, const e &b) {
    if (a.t == b.t) {
        if (a.tp == b.tp)
            return a.s > b.s;
        return a.tp > b.tp;
    }
    return a.t > b.t;
}

int n, k;

bool can(int lim) {
    open.clear();
    priority_queue<e> ev;
    for (int i = 0; i < n; i++) {
        if (S[i].w <= lim) {
            ev.push({S[i].l, 0, &S[i]});
        }
    }
    while (!ev.empty()) {
        auto e = ev.top();
        ev.pop();
        if (e.tp == 0) {
            auto *s = e.s;
            s->d = INF;
            if (s->l == 1) {
                s->d = 0;
            } else {
                int mnr = open.getMin(s->l - 1, lim - s->w);
                if (mnr < s->r) {
                    s->d = mnr;
                }
            }
            if (s->d != INF) {
                ev.push({s->d, 1, s});
                ev.push({s->r + 1, 2, s});
                if (s->r == k) {
                    return true;
                }
            }
        } else if (e.tp == 1) {
            open.add(e.s);
        } else {
            open.del(e.s);
        }
    }
    return false;
}


int bin() {
    int l = 0, r = INF;
    while (l + 1 != r) {
        int m = (l + r) / 2;
        if (can(m))
            r = m;
        else
            l = m;
    }
    if (r == INF) return -1;
    return r;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> k;
    for (int i = 0; i < n; i++) {
        int l, r, w;
        cin >> l >> r >> w;
        l = max(l, (int) 1);
        r = min(r, k);
        S[i] = {l, r, w, -1, -1};
        open.st.add(w, &S[i]);
    }
    open.st.build();
    cout << bin();
    return 0;
}
