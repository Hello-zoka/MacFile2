#include <vector>
#include <algorithm>
#include <vector>
#include <iostream>
#include <set>

using namespace std;

#define int long long
#define maxn 1e18
#define maxk 10000000

struct node {
    node *l, *r;
    int x, msk, sz, cnt;
    node() {}
};

node *t[maxk];
int cur = 0;

node *full(int sz) {
    node *ans = new node();
    ans->l = ans->r = NULL;
    ans->x = ans->sz = sz;
    ans->cnt = ans->msk = 0;
    t[cur++] = ans;
    return ans;
}

void go(node *a, int tp) {
    if (a->x == 0) return;
    if (a->x == 1 && (tp == 1)) return;
    a->x = (a->x + tp) / 2;
    a->msk += tp << ((a->cnt)++);
}

void push(node *a) {
    if (!a->l) {
        a->l = full((a->sz + 1) / 2);
        a->r = full(a->sz / 2);
    }
    for (int i = 0; i < a->cnt; i++) {
        int v1 = ((a->msk) >> i) & 1;
        int v2 = (a->l->x & 1) ^v1;
        go(a->l, v1);
        go(a->r, v2);
    }
    a->msk = a->cnt = 0;
}

node *rt;

int geti(int x) {
    node *a = rt;
    int cc = 1;
    while (a->sz > 1) {
        push(a);
        if (a->l->x < x) {
            cc += a->l->sz;
            x -= a->l->x;
            a = a->r;
        } else {
            a = a->l;
        }
    }
    return cc;
}

int tl, tr;

void mod(node *a, int x) {
    if (x >= tl && (x + a->x <= tr + 1)) {
        if ((x & 1) == (tl & 1))
            go(a, 0);
        else
            go(a, 1);
        return;
    }
    push(a);
    int tm = (x + a->l->x);
    if (tm <= tr) {
        mod(a->r, a->l->x + x);
    }
    if (tm > tl) {
        mod(a->l, x);
    }
    a->x = a->l->x + a->r->x;
}


signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, m;
    cin >> n >> m;
    rt = full(m + 1);
    for (int i = 0; i < n; i++) {
        int l, r;
        cin >> l >> r;
        cout << geti(l) << " " << geti(r) << '\n';
        tl = l;
        tr = r;
        mod(rt, 1);
    }
}