#include <iostream>
#include <vector>
#include <stdio.h>
#include <algorithm>
#include <set>

using namespace std;
#define int long long
#define maxn 2000070
vector<vector<int>> g;
vector<int> ans;
vector<set<int>> used;


int t[4 * maxn], pus[4 * maxn];

struct e {
    int l, r, x, typ, ind;
};


bool operator<(const e &a, const e &b) {
    if (a.x == b.x) {
        return a.typ > b.typ;
    }
    return a.x < b.x;
}

void pu(int v, int tl, int tr) {
    if (pus[v] == -2) return;
    if (tl + 1 == tr) {
        t[v] = pus[v];
        pus[v] = -2;
    } else {
        t[v] = pus[v];
        pus[v * 2 + 1] = pus[v];
        pus[v * 2 + 2] = pus[v];
        pus[v] = -2;
    }
}

int get(int v, int tl, int tr, int pos) {
    // cerr << tl << " " << tr << " " << l << " " << r << '\n';
    pu(v, tl, tr);
    if (tl + 1 == tr) {
        // cerr << tl << " answeer \n";
        return t[v];
    }
    int tm = (tl + tr) / 2;
    if (pos < tm)
        return get(v * 2 + 1, tl, tm, pos);
    return get(v * 2 + 2, tm, tr, pos);
}

void upd(int v, int tl, int tr, int l, int r, int val) {
    pu(v, tl, tr);
    if (l >= tr || r <= tl) {
        return;
    }
    if (l <= tl && tr <= r) {
        // cerr << tl <<  "  " << tr  << " ind upd alslkdkas\n";
        pus[v] = val;
        // cerr << '\n';
        // cerr << tl << " " << tr << " updated with val: " << val << "    range was:  " << l << " " << r << '\n';
        pu(v, tl, tr);
        return;
    }
    int tm = (tl + tr) / 2;
    upd(v * 2 + 1, tl, tm, l, min(r, tm), val);
    upd(v * 2 + 2, tm, tr, max(l, tm), r, val);
    // t[v] = max(t[v * 2 + 1], t[v * 2 + 2]);
}

void dfs(int st) {
    int mx = used[st].size(), ind = st;
    for (int to : g[st]) {
        dfs(to);
        if (used[to].size() > mx) {
            mx = used[to].size();
            ind = to;
        }
    }
    if (ind != st) {
        for (int i : used[st]) {
            used[ind].insert(i);
        }
    }
    for (int to : g[st]) {
        if (to != ind) {
            for (int i : used[to])
                used[ind].insert(i);
        }
    }
    ans[st] = used[ind].size();
    if (ind != st)
        swap(used[st], used[ind]);
}


signed main() {
    int n, m;
    cin >> n >> m;
    vector<e> lst;
    vector<pair<int, int>> ind;
    for (int i = 0; i < 4 * maxn; i++) {
        pus[i] = -2;
        t[i] = -1;
    }
    for (int i = 0; i < n; i++) {
        int x1, y1, x2, y2;
        cin >> x1 >> y1 >> x2 >> y2;
        ind.push_back({x1, i * 4});
        ind.push_back({y1, i * 4 + 1});
        ind.push_back({x2, i * 4 + 2});
        ind.push_back({y2, i * 4 + 3});
        e a;
        a.l = x1;
        a.r = x2;
        a.x = y1;
        a.typ = 1;
        a.ind = i;
        lst.push_back(a);
        a.x = y2;
        a.typ = -1;
        lst.push_back(a);
    }
    for (int i = 0; i < m; i++) {
        int x, y, c;
        cin >> x >> y >> c;
        e a;
        a.x = y;
        a.l = x;
        a.r = c;
        a.typ = 0;
        ind.push_back({x, n * 4 + i * 2});
        ind.push_back({y, n * 4 + i * 2 + 1});
        a.ind = i;
        lst.push_back(a);
    }
    sort(ind.begin(), ind.end());
    vector<int> cast(n * 4 + m * 2);
    int cur = 0;
    for (int i = 0; i < ind.size(); i++) {
        if (i != 0 && ind[i].first != ind[i - 1].first)
            cur++;
        cast[ind[i].second] = cur;
    }
    sort(lst.begin(), lst.end());
    vector<int> pr;
    used.assign(n, {});
    pr.assign(n, -1);

    int nn = 4 * n + 2 * m;
    for (int i = 0; i < lst.size(); i++) {
        // cerr << lst[i].typ << " typ \n";
        if (lst[i].typ == 1) {
            // cerr << cast[4 * lst[i].ind] << "  " << cast[4 * lst[i].ind + 2] + 1 << " l r \n";
            int x = get(0, 0, nn, cast[4 * lst[i].ind]);
            pr[lst[i].ind] = x;
            upd(0, 0, nn, cast[4 * lst[i].ind], cast[4 * lst[i].ind + 2] + 1, lst[i].ind);
        } else if (lst[i].typ == -1) {
            int x = pr[lst[i].ind];
            // cerr << x << " " << cast[4 * lst[i].ind] << "  " << cast[4 * lst[i].ind + 2] + 1 << " l r delete\n";
            upd(0, 0, nn, cast[4 * lst[i].ind], cast[4 * lst[i].ind + 2] + 1, x);
        } else {
            // cerr << cast[n * 4 + 2 * lst[i].ind] << "   pos \n";
            int x = get(0, 0, nn, cast[n * 4 + 2 * lst[i].ind]);
            // cerr << x;
            if (x >= 0)
                used[x].insert(lst[i].r);
            // cerr << x << " " << lst[i].r << '\n';
        }
    }
    g.assign(n, {});
    ans.assign(n, 0);

    for (int i = 0; i < n; i++) {
        if (pr[i] != -1) {
            g[pr[i]].push_back(i);
        }
    }
    for (int i = 0; i < n; i++) {
        if (pr[i] == -1) {
            dfs(i);
        }
    }
    for (int i = 0; i < n; i++) {
        cout << ans[i] << "\n";
    }
    return 0;
}