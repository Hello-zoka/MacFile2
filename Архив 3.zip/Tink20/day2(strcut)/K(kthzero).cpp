#include <iostream>
#include <vector>
#include <stdio.h>
#include <algorithm>

using namespace std;
#define int long long
vector<int> t;
int n, lg = 0;

void inc(int x, int val) {
    for (int i = x; i <= n; i = (i | (i + 1))) {
        t[i] += val;
    }
}

int get(int r) {
    if (r < 0) return 0;
    int v2 = 0;
    for (int x = r; x >= 0; x = (x & (x + 1)) - 1)
        v2 += t[x];
    return v2;
}

int find_last_less(int s) {
    int k = -1;
    for (int l = lg; l >= 0; l--) {
        // cout << k << " " << (1 << l) << "  " << s << '\n';
        if (k + (1 << l) < n && t[k + (1 << l)] < s) {
            // cout << "wtf";
            k += (1 << l);
            s -= t[k];
        }
    }
    return k;
}


signed main() {
    cin >> n;
    t.assign(n + 7, 0);
    vector<int> lst;
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        if (x == 0)
            inc(i, 1);
        lst.push_back(x);
    }
    int c = 1;
    while (c < n) {
        c *= 2;
        lg++;
    }
    int m;
    cin >> m;
    for (int q = 0; q < m; q++) {
        char x;
        cin >> x;
        if (x == 'u') {
            int pos, val;
            cin >> pos >> val;
            pos--;
            if (val == 0 && lst[pos] != val)
                inc(pos, 1);
            else if (val != 0 && lst[pos] == 0)
                inc(pos, -1);
            lst[pos] = val;
        } else {
            int l, r, k;
            cin >> l >> r >> k;
            l--;
            r--;
            int xx = get(l - 1);
            if (get(r) < xx + k) {
                cout << -1 << '\n';
            } else {
                cout << find_last_less(k + xx) + 2 << '\n';
            }
        }
    }
    return 0;
}