#include <iostream>
#include <vector>
#include <stdio.h>
#include <algorithm>
#include <set>
#include <chrono>
#include <random>

using namespace std;
#define int long long
#define maxn 400070
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
int lst[maxn];

struct node {
    node *l, *r;
    int val, pr, mod, sz;

    node() {
        sz = 0;
        mod = 0;
        pr = (rng() << 10) + rng();
        val = 0;
        l = nullptr;
        r = nullptr;
    }
};

node *rt[2];

void upd(node *a) {
    if (!a) return;
    int sz = 1;
    if (a->l)
        sz += a->l->sz;
    if (a->r)
        sz += a->r->sz;
    a->sz = sz;
}


void push(node *t) {
    if (!t) return;
    if (t->mod) {
        if (t->l) {
            t->l->mod += t->mod;
        }
        if (t->r) {
            t->r->mod += t->mod;
        }
        t->val += t->mod;
        t->mod = 0;
    }
}

node *merge(node *l, node *r) {
    if (!l) return r;
    if (!r) return l;
    if (l->pr < r->pr) {
        push(l);
        l->r = merge(l->r, r);
        upd(l);
        return l;
    }
    push(r);
    r->l = merge(l, r->l);
    upd(r);
    return r;
}

void split(node *t, node *&a, node *&b, int cnt) {
    if (!t) {
        b = 0;
        a = 0;
        return;
    }
    if (!cnt) {
        a = 0;
        b = t;
        upd(b);
        return;
    }
    int pp = 0;
    if (t->l)
        pp += t->l->sz;
    push(t);
    if (pp >= cnt) {
        split(t->l, a, t->l, cnt);
        b = t;
        upd(a);
        upd(b);
    } else {
        split(t->r, t->r, b, cnt - pp - 1);
        a = t;
        upd(a);
        upd(b);
    }
}

bool fl = false;

int les(node *t, int x) {
    int cnt = 0;
    while (t) {
        push(t);
        if (t->val == x) {
            t = t->r;
            continue;
        }
        if (t->val > x) {
            t = t->r;
        } else {
            cnt++;
            if (t->r) cnt += t->r->sz;
            t = t->l;
        }
    }
    return cnt;
}

node *add(node *t, int len, int p) {
    node *a, *b;
    split(t, a, b, len);
    a->mod += p;
    return merge(a, b);
}

int cur = 0;

node *insert(node *t, int x) {
    node *tree = t;
    int cnt = 0;
    cnt = les(t, x);
    cnt = t->sz - cnt;
    node *nd = new node;
    nd->val = x;
    nd->sz = 1;
    node *a, *b;
    split(tree, a, b, cnt);
    return merge(merge(a, nd), b);
}

node *rem(node *t, int x) {
    node *tree = t;
    int cnt = 0;
    fl = 0;
    while (t) {
        push(t);
        if (t->val == x) {
            fl = true;
            if (t->l)
                cnt += t->l->sz;
            break;
        }
        if (t->val < x) {
            t = t->l;
        } else {
            cnt++;
            if (t->l)
                cnt += t->l->sz;
            t = t->r;
        }
    }
    if (!fl) {
        return tree;
    }
    node *a, *b, *c, *d;
    split(tree, a, b, cnt + 1);
    split(a, c, d, cnt);
    return merge(c, b);
}

void print(node *t) {
    if (!t) return;
    push(t);
    if (t->r) print(t->r);
    if (t->val != 0) {
        cout << t->val << " ";
    }
    if (t->l)
        print(t->l);
}

void prec(int n) {
    sort(lst + 1, lst + n + 1);
    reverse(lst + 1, lst + n + 1);
    for (int i = maxn; i >= 1; i--) {
        node *nd = new node;
        nd->val = 0;
        nd->sz = 1;
        rt[1] = merge(rt[1], nd);
    }
    for (int i = 1; i <= n; i++) {
        node *nd = new node;
        nd->val = lst[i];
        nd->sz = 1;
        rt[cur] = merge(rt[cur], nd);
        rt[1 - cur] = add(rt[1 - cur], lst[i], 1);
    }
    for (int i = maxn; i >= 1; i--) {
        node *nd = new node;
        nd->val = 0;
        nd->sz = 1;
        rt[0] = merge(rt[0], nd);
    }
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= n; i++) {
        cin >> lst[i];
    }
    prec(n);
    for (int i = 1; i <= m; i++) {
        char zap;
        int x;
        cin >> zap;
        if (zap == 'a') {
            cin >> x;
            rt[1 - cur] = add(rt[1 - cur], x, 1);
            rt[cur] = insert(rt[cur], x);
        } else if (zap == 'r') {
            cin >> x;
            rt[cur] = rem(rt[cur], x);
            if (fl)
                rt[1 - cur] = add(rt[1 - cur], x, -1);
        } else if (zap == 'c') {
            cin >> x;
            cout << les(rt[cur], x + 1) - les(rt[cur], x) << '\n';
        } else {
            cur = 1 - cur;
        }
    }
    print(rt[cur]);
    return 0;
}