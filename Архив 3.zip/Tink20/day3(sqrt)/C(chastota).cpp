#include <iostream>
#include <vector>
#include <math.h>
#include <map>
#include <unordered_map>

using namespace std;

#define int long long
#define INF 1e9
#define maxn 100005
#define MOD 1000000009
const int P = 239017;
unsigned long long h[maxn + 1], deg[maxn + 1];

auto get_hash(int l, int r) {
    return (h[r + 1] - (h[l] * deg[r - l + 1]) % MOD + MOD) % MOD;
}

signed main() {
    string s;
    cin >> s;
    int n;
    cin >> n;
    vector<pair<int, string>> lst;
    vector<int> used;
    used.assign(s.size(), 0);
    vector<vector<int>> hck;
    vector<map<int, int>> mp(s.size());

    for (int i = 0; i < n; i++) {
        int k;
        string m;
        cin >> k >> m;
        lst.push_back({k, m});
        used[m.size() - 1] = 1;
        int hh = 0;
        for (int j = 0; j < m.size(); j++) {
            hh = (hh * P) % MOD + (m[j] - 'a' + 1);
            hh %= MOD;
        }
        // cerr << hh << "     zpros \n";
        mp[m.size() - 1].insert({hh, i});
    }
    h[0] = 0, deg[0] = 1;
    for (int i = 0; i < s.size(); i++) {
        h[i + 1] = (h[i] * P) % MOD + (s[i] - 'a' + 1);
        h[i + 1] %= MOD;
        deg[i + 1] = deg[i] * P;
        deg[i + 1] %= MOD;
    }
    vector<vector<int>> res(n);
    for (int k = 0; k < s.size(); k++) {
        if (used[k]) {
            for (int i = 0; i + k < s.size(); i++) {
                // cerr << get_hash(i, i + k) << " " << i + k << '\n';
                if (mp[k].find(get_hash(i, i + k)) == mp[k].end()) continue;
                // cerr << "Wd";
                res[mp[k].find(get_hash(i, i + k))->second].push_back(i);
            }
        }
    }
    for (int i = 0; i < n; i++) {
        int k = lst[i].first;
        int ans = INF;
        for (int j = 0; j + k - 1 < res[i].size(); j++) {
            ans = min(res[i][j + k - 1] - res[i][j], ans);
        }
        if (ans == INF) {
            cout << -1 << '\n';
        } else {
            cout << ans + lst[i].second.size() << '\n';
        }
    }
    return 0;
}