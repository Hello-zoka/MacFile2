#include <iostream>
#include <vector>
#include <math.h>

using namespace std;

int main() {
    int n, m;
    cin >> n >> m;
    int k = 700;
    int cur[n];
    vector<vector<int>> lst;
    pair<int, int> e[m];
    lst.assign(n, {});
    for (int i = 0; i < n; i++) {
        cin >> cur[i];
    }
    for (int i = 0; i < m; i++) {
        int a, b;
        cin >> a >> b;
        a--;
        b--;
        e[i] = {a, b};
        lst[a].push_back(b);
        lst[b].push_back(a);
    }
    vector<int> ind;
    int x = 0;
    for (int i = 0; i < n; i++) {
        ind.push_back(-1);
        if (lst[i].size() > k) {
            x++;
            ind[i] = x - 1;
        }
    }
    int hmat[x][x], hcnt[x][100007];
    int cnt = 0;
    for (int i = 0; i < x; i++) {
        for (int j = 0; j < x; j++) {
            hmat[i][j] = 0;
        }
        for (int j = 0; j < 100007; j++) {
            hcnt[i][j] = 0;
        }
    }
    for (int i = 0; i < m; i++) {
        pair<int, int> a = e[i];

        if (lst[a.first].size() > k) {
            hcnt[ind[a.first]][cur[a.second]]++;
            if (lst[a.second].size() > k) {
                hmat[ind[a.first]][ind[a.second]] = 1;
                hmat[ind[a.second]][ind[a.first]] = 1;
            }
        }
        if (lst[a.second].size() > k) {
            hcnt[ind[a.second]][cur[a.first]]++;
        }
        if (cur[a.first] == cur[a.second])
            cnt++;
    }
    int q;
    cin >> q;
    for (int qq = 0; qq < q; qq++) {
        int a, b;
        cin >> a >> b;
        a--;
        if (lst[a].size() > k) {
            cnt -= hcnt[ind[a]][cur[a]];
            cnt += hcnt[ind[a]][b];
            for (int i = 0; i < x; i++) {
                if (i != ind[a] && hmat[i][ind[a]] == 1) {
                    hcnt[i][cur[a]] -= 1;
                    hcnt[i][b] += 1;
                }
            }
            cur[a] = b;
        } else {
            for (int i = 0; i < lst[a].size(); i++) {
                int to = lst[a][i];
                if (cur[to] == cur[a])
                    cnt--;
                if (cur[to] == b)
                    cnt++;
                if (lst[to].size() > k) {
                    hcnt[ind[to]][cur[a]]--;
                    hcnt[ind[to]][b]++;
                }
            }
            cur[a] = b;
        }
        cout << m - cnt << '\n';
    }
    return 0;
}