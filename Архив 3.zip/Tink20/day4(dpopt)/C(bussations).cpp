#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>

using namespace std;

#define int long long
#define maxn 60007
#define eps 0.00000001
#define double long double
double dp[maxn][102];
vector<double> lst, sm, sm1;

double get(int l, int r) {
    // cerr << r << " " << l << '\n';
    int x = 0, x1 = 0;
    if (l != 0) {
        x = sm[l - 1];
        x1 = sm1[l - 1];
    }
    double p = (sm[r] - x) / (double) (r - l + 1);
    double res = p * p * (r - l + 1) - (sm[r] - x) * p * 2 + sm1[r] - x1;
    return res;
}

void rel(int k, int l, int r, int lop, int rop) {
    if (l > r) return;
    int m = (l + r) / 2;
    int op = lop, mx = min(rop + 1, m);
    double ans = dp[op][k - 1] + get(op + 1, m);
    for (int i = op; i < mx; i++) {
        double x = dp[i][k - 1] + get(i + 1, m);
        if (x < ans) {
            ans = x;
            op = i;
        }
    }
    dp[m][k] = ans;
    rel(k, l, m - 1, lop, op);
    rel(k, m + 1, r, op, rop);
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, k;
    cin >> n >> k;
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        lst.push_back(x);
    }
    sort(lst.begin(), lst.end());
    for (int i = 0; i < n; i++) {
        sm.push_back(lst[i]);
        sm1.push_back(lst[i] * lst[i]);
        if (i != 0) {
            sm[i] += sm[i - 1];
            sm1[i] += sm1[i - 1];
        }
    }
    for (int i = 0; i < n; i++) {
        dp[i][0] = get(0, i);
        // cerr << dp[i][0] << " ";
    }
    for (int i = 1; i < k; i++) {
        rel(i, i, n - 1, i - 1, n - 1);
    }
//    for (int i = 0; i < n; i++) {
//        for (int j = 0; j <= k; j++) {
//            cerr << dp[i][j] << " ";
//        }
//        cerr << '\n';
//    }
    printf("%.7Lf", dp[n - 1][k - 1]);
    // cout << setprecision(20) << dp[n - 1][k - 1];
    return 0;
}