#include <iostream>
#include <vector>
#include <algorithm>
#include <set>

using namespace std;

#define int long long
#define maxn 300007

struct e {
    int u, v;
};
struct qu {
    int u, v, typ, ans;
};

bool operator<(const e &a, const e &b) {
    if (a.u == b.u) return a.v < b.v;
    return a.u < b.u;
}

vector<int> par, sz;
vector<pair<int *, int>> hist;
int n, k, cnt;
qu q[maxn];

int fnd(int v) {
    if (par[v] == v) return v;
    return fnd(par[v]);
}

void un(int a, int b) {
    a = fnd(a);
    b = fnd(b);
    if (a != b) {
        cnt -= 1;
        if (sz[a] < sz[b]) {
            swap(a, b);
        }
        hist.push_back({&par[b], par[b]});
        par[b] = a;
        if (sz[a] == sz[b]) {
            hist.push_back({&sz[a], sz[a]});
            sz[a]++;
        }
    }
}

vector<e> t[4 * maxn];

void addEdg(int l, int r, e u, int c, int tl, int tr) {
    if (l > tr || r < tl) {
        return;
    }
    if (l <= tl && tr <= r) {
        t[c].push_back(u);
        return;
    }
    int tm = (tl + tr) / 2;
    addEdg(l, r, u, c * 2 + 1, tl, tm);
    addEdg(l, r, u, c * 2 + 2, tm + 1, tr);
}

void solve(int c, int l, int r) {
    int st = hist.size(), prevans = cnt;
    for (e u : t[c]) {
        un(u.u, u.v);
    }
    if (l == r) {
        if (q[l].typ == 3) {
            q[l].ans = cnt;
        }
    } else {
        int tm = (l + r) / 2;
        solve(c * 2 + 1, l, tm);
        solve(c * 2 + 2, tm + 1, r);
    }
    while (hist.size() != st) {
        *hist.back().first = hist.back().second;
        hist.pop_back();
    }
    cnt = prevans;
}

signed main() {
    cin >> n >> k;
    cnt = n;
    par.assign(n, 0);
    sz.assign(n, 0);
    for (int i = 0; i < n; i++) par[i] = i;
    set<pair<e, int>> lst;
    int bl = 0;

    for (int i = 0; i < k; i++) {
        char a;
        // cerr << 1;
        cin >> a;
        if (a == '+') {
            q[i].typ = 1;
            cin >> q[i].u >> q[i].v;
            if (q[i].u > q[i].v) swap(q[i].u, q[i].v);
            q[i].u--;
            q[i].v--;
            e aa;
            aa.u = q[i].u;
            aa.v = q[i].v;
            lst.insert({aa, i});
        } else if (a == '-') {
            q[i].typ = 2;
            cin >> q[i].u >> q[i].v;
            if (q[i].u > q[i].v) swap(q[i].u, q[i].v);
            q[i].u--;
            q[i].v--;
            e aa;
            aa.u = q[i].u;
            aa.v = q[i].v;
            // cerr << 1;
            auto ind = lst.lower_bound({aa, 0});
            addEdg(ind->second, i, ind->first, 0, 0, k - 1);
            //  cerr << 2;
            lst.erase(ind);
        } else {
            q[i].typ = 3;
            bl = 1;
        }
    }
    if (!bl) return 0;
    for (auto a : lst) {
        addEdg(a.second, k - 1, a.first, 0, 0, k - 1);
    }
    solve(0, 0, k - 1);
    for (int i = 0; i < k; i++) {
        if (q[i].typ == 3) {
            cout << q[i].ans << '\n';
        }
    }
    return 0;
}