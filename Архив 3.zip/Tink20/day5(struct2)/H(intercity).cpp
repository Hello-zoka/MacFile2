#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

#define int long long
#define MAXN 4000000
#define INF 1e14

struct Node {
    int l, r, x;

    Node() {
        x = INF, l = -1, r = -1;
    }

    Node(int xx) {
        x = xx, l = -1, r = -1;
    }
};

Node pos[MAXN];
int sz = 0;

int build(int tl, int tr) {
    if (tl + 1 == tr) {
        pos[sz] = Node(0);
        return sz++;
    }
    int tm = (tl + tr) / 2;
    int num = sz++;
    Node x = Node(INF);
    x.l = build(tl, tm);
    x.r = build(tm, tr);
    int a = INF, b = INF;
    if (x.l != -1) {
        a = pos[x.l].x;
    }
    if (x.r != -1) {
        b = pos[x.r].x;
    }
    x.x = min(a, b);
    pos[num] = x;
    return num;
}

int upd(int v, int tl, int tr, int p, int val) {
    if (tl + 1 == tr) {
        pos[sz] = Node(val);
        return sz++;
    }
    int tm = (tl + tr) / 2;
    if (p < tm) {
        Node x = Node(INF);
        int num = sz++;
        x.l = upd(pos[v].l, tl, tm, p, val);
        x.r = pos[v].r;
        int a = INF, b = INF;
        if (x.l != -1) a = min(a, pos[x.l].x);
        if (x.r != -1) b = min(b, pos[x.r].x);
        x.x = min(a, b);
        pos[num] = x;
        return num;
    }
    Node x = Node(INF);
    int num = sz++;
    x.r = upd(pos[v].r, tm, tr, p, val);
    x.l = pos[v].l;
    int a = INF, b = INF;
    if (x.l != -1) a = min(a, pos[x.l].x);
    if (x.r != -1) b = min(b, pos[x.r].x);
    x.x = min(a, b);
    pos[num] = x;
    return num;
}

int get(int tl, int l, int r, int k) {
    if (l + 1 == r) {
        return l;
    }
    int m = (l + r) / 2;
    if (pos[pos[tl].l].x <= k) {
        return get(pos[tl].l, l, m, k);
    }
    return get(pos[tl].r, m, r, k);
}

struct bil {
    int x, c, typ;
};

bool operator<(const bil &a, const bil &b) {
    if (a.x == b.x) return a.typ < b.typ;
    return a.x < b.x;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, s, m;
    cin >> n >> s >> m;
    vector<bil> lst;
    for (int i = 0; i < m; i++) {
        int l, r, c;
        cin >> c >> l >> r;
        bil a, b;
        a.x = l;
        b.x = r;
        a.c = c;
        b.c = c;
        a.typ = 1;
        b.typ = -1;
        lst.push_back(a);
        lst.push_back(b);
    }
    vector<int> vers;
    vers.push_back(build(0, s));
    lst.push_back({0, 0, -2});
    sort(lst.begin(), lst.end());
    for (int i = 1; i < lst.size(); i++) {
        if (lst[i].typ == 1) {
            vers.push_back(upd(vers[i - 1], 0, s, lst[i].c - 1, INF));
        } else {
            vers.push_back(upd(vers[i - 1], 0, s, lst[i].c - 1, lst[i].x));
        }
    }
//    for (int i= 0; i < lst.size(); i++){
//        cerr << lst[i].x << " " << lst[i].typ << " " << lst[i].c << "     ";
//    }
//    cerr << "THAT WAS FUCKING mas NIGAA\n";
//
//    for (int i =0; i < vers.size(); i++){
//        cerr << pos[vers[i]].x << " ";
//    }
//    cerr << "THAT WAS FUCKING TREE NIGAA\n";
    int q;
    cin >> q;
    int p = 0;
    // cerr << "\nVERSIONS::\n";
    for (int qq = 0; qq < q; qq++) {
        int x, y;
        cin >> x >> y;
        int a = x + p, b = y + p;
        // cerr << a << " " << b << "\n";
        bil xx = {b, (int) INF, -1};
        int res;
        // if (lower_bound(lst.begin(), lst.end(), xx) == lst.end()) cout << "blaaa";
        int v = upper_bound(lst.begin(), lst.end(), xx) - lst.begin() - 1;
        // cerr << v <<" ";
        if (pos[vers[v]].x > a) res = 0;
        else
            res = get(vers[v], 0, s, a) + 1;
        p = res;
        cout << res << '\n';
    }
}