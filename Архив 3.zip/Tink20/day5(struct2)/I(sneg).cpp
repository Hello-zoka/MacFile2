#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

#define int long long

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    int ans = 0;
    vector<pair<int, int >> lst = {{0, 0}};
    vector<int> sz = {0};
    for (int i = 0; i < n; i++) {
        int t, m;
        cin >> t >> m;
        if (m == 0) {
            lst.push_back({lst[lst[t].first].first, lst[lst[t].first].second});
            sz.push_back(sz[lst[t].first]);
            ans += sz[sz.size() - 1];
        } else {
            lst.push_back({t, m});
            sz.push_back(sz[t] + m);
            ans += sz[sz.size() - 1];
        }
    }
    cout << ans << "\n";
}