#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

#define int long long

class PSt {
private:
    int val;
    PSt *nxt;

    PSt(int vall, PSt *_nxt = 0) : val(vall), nxt(_nxt) {}

public:
    PSt *push(int x) {
        return new PSt(x, this);
    }

    int top() {
        return val;
    }

    PSt *pop() {
        return nxt;
    }

    static PSt *null;
};

PSt *PSt::null = 0;

class PQ {
private:
    int sz, helpsz;
    PSt *main, *help, *main2, *help2;

    PQ(int _sz, int _helpsz, PSt *_main, PSt *_help, PSt *_main2, PSt *_help2) : sz(_sz),
                                                                                 helpsz(_helpsz),
                                                                                 main(_main),
                                                                                 help(_help),
                                                                                 main2(_main2),
                                                                                 help2(_help2) {}

    PQ *morph() {
        if (helpsz == -1) {
            helpsz = sz;
            help2 = PSt::null;
            main2 = main;
        }
        if (helpsz > 0) {
            helpsz--;
            help2 = help2->push(main2->top());
            main2 = main2->pop();
        }
        if (helpsz == 0) {
            help = help2;
            helpsz--;
        }
        return new PQ(sz, helpsz, main, help, main2, help2);
    }

public:
    PQ() : sz(0), helpsz(-1) {
        main = help = main2 = help2 = PSt::null;
    }

    PQ *push(int val) {
        return PQ(sz + 1, helpsz, main->push(val), help, main2, help2).morph();
    }

    int top() {
        return help->top();
    }

    PQ *pop() {
        return PQ(sz - 1, helpsz == -1 ? -1 : helpsz - 1, main, help->pop(), main2, help2).morph();
    }
};

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    vector<PQ> lst = {PQ()};
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        if (x == 1) {
            int t, m;
            cin >> t >> m;
            lst.push_back(*lst[t].push(m));
        } else {
            int t;
            cin >> t;
            cout << lst[t].top() << "\n";
            lst.push_back(*lst[t].pop());
        }
    }
}