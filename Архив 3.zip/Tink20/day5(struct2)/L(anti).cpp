#include <vector>
#include <algorithm>
#include <iostream>

using namespace std;

#define int long long
#define maxn 200
#define maxa 2000007
#define C 1e9
int l[maxn], r[maxn], c[maxn];
int pr[maxa], rk[maxa], mv[maxa];
int dp[maxa];

int get(int x) {
    if (pr[x] == x) return x;
    return pr[x] = get(pr[x]);
}

void sl(int a, int b) {
    a = get(a);
    b = get(b);
    if (a == b) return;
    if (rk[a] > rk[b]) {
        swap(a, b);
    }
    pr[a] = b;
    if (dp[mv[b]] > dp[mv[a]]) {
        mv[b] = mv[a];
    }
    if (rk[a] == rk[b]) rk[b]++;
}

int get_mn(int x) {
    return dp[mv[get(x)]];
}

vector<int> st;

void add(int pos) {
    mv[pos] = pos;
    while (!st.empty() && dp[st.back()] > dp[pos]) {
        sl(pos, st.back());
        st.pop_back();
    }
    st.push_back(pos);
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n, a;
    cin >> n >> a;
    for (int i = 0; i < n; i++) {
        cin >> l[i] >> r[i] >> c[i];
    }
    for (int i = 0; i <= a; i++) {
        dp[i] = i * C;
        pr[i] = i;
        rk[i] = i;
        mv[i] = -1;
    }
    for (int i = a; i >= 0; i--) {
        add(i);
        for (int j = 0; j < n; j++) {
            if (i - l[j] < 0) continue;
            int cur = i - l[j];
            if (cur + r[j] > a) continue;
            int x = get_mn(cur + r[j]);
            x -= c[j];
            dp[cur] = max(dp[cur], x);
        }
    }
    cout << dp[0];
    return 0;
}