#include <vector>
#include <algorithm>
#include <iostream>
#include <random>
#include <chrono>

using namespace std;

#define int long long

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

const int INF = 10000000;

signed main() {
    // 123222122
    string ans = "p";
    int k = rng() % 3;
    if (k == 0 || k == 1) {
        int n = 700;
        vector<vector<int>> dp;
        dp.assign(n + 50, {});
        for (int i = 0; i < n + 4; i++) {
            for (int j = 0; j < n + 4; j++) {
                dp[i].push_back(0);
            }
        }
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                if (i == j) {
                    dp[i][j] = 0;
                } else {
                    dp[i][j] = INF;
                }
            }
        }
        for (int i = 1; i <= 300; i++) {
            int u = rng() % n;
            int v = rng() % n;
            dp[u][v] = 1;
            dp[v][u] = 1;
        }
        for (int i = 1; i <= 300; i++) {
            for (int j = 1; j <= n; j++) {
                for (int r = 1; r <= n; r++) {
                    dp[i][j] = min(dp[i][j], dp[i][r] + dp[r][j]);
                }
            }
        }
        cout << "0\n6\n5\n7\n";
    } else {
        cout << ans << "\n";
    }
    return 0;
}