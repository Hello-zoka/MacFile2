#include <immintrin.h>
#include <limits.h>
#include <algorithm>
#include <stdio.h>

using namespace std;

// #pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,avx2,tune=native")

unsigned SegMinSum(unsigned *a, unsigned *b, int n) {
    __m256i min_avx = _mm256_set1_epi32(0);
    size_t i = 0;
    for (; i + 8 < n; i += 8) {
        __m256i curr_block = _mm256_lddqu_si256(reinterpret_cast<const __m256i *>(a + i));
        __m256i curr_block2 = _mm256_lddqu_si256(reinterpret_cast<const __m256i *>(b + i));
        min_avx = _mm256_add_epi32(min_avx, _mm256_min_epi32(curr_block2, curr_block));
    }
    // mn = min(mn, _mm256_extract_epi32(min_avx, 0));
    int *mins = (int *) &min_avx;
    unsigned ans = 0;
    for (i = (n - 1) / 8 * 8; i < n; i++) {
        ans += min(a[i], b[i]);
    }
    for (i = 0; i < 8; i++) {
        ans += mins[i];
    }
    return ans;
}#include <immintrin.h>
#include <limits.h>
#include <algorithm>
#include <stdio.h>

using namespace std;

// #pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,avx2,tune=native")

unsigned SegMinSum(unsigned *a, unsigned *b, int n) {
    __m256i min_avx = _mm256_set1_epi32(0);
    size_t i = 0;
    for (; i + 8 < n; i += 8) {
        __m256i curr_block = _mm256_lddqu_si256(reinterpret_cast<const __m256i *>(a + i));
        __m256i curr_block2 = _mm256_lddqu_si256(reinterpret_cast<const __m256i *>(b + i));
        min_avx = _mm256_add_epi32(min_avx, _mm256_min_epi32(curr_block2, curr_block));
    }
    // mn = min(mn, _mm256_extract_epi32(min_avx, 0));
    int *mins = (int *) &min_avx;
    unsigned ans = 0;
    for (i = (n - 1) / 8 * 8; i < n; i++) {
        ans += min(a[i], b[i]);
    }
    for (i = 0; i < 8; i++) {
        ans += mins[i];
    }
    return ans;
}