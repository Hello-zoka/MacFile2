#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

#define int long long
#define INF 1e12
#define MAXN 50000
#define inf 1e9

struct e {
    int u, v, cap, f, inda, indb;
};
int n, m;
vector<e> ed;
vector<int> lst[MAXN], d;
vector<int> p1 = {0, 0, 1, -1};
vector<int> p2 = {1, -1, 0, 0};

int q[MAXN];
vector<int> ptr;
int lm;
int sz;
int s, t;

int bfs() {
    int l = 0, r = 0;
    q[r++] = s;
    d.assign(sz, INF);
    d[s] = 1;
    while (l < r && d[t] == INF) {
        int v = q[l++];
        for (int i : lst[v]) {
            int to = ed[i].v;
            if (d[to] == INF && ed[i].cap - ed[i].f >= lm) {
                q[r++] = to;
                d[to] = d[v] + 1;
            }
        }
    }
    return d[t] != INF;
}

int dfs(int v, int f) {
    if (f == 0 || v == t) return f;
    while (ptr[v] < lst[v].size()) {
        int ind = lst[v][ptr[v]], to = ed[ind].v;
        if (d[to] == d[v] + 1 && ed[ind].cap - ed[ind].f >= f) {
            int cur = dfs(to, f);
            if (cur) {
                ed[ind].f += f;
                ed[ind ^ 1].f -= f;
                return f;
            }
        }
        ptr[v]++;
    }
    return 0;
}

void addedg(int a, int b, int x, int inda = -1, int indb = -1) {
    if (inda == -1) {
        inda = a;
        indb = b;
    }
    ed.push_back({a, b, x, 0, inda, indb});
    ed.push_back({b, a, 0, 0, indb, inda});
    lst[a].push_back(ed.size() - 2);
    lst[b].push_back(ed.size() - 1);
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m;
    vector<vector<int>> tab, vert, gor;
    sz = n * m + 2;
    s = n * m;
    t = n * m + 1;
    for (int i = 0; i < n; i++) {
        tab.push_back({});
        vert.push_back({});
        gor.push_back({});
        for (int j = 0; j < m; j++) {
            int x;
            cin >> x;
            tab[i].push_back(x);
            vert[i].push_back(-1);
            gor[i].push_back(-1);
            if (x == 2) {
                vert[i][j] = sz++;
                gor[i][j] = sz++;
                if ((i + j) % 2 == 0) {
                    addedg(i * m + j, vert[i][j], 1);
                    addedg(i * m + j, gor[i][j], 1);
                } else {
                    addedg(vert[i][j], i * m + j, 1);
                    addedg(gor[i][j], i * m + j, 1);
                }
            }
        }
    }
    int anssss = 0;
    int anssss2 = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if ((i + j) % 2 == 0) {
                anssss2 += tab[i][j];
                addedg(s, i * m + j, tab[i][j]);
                for (int k = 0; k < 4; k++) {
                    int x = i + p1[k], y = j + p2[k];
                    if (x < 0 || y < 0 || x >= n || y >= m) continue;
                    if (k <= 1) {
                        if (vert[i][j] != -1) {
                            if (vert[x][y] != -1) {
                                addedg(vert[i][j], vert[x][y], 1, i * m + j, x * m + y);
                            } else {
                                addedg(vert[i][j], x * m + y, 1, i * m + j, x * m + y);
                            }
                        } else if (vert[x][y] != -1) {
                            addedg(i * m + j, vert[x][y], 1, i * m + j, x * m + y);
                        } else {
                            addedg(i * m + j, x * m + y, 1);
                        }
                    } else {
                        if (gor[i][j] != -1) {
                            if (gor[x][y] != -1) {
                                addedg(gor[i][j], gor[x][y], 1, i * m + j, x * m + y);
                            } else {
                                addedg(gor[i][j], x * m + y, 1, i * m + j, x * m + y);
                            }
                        } else if (gor[x][y] != -1) {
                            addedg(i * m + j, gor[x][y], 1, i * m + j, x * m + y);
                        } else {
                            addedg(i * m + j, x * m + y, 1);
                        }
                    }
                }
            } else {
                addedg(i * m + j, t, tab[i][j]);
                anssss += tab[i][j];
            }
        }
    }
    int ans = 0;
    for (lm = 1 << 30; lm >= 1;) {
        if (!bfs()) {
            lm >>= 1;
            continue;
        }
        ptr.assign(sz, 0);
        while (int cur = dfs(s, lm)) ans += cur;
    }
    if (ans != anssss2 || ans != anssss) {
        cout << "Impossible!";
        return 0;
    }
    vector<vector<char>> res(n * 3, vector<char>(m * 3, '.'));
    for (int i = 0; i < ed.size(); i++) {
        if (ed[i].f == 1 && ed[i].u != s && ed[i].v != t) {
            int a = ed[i].inda, b = ed[i].indb;
            if (a >= n * m || b >= n * m) continue;
            // cerr << a << " " << b << '\n';
            int x = a / m, y = a % m, xx = b / m, yy = b % m;
            if (x + 1 == xx) {
                res[x * 3 + 2][y * 3 + 1] = 'X';
                res[x * 3 + 3][y * 3 + 1] = 'X';
            }
            if (x - 1 == xx) {
                res[x * 3][y * 3 + 1] = 'X';
                res[x * 3 - 1][y * 3 + 1] = 'X';
            }
            if (y + 1 == yy) {
                res[x * 3 + 1][y * 3 + 2] = 'X';
                res[x * 3 + 1][y * 3 + 3] = 'X';
            }
            if (y - 1 == yy) {
                res[x * 3 + 1][y * 3] = 'X';
                res[x * 3 + 1][y * 3 - 1] = 'X';
            }
        }
    }
    for (int i = 0; i < res.size(); i++) {
        for (int j = 0; j < res[i].size(); j++) {
            if (i % 3 == 1 && j % 3 == 1) {
                if (tab[i / 3][j / 3] == 0)
                    cout << '.';
                else
                    cout << 'O';
            } else {
                cout << res[i][j];
            }
        }
        cout << '\n';
    }
    return 0;
}