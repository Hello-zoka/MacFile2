#include <iostream>
#include <vector>
#include <queue>

using namespace std;

#define MAXN 507
#define INF 1e18
#define int long long
#define INFF 1e8



// vector<int> lst[MAXN];
int n;
struct e {
    int u, v, cap, cost;
};

// int cost[MAXN][MAXN], cap[MAXN][MAXN];
vector<e> edg;
vector<vector<int>> cost, cap;
vector<vector<int>> adj;

void djk(int v0, vector<int> &d, vector<int> &p) {
    d.assign(n, INF);
    d[v0] = 0;
    vector<int> m(n, 2);
    deque<int> q;
    q.push_back(v0);
    p.assign(n, -1);
    while (!q.empty()) {
        int u = q.front();
        q.pop_front();
        m[u] = 0;
        for (int v : adj[u]) {
            if (edg[v].cap > 0 && d[edg[v].v] > d[u] + edg[v].cost) {
                d[edg[v].v] = d[u] + edg[v].cost;
                p[edg[v].v] = v;
                if (m[edg[v].v] == 2) {
                    m[edg[v].v] = 1;
                    q.push_back(edg[v].v);
                } else if (m[edg[v].v] == 0) {
                    m[edg[v].v] = 1;
                    q.push_front(edg[v].v);
                }
            }
        }
    }
}


int min_cost(int s, int t) {
    int flow = 0;
    int cst = 0;
    vector<int> d, p;
    while (1) {
        djk(s, d, p);
        if (d[t] == INF) {
            break;
        }
        int f = INF;
        int cur = t;
        while (cur != s) {
            f = min(f, edg[p[cur]].cap);
            cur = edg[p[cur]].u;
        }
        flow += f;
        cst += f * d[t];
        cur = t;
        while (cur != s) {
            edg[p[cur]].cap -= f;
            edg[p[cur] ^ 1].cap += f;
            cur = edg[p[cur]].u;
        }
    }
    return cst;
}

signed main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int m;
    cin >> n >> m;
    adj.assign(n, vector<int>());
    cost.assign(n, vector<int>(n, 0));
    cap.assign(n, vector<int>(n, 0));
    for (int i = 0; i < m; i++) {
        int a, b, cp, c;
        cin >> a >> b >> cp >> c;
        a--;
        b--;
        e x = {a, b, cp, c};
        adj[a].push_back(edg.size());
        edg.push_back(x);
        e y = {b, a, 0, -c};
        adj[b].push_back(edg.size());
        edg.push_back(y);
    }
    cout << min_cost(0, n - 1);
    return 0;
}