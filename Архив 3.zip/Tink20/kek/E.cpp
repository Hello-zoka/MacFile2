#include <iostream>

using namespace  std;
#define int long long
signed main() {
    cout << 11842 / 30 * 63;
    cerr << (long long)362879 * 362879;
    return 0;
}